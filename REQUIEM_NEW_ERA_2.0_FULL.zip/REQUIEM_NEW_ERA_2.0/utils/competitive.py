"""Competitive services for REQUIEM NEW ERA 2.0.

All state-changing operations are SQLite transactions. This module deliberately
keeps ranked results pending until an authorized reviewer approves them.
"""
from __future__ import annotations

import json
import sqlite3
import hashlib
from datetime import datetime, timezone
from typing import Any

from utils import db as legacy_db

MODES = {"general", "tournament"}
CURRENCIES = {"points", "coins", "gems", "bounty"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def record_staff_audit(actor_id: int, action: str, target_id: int | None = None, details: str = "") -> None:
    with _conn() as conn:
        conn.execute("INSERT INTO audit_logs(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",
                     (actor_id, action[:100], target_id, (details or "")[:1000], _now()))
        conn.commit()


def _conn():
    return legacy_db._connect()


def _ensure_wallet(conn: sqlite3.Connection, user_id: int, username: str = "") -> None:
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0:
        raise ValueError("Invalid player ID")
    now = _now()
    conn.execute(
        "INSERT OR IGNORE INTO users(user_id,username,streak,rank,points,coins,gems,bounty,created_at,updated_at) "
        "VALUES(?,?,0,?,0,0,0,0,?,?)",
        (user_id, (username or "")[:100], legacy_db.RANK_TIERS[0][1], now, now),
    )


def init_competitive_schema() -> None:
    with _conn() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS competitive_ratings(
            user_id INTEGER NOT NULL, mode TEXT NOT NULL CHECK(mode IN ('general','tournament')),
            rating INTEGER NOT NULL DEFAULT 1000 CHECK(rating >= 0), wins INTEGER NOT NULL DEFAULT 0,
            losses INTEGER NOT NULL DEFAULT 0, games INTEGER NOT NULL DEFAULT 0,
            peak_rating INTEGER NOT NULL DEFAULT 1000, updated_at TEXT NOT NULL,
            PRIMARY KEY(user_id,mode)
        );
        CREATE TABLE IF NOT EXISTS competitive_matches(
            id INTEGER PRIMARY KEY AUTOINCREMENT, mode TEXT NOT NULL CHECK(mode IN ('general','tournament')),
            player1_id INTEGER NOT NULL, player2_id INTEGER NOT NULL, winner_id INTEGER,
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','cancelled')),
            idempotency_key TEXT NOT NULL UNIQUE, proof_url TEXT DEFAULT '',
            reviewer_id INTEGER, review_note TEXT DEFAULT '', created_at TEXT NOT NULL,
            reviewed_at TEXT, rating_delta_p1 INTEGER, rating_delta_p2 INTEGER,
            CHECK(player1_id <> player2_id)
        );
        CREATE INDEX IF NOT EXISTS idx_comp_matches_p1 ON competitive_matches(player1_id,created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_comp_matches_p2 ON competitive_matches(player2_id,created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_comp_matches_status ON competitive_matches(status,created_at);
        CREATE TABLE IF NOT EXISTS matchmaking_queue(
            user_id INTEGER PRIMARY KEY, mode TEXT NOT NULL DEFAULT 'general', rating INTEGER NOT NULL DEFAULT 1000,
            queued_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting','matched','cancelled'))
        );
        CREATE INDEX IF NOT EXISTS idx_match_queue_search ON matchmaking_queue(mode,status,rating,queued_at);
        CREATE TABLE IF NOT EXISTS competitive_seasons(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, starts_at TEXT NOT NULL,
            ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','archived')),
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS season_archive(
            id INTEGER PRIMARY KEY AUTOINCREMENT, season_id INTEGER NOT NULL, mode TEXT NOT NULL,
            user_id INTEGER NOT NULL, final_rating INTEGER NOT NULL, final_rank INTEGER NOT NULL,
            archived_at TEXT NOT NULL, UNIQUE(season_id,mode,user_id)
        );
        CREATE TABLE IF NOT EXISTS rival_pairs(
            user_low INTEGER NOT NULL, user_high INTEGER NOT NULL, created_by INTEGER NOT NULL,
            created_at TEXT NOT NULL, PRIMARY KEY(user_low,user_high), CHECK(user_low < user_high)
        );
        CREATE TABLE IF NOT EXISTS cosmetic_catalog(
            item_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
            currency TEXT NOT NULL CHECK(currency IN ('coins','gems','bounty','points')),
            price INTEGER NOT NULL CHECK(price >= 0), rarity TEXT NOT NULL DEFAULT 'common',
            rotation TEXT NOT NULL DEFAULT 'permanent' CHECK(rotation IN ('daily','weekly','seasonal','permanent')),
            active INTEGER NOT NULL DEFAULT 1, metadata_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS player_inventory(
            user_id INTEGER NOT NULL, item_id TEXT NOT NULL REFERENCES cosmetic_catalog(item_id),
            acquired_at TEXT NOT NULL, source TEXT NOT NULL, equipped INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(user_id,item_id)
        );
        CREATE TABLE IF NOT EXISTS anti_abuse_flags(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, category TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'review', details TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','reviewed','dismissed')),
            created_at TEXT NOT NULL, reviewed_by INTEGER, reviewed_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_abuse_flags_open ON anti_abuse_flags(status,severity,created_at DESC);
        CREATE TABLE IF NOT EXISTS achievement_catalog(
            achievement_id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL CHECK(category IN ('daily','weekly','seasonal','permanent')),
            trigger_key TEXT NOT NULL, target INTEGER NOT NULL CHECK(target > 0),
            reward_points INTEGER NOT NULL DEFAULT 0 CHECK(reward_points >= 0),
            reward_coins INTEGER NOT NULL DEFAULT 0 CHECK(reward_coins >= 0),
            reward_gems INTEGER NOT NULL DEFAULT 0 CHECK(reward_gems >= 0),
            reward_bounty INTEGER NOT NULL DEFAULT 0 CHECK(reward_bounty >= 0),
            title_reward TEXT DEFAULT '', badge_reward TEXT DEFAULT '', hidden INTEGER NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1, season_id INTEGER, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS player_achievements(
            user_id INTEGER NOT NULL, achievement_id TEXT NOT NULL REFERENCES achievement_catalog(achievement_id),
            period_key TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
            unlocked_at TEXT, claimed_at TEXT, PRIMARY KEY(user_id,achievement_id,period_key)
        );
        CREATE INDEX IF NOT EXISTS idx_achievement_trigger ON achievement_catalog(trigger_key,active,category);
        CREATE TABLE IF NOT EXISTS announcements(
            id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL,
            actor_id INTEGER NOT NULL, message TEXT NOT NULL, discord_message_id INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS competitive_idempotency(
            idempotency_key TEXT PRIMARY KEY, operation TEXT NOT NULL, result_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(competitive_matches)").fetchall()}
        if "proof_submitter_id" not in columns:
            conn.execute("ALTER TABLE competitive_matches ADD COLUMN proof_submitter_id INTEGER")
        cosmetic_columns = {row["name"] for row in conn.execute("PRAGMA table_info(cosmetic_catalog)").fetchall()}
        if "rotation" not in cosmetic_columns:
            conn.execute("ALTER TABLE cosmetic_catalog ADD COLUMN rotation TEXT NOT NULL DEFAULT 'permanent'")
        conn.commit()


def _ensure_rating(conn: sqlite3.Connection, user_id: int, mode: str) -> sqlite3.Row:
    if mode not in MODES:
        raise ValueError("Invalid rating mode")
    _ensure_wallet(conn, user_id)
    conn.execute(
        "INSERT OR IGNORE INTO competitive_ratings(user_id,mode,rating,peak_rating,updated_at) VALUES(?,?,1000,1000,?)",
        (user_id, mode, _now()),
    )
    return conn.execute("SELECT * FROM competitive_ratings WHERE user_id=? AND mode=?", (user_id, mode)).fetchone()


def get_player_ratings(user_id: int) -> dict[str, Any]:
    with _conn() as conn:
        result = {}
        for mode in sorted(MODES):
            row = conn.execute("SELECT * FROM competitive_ratings WHERE user_id=? AND mode=?", (user_id, mode)).fetchone()
            result[mode] = dict(row) if row else {"user_id": user_id, "mode": mode, "rating": 1000, "wins": 0, "losses": 0, "games": 0, "peak_rating": 1000}
        return result


def create_competitive_match(player1_id: int, player2_id: int, mode: str = "general", idempotency_key: str | None = None, proof_url: str = "") -> int:
    if player1_id == player2_id:
        raise ValueError("A player cannot compete against themselves")
    if mode not in MODES:
        raise ValueError("Invalid match mode")
    key = (idempotency_key or "").strip()[:160]
    if not key:
        raise ValueError("Idempotency key is required")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            old = conn.execute("SELECT id FROM competitive_matches WHERE idempotency_key=?", (key,)).fetchone()
            if old:
                conn.commit()
                return int(old["id"])
            _ensure_rating(conn, player1_id, mode)
            _ensure_rating(conn, player2_id, mode)
            cur = conn.execute(
                "INSERT INTO competitive_matches(mode,player1_id,player2_id,idempotency_key,proof_url,created_at) VALUES(?,?,?,?,?,?)",
                (mode, player1_id, player2_id, key, (proof_url or "")[:2000], _now()),
            )
            conn.commit()
            return int(cur.lastrowid)
        except Exception:
            conn.rollback()
            raise


def _elo_delta(r1: int, r2: int, score1: float, k: int) -> int:
    expected = 1.0 / (1.0 + 10.0 ** ((r2 - r1) / 400.0))
    return int(round(k * (score1 - expected)))


def record_approved_match_in_connection(conn: sqlite3.Connection, mode: str, player1_id: int, player2_id: int,
                                         winner_id: int, idempotency_key: str, proof_url: str = "",
                                         reviewer_id: int | None = None, note: str = "") -> dict[str, Any]:
    """Apply an already-reviewed result inside a caller-owned transaction."""
    if mode not in MODES or player1_id == player2_id or winner_id not in {player1_id, player2_id}:
        raise ValueError("Invalid approved match data")
    existing = conn.execute("SELECT id FROM competitive_matches WHERE idempotency_key=?", (idempotency_key,)).fetchone()
    if existing:
        return {"id": int(existing["id"]), "duplicate": True}
    r1 = _ensure_rating(conn, player1_id, mode)
    r2 = _ensure_rating(conn, player2_id, mode)
    k = 40 if int(r1["games"]) + int(r2["games"]) < 20 else 32
    delta1 = _elo_delta(int(r1["rating"]), int(r2["rating"]), 1.0 if winner_id == player1_id else 0.0, k)
    delta2 = -delta1
    now = _now()
    for uid, delta, win in ((player1_id, delta1, winner_id == player1_id), (player2_id, delta2, winner_id == player2_id)):
        conn.execute("UPDATE competitive_ratings SET rating=MAX(0,rating+?),wins=wins+?,losses=losses+?,games=games+1,peak_rating=MAX(peak_rating,rating+?),updated_at=? WHERE user_id=? AND mode=?",
                     (delta, int(win), int(not win), delta, now, uid, mode))
    _record_achievement_progress_in_connection(conn, winner_id, "general_win" if mode == "general" else "tournament_win", 1)
    _record_achievement_progress_in_connection(conn, player1_id, "general_match" if mode == "general" else "tournament_match", 1)
    _record_achievement_progress_in_connection(conn, player2_id, "general_match" if mode == "general" else "tournament_match", 1)
    cur = conn.execute("INSERT INTO competitive_matches(mode,player1_id,player2_id,winner_id,status,idempotency_key,proof_url,reviewer_id,review_note,created_at,reviewed_at,rating_delta_p1,rating_delta_p2) VALUES(?,?,?,?, 'approved',?,?,?,?,?,?,?,?)",
                       (mode, player1_id, player2_id, winner_id, idempotency_key, (proof_url or "")[:2000], reviewer_id, (note or "")[:500], now, now, delta1, delta2))
    if mode == "general":
        risk = conn.execute("SELECT wins,games FROM competitive_ratings WHERE user_id=? AND mode='general'", (winner_id,)).fetchone()
        if risk and int(risk["games"]) >= 10 and int(risk["wins"]) / max(1,int(risk["games"])) >= 0.90:
            already = conn.execute("SELECT 1 FROM anti_abuse_flags WHERE user_id=? AND category='high_win_rate' AND status='open'", (winner_id,)).fetchone()
            if not already:
                conn.execute("INSERT INTO anti_abuse_flags(user_id,category,severity,details,created_at) VALUES(?,?,?,?,?)", (winner_id,'high_win_rate','review',f"{risk['wins']}/{risk['games']} approved wins; manual review only",now))
    return {"id": int(cur.lastrowid), "duplicate": False, "delta_p1": delta1, "delta_p2": delta2}


def submit_competitive_match_proof(match_id: int, user_id: int, image_url: str, description: str = "") -> bool:
    if not image_url.startswith(("https://", "http://")):
        raise ValueError("Proof URL must use HTTP or HTTPS")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            row=conn.execute("SELECT * FROM competitive_matches WHERE id=? AND status='pending'",(match_id,)).fetchone()
            if not row or user_id not in (row["player1_id"],row["player2_id"]):
                raise LookupError("Match is unavailable or you are not a participant")
            if row["proof_url"]:
                raise LookupError("A proof is already waiting for review")
            conn.execute("UPDATE competitive_matches SET proof_url=?,proof_submitter_id=?,review_note=? WHERE id=? AND status='pending' AND proof_url=''",
                         (image_url[:2000],user_id,(description or "")[:500],match_id))
            conn.commit(); return True
        except Exception:
            conn.rollback(); raise


def review_competitive_match_in_connection(conn: sqlite3.Connection, match_id: int, decision: str, reviewer_id: int, note: str = "") -> dict[str, Any]:
    if decision not in {"approved", "rejected"}:
        raise ValueError("Invalid review decision")
    match=conn.execute("SELECT * FROM competitive_matches WHERE id=? AND status='pending' AND proof_url<>''",(match_id,)).fetchone()
    if not match or not match["proof_submitter_id"]:
        raise LookupError("Match proof not found or already reviewed")
    winner=int(match["proof_submitter_id"])
    p1,p2=int(match["player1_id"]),int(match["player2_id"])
    delta1=delta2=None
    if decision == "approved":
        r1=_ensure_rating(conn,p1,match["mode"]); r2=_ensure_rating(conn,p2,match["mode"])
        k=40 if int(r1["games"])+int(r2["games"])<20 else 32
        delta1=_elo_delta(int(r1["rating"]),int(r2["rating"]),1.0 if winner==p1 else 0.0,k); delta2=-delta1
        now=_now()
        for uid,delta,win in ((p1,delta1,winner==p1),(p2,delta2,winner==p2)):
            conn.execute("UPDATE competitive_ratings SET rating=MAX(0,rating+?),wins=wins+?,losses=losses+?,games=games+1,peak_rating=MAX(peak_rating,rating+?),updated_at=? WHERE user_id=? AND mode=?",
                         (delta,int(win),int(not win),delta,now,uid,match["mode"]))
        _record_achievement_progress_in_connection(conn, winner, "general_win" if match["mode"] == "general" else "tournament_win", 1)
        _record_achievement_progress_in_connection(conn, p1, "general_match" if match["mode"] == "general" else "tournament_match", 1)
        _record_achievement_progress_in_connection(conn, p2, "general_match" if match["mode"] == "general" else "tournament_match", 1)
        if match["mode"] == "general":
            risk=conn.execute("SELECT wins,games FROM competitive_ratings WHERE user_id=? AND mode='general'",(winner,)).fetchone()
            if risk and int(risk["games"])>=10 and int(risk["wins"])/max(1,int(risk["games"]))>=0.90:
                if not conn.execute("SELECT 1 FROM anti_abuse_flags WHERE user_id=? AND category='high_win_rate' AND status='open'",(winner,)).fetchone():
                    conn.execute("INSERT INTO anti_abuse_flags(user_id,category,severity,details,created_at) VALUES(?,?,?,?,?)",(winner,'high_win_rate','review',f"{risk['wins']}/{risk['games']} approved wins; manual review only",now))
    now=_now()
    conn.execute("UPDATE competitive_matches SET status=?,winner_id=?,reviewer_id=?,review_note=?,reviewed_at=?,rating_delta_p1=?,rating_delta_p2=? WHERE id=? AND status='pending'",
                 (decision,winner if decision=='approved' else None,reviewer_id,(note or '')[:500],now,delta1,delta2,match_id))
    return {"id":match_id,"status":decision,"user_id":winner,"winner_id":winner if decision=='approved' else None,
            "reward":{"points":0,"coins":0,"gems":0,"tournament_points":0,"elo_delta_p1":delta1,"elo_delta_p2":delta2}}


def review_competitive_match(match_id: int, decision: str, reviewer_id: int, winner_id: int | None = None, note: str = "") -> dict[str, Any]:
    """Review a match only after a participant has submitted a proof image."""
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            match=conn.execute("SELECT proof_submitter_id FROM competitive_matches WHERE id=? AND status='pending' AND proof_url<>''",(match_id,)).fetchone()
            if not match or not match["proof_submitter_id"]:
                raise LookupError("A submitted proof is required before review")
            submitted_winner=int(match["proof_submitter_id"])
            if winner_id is not None and int(winner_id) != submitted_winner:
                raise ValueError("Winner must match the player who submitted the proof")
            result=review_competitive_match_in_connection(conn,match_id,decision,reviewer_id,note)
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise


def matchmaking_status(user_id: int) -> dict[str, Any]:
    with _conn() as conn:
        row=conn.execute("SELECT * FROM matchmaking_queue WHERE user_id=?",(user_id,)).fetchone()
        if not row: return {"status":"idle"}
        if row["status"] == "matched":
            match=conn.execute("SELECT id,player1_id,player2_id,status,proof_url FROM competitive_matches WHERE (player1_id=? OR player2_id=?) AND mode=? ORDER BY id DESC LIMIT 1",(user_id,user_id,row["mode"])).fetchone()
            if match:
                opponent=int(match["player2_id"] if match["player1_id"]==user_id else match["player1_id"])
                return {"status":"matched","match_id":int(match["id"]),"opponent_id":opponent,"match_status":match["status"],"proof_submitted":bool(match["proof_url"])}
        return {"status":row["status"],"queued_at":row["queued_at"],"rating":int(row["rating"]),"mode":row["mode"]}


def queue_for_match(user_id: int, mode: str = "general", max_rating_gap: int = 250) -> dict[str, Any]:
    if mode not in MODES:
        raise ValueError("Invalid matchmaking mode")
    if max_rating_gap < 0 or max_rating_gap > 2000:
        raise ValueError("Invalid rating gap")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            active = conn.execute("SELECT id,player1_id,player2_id FROM competitive_matches WHERE mode=? AND status='pending' AND (player1_id=? OR player2_id=?) ORDER BY id DESC LIMIT 1",(mode,user_id,user_id)).fetchone()
            if active:
                opponent=int(active["player2_id"] if active["player1_id"]==user_id else active["player1_id"])
                current=conn.execute("SELECT rating FROM competitive_ratings WHERE user_id=? AND mode=?",(user_id,mode)).fetchone()
                conn.commit()
                return {"status":"matched","match_id":int(active["id"]),"opponent_id":opponent,"rating":int(current["rating"]) if current else 1000}
            rating = _ensure_rating(conn, user_id, mode)
            now = _now()
            conn.execute("INSERT INTO matchmaking_queue(user_id,mode,rating,queued_at,status) VALUES(?,?,?,?, 'waiting') ON CONFLICT(user_id) DO UPDATE SET mode=excluded.mode,rating=excluded.rating,queued_at=excluded.queued_at,status='waiting'", (user_id, mode, int(rating["rating"]), now))
            opponent = conn.execute("SELECT user_id,rating FROM matchmaking_queue WHERE user_id<>? AND mode=? AND status='waiting' AND ABS(rating-?)<=? ORDER BY ABS(rating-?),queued_at LIMIT 1", (user_id, mode, int(rating["rating"]), max_rating_gap, int(rating["rating"]))).fetchone()
            if not opponent:
                conn.commit()
                return {"status": "waiting", "rating": int(rating["rating"])}
            low, high = sorted((user_id, int(opponent["user_id"])))
            key = f"matchmaking:{mode}:{low}:{high}:{now}"
            _ensure_rating(conn, int(opponent["user_id"]), mode)
            cur = conn.execute("INSERT INTO competitive_matches(mode,player1_id,player2_id,idempotency_key,created_at) VALUES(?,?,?,?,?)", (mode, low, high, key, now))
            conn.execute("UPDATE matchmaking_queue SET status='matched' WHERE user_id IN (?,?)", (user_id, int(opponent["user_id"])))
            conn.commit()
            return {"status": "matched", "match_id": int(cur.lastrowid), "opponent_id": int(opponent["user_id"]), "rating": int(rating["rating"])}
        except Exception:
            conn.rollback()
            raise


def leave_matchmaking(user_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("UPDATE matchmaking_queue SET status='cancelled' WHERE user_id=? AND status='waiting'", (user_id,))
        conn.commit()
        return cur.rowcount == 1


def set_rival(user_id: int, rival_id: int) -> None:
    if user_id == rival_id or min(user_id, rival_id) <= 0:
        raise ValueError("Invalid rival")
    low, high = sorted((user_id, rival_id))
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            _ensure_wallet(conn, user_id)
            _ensure_wallet(conn, rival_id)
            conn.execute("INSERT OR IGNORE INTO rival_pairs(user_low,user_high,created_by,created_at) VALUES(?,?,?,?)", (low, high, user_id, _now()))
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def list_rivals(user_id: int) -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute("SELECT CASE WHEN user_low=? THEN user_high ELSE user_low END AS rival_id,created_at FROM rival_pairs WHERE user_low=? OR user_high=? ORDER BY created_at DESC", (user_id, user_id, user_id)).fetchall()
        return [dict(r) for r in rows]


def upsert_cosmetic(item_id: str, name: str, category: str, currency: str, price: int, rarity: str = "common", rotation: str = "permanent", metadata: dict | None = None) -> None:
    if currency not in CURRENCIES or price < 0 or price > 10_000_000 or rotation not in {"daily","weekly","seasonal","permanent"}:
        raise ValueError("Invalid cosmetic price or currency")
    if not item_id.strip() or not name.strip() or not category.strip():
        raise ValueError("Item ID, name and category are required")
    with _conn() as conn:
        conn.execute("INSERT INTO cosmetic_catalog(item_id,name,category,currency,price,rarity,rotation,metadata_json) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET name=excluded.name,category=excluded.category,currency=excluded.currency,price=excluded.price,rarity=excluded.rarity,rotation=excluded.rotation,metadata_json=excluded.metadata_json", (item_id.strip()[:80], name.strip()[:100], category.strip()[:40], currency, price, rarity[:30], rotation, json.dumps(metadata or {}, ensure_ascii=False)))
        conn.commit()


def purchase_cosmetic(user_id: int, item_id: str, idempotency_key: str) -> dict[str, Any]:
    key = (idempotency_key or "").strip()[:160]
    if not key:
        raise ValueError("Idempotency key is required")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            prior = conn.execute("SELECT result_json FROM competitive_idempotency WHERE idempotency_key=?", (key,)).fetchone()
            if prior:
                conn.commit()
                return json.loads(prior["result_json"])
            item = conn.execute("SELECT * FROM cosmetic_catalog WHERE item_id=? AND active=1", (item_id,)).fetchone()
            if not item:
                raise LookupError("Cosmetic item is unavailable")
            if item["rotation"] != "permanent":
                eligible={r["item_id"] for r in _rotating_rows(conn,item["rotation"],6)}
                if item_id not in eligible:
                    raise LookupError("This item is not in the current shop rotation")
            if conn.execute("SELECT 1 FROM player_inventory WHERE user_id=? AND item_id=?", (user_id, item_id)).fetchone():
                raise ValueError("Item already owned")
            _ensure_wallet(conn, user_id)
            field, price = item["currency"], int(item["price"])
            if price:
                conn.execute(f"UPDATE users SET {field}={field}-?,updated_at=? WHERE user_id=? AND {field}>=?", (price, _now(), user_id, price))
                if conn.execute("SELECT changes()").fetchone()[0] != 1:
                    raise ValueError("Insufficient balance")
                balance = conn.execute(f"SELECT {field} FROM users WHERE user_id=?", (user_id,)).fetchone()[0]
                conn.execute("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,created_at) VALUES(?,?,?,?,?,?)", (user_id, field, -price, balance, f"cosmetic purchase: {item_id}", _now()))
            conn.execute("INSERT INTO player_inventory(user_id,item_id,acquired_at,source) VALUES(?,?,?,'black_market')", (user_id, item_id, _now()))
            result = {"user_id": user_id, "item_id": item_id, "status": "owned"}
            conn.execute("INSERT INTO competitive_idempotency(idempotency_key,operation,result_json,created_at) VALUES(?,?,?,?)", (key, "purchase_cosmetic", json.dumps(result), _now()))
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise


def player_inventory(user_id: int) -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute("SELECT c.item_id,c.name,c.category,c.rarity,c.metadata_json,i.acquired_at,i.source,i.equipped FROM player_inventory i JOIN cosmetic_catalog c ON c.item_id=i.item_id WHERE i.user_id=? ORDER BY i.acquired_at DESC", (user_id,)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            try: item["metadata"] = json.loads(item.pop("metadata_json"))
            except (ValueError, TypeError): item["metadata"] = {}
            result.append(item)
        return result


def leaderboard(mode: str = "general", limit: int = 10) -> list[dict[str, Any]]:
    if mode not in MODES:
        raise ValueError("Invalid rating mode")
    limit = max(1, min(int(limit), 100))
    with _conn() as conn:
        return [dict(r) for r in conn.execute("SELECT r.user_id,u.username,r.rating,r.wins,r.losses,r.games,r.peak_rating FROM competitive_ratings r JOIN users u ON u.user_id=r.user_id WHERE r.mode=? ORDER BY r.rating DESC,r.wins DESC,r.user_id ASC LIMIT ?", (mode, limit)).fetchall()]


def wanted_board(limit: int = 10) -> dict[str, Any]:
    limit = max(1, min(int(limit), 100))
    with _conn() as conn:
        bounty = [dict(r) for r in conn.execute("SELECT user_id,username,bounty FROM users ORDER BY bounty DESC,user_id ASC LIMIT ?", (limit,)).fetchall()]
        general = [dict(r) for r in conn.execute("SELECT r.user_id,u.username,r.rating,r.wins,r.losses FROM competitive_ratings r JOIN users u ON u.user_id=r.user_id WHERE r.mode='general' ORDER BY r.rating DESC LIMIT ?", (limit,)).fetchall()]
        tournament = [dict(r) for r in conn.execute("SELECT r.user_id,u.username,r.rating,r.wins,r.losses FROM competitive_ratings r JOIN users u ON u.user_id=r.user_id WHERE r.mode='tournament' ORDER BY r.rating DESC LIMIT ?", (limit,)).fetchall()]
        weekly = [dict(r) for r in conn.execute("SELECT m.winner_id AS user_id,u.username,COUNT(*) AS wins FROM competitive_matches m JOIN users u ON u.user_id=m.winner_id WHERE m.status='approved' AND datetime(m.reviewed_at)>=datetime('now','-7 days') GROUP BY m.winner_id ORDER BY wins DESC,m.winner_id LIMIT ?", (limit,)).fetchall()]
        monthly = [dict(r) for r in conn.execute("SELECT m.winner_id AS user_id,u.username,COUNT(*) AS wins FROM competitive_matches m JOIN users u ON u.user_id=m.winner_id WHERE m.status='approved' AND datetime(m.reviewed_at)>=datetime('now','-30 days') GROUP BY m.winner_id ORDER BY wins DESC,m.winner_id LIMIT ?", (limit,)).fetchall()]
        return {"bounty": bounty, "weekly": weekly, "monthly": monthly, "general_elo": general, "tournament_elo": tournament}


def list_cosmetics(active_only: bool = True) -> list[dict[str, Any]]:
    with _conn() as conn:
        where = "WHERE active=1" if active_only else ""
        rows = conn.execute(f"SELECT * FROM cosmetic_catalog {where} ORDER BY CASE rarity WHEN 'legendary' THEN 1 WHEN 'epic' THEN 2 WHEN 'rare' THEN 3 ELSE 4 END,price,item_id").fetchall()
        result=[]
        for row in rows:
            item=dict(row)
            try: item["metadata"] = json.loads(item.pop("metadata_json"))
            except (ValueError,TypeError): item["metadata"]={}
            result.append(item)
        return result


def _rotation_period(rotation: str) -> str:
    try:
        from config import TIMEZONE
        from zoneinfo import ZoneInfo
        now=datetime.now(ZoneInfo(TIMEZONE))
    except Exception:
        now=datetime.now(timezone.utc)
    if rotation == "daily": return now.date().isoformat()
    if rotation == "weekly": return now.strftime("%G-W%V")
    if rotation == "seasonal": return f"{now.year}-Q{((now.month-1)//3)+1}"
    return "permanent"


def _rotating_rows(conn: sqlite3.Connection, rotation: str, limit: int = 6) -> list[sqlite3.Row]:
    if rotation not in {"daily","weekly","seasonal","permanent"}:
        raise ValueError("Invalid shop rotation")
    rows=conn.execute("SELECT * FROM cosmetic_catalog WHERE active=1 AND rotation=? ORDER BY item_id",(rotation,)).fetchall()
    if rotation == "permanent" or len(rows) <= limit: return rows[:limit]
    period=_rotation_period(rotation)
    offset=int(hashlib.sha256(period.encode()).hexdigest()[:8],16)%len(rows)
    return [rows[(offset+i)%len(rows)] for i in range(min(limit,len(rows)))]


def rotating_shop(rotation: str, limit: int = 6) -> list[dict[str, Any]]:
    limit=max(1,min(int(limit),20))
    with _conn() as conn:
        rows=_rotating_rows(conn,rotation,limit)
        result=[]
        for row in rows:
            item=dict(row)
            try: item["metadata"] = json.loads(item.pop("metadata_json"))
            except (ValueError,TypeError): item["metadata"]={}
            result.append(item)
        return result


def equip_inventory_item(user_id: int, item_id: str) -> bool:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            row=conn.execute("SELECT c.category FROM player_inventory i JOIN cosmetic_catalog c ON c.item_id=i.item_id WHERE i.user_id=? AND i.item_id=?",(user_id,item_id)).fetchone()
            if not row: raise LookupError("Item is not owned by this player")
            conn.execute("UPDATE player_inventory SET equipped=0 WHERE user_id=? AND item_id IN (SELECT item_id FROM cosmetic_catalog WHERE category=?)",(user_id,row["category"]))
            conn.execute("UPDATE player_inventory SET equipped=1 WHERE user_id=? AND item_id=?",(user_id,item_id))
            conn.commit(); return True
        except Exception:
            conn.rollback(); raise


def player_match_history(user_id: int, limit: int = 30) -> list[dict[str, Any]]:
    limit=max(1,min(int(limit),100))
    with _conn() as conn:
        return [dict(r) for r in conn.execute("SELECT id,mode,player1_id,player2_id,winner_id,status,review_note,created_at,reviewed_at,rating_delta_p1,rating_delta_p2 FROM competitive_matches WHERE player1_id=? OR player2_id=? ORDER BY id DESC LIMIT ?",(user_id,user_id,limit)).fetchall()]


def create_competitive_season(name: str, starts_at: str, ends_at: str) -> int:
    name=(name or "").strip()
    if not name or len(name)>100 or not starts_at or not ends_at or starts_at>=ends_at:
        raise ValueError("Invalid season name or date range")
    with _conn() as conn:
        cur=conn.execute("INSERT INTO competitive_seasons(name,starts_at,ends_at,status,created_at) VALUES(?,?,?,'scheduled',?)",(name,starts_at,ends_at,_now()))
        conn.commit(); return int(cur.lastrowid)


def list_competitive_seasons() -> list[dict[str, Any]]:
    with _conn() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM competitive_seasons ORDER BY id DESC").fetchall()]


def activate_competitive_season(season_id: int) -> None:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            row=conn.execute("SELECT id,status FROM competitive_seasons WHERE id=?",(season_id,)).fetchone()
            if not row or row["status"]=="archived": raise LookupError("Season is unavailable")
            conn.execute("UPDATE competitive_seasons SET status='scheduled' WHERE status='active'")
            conn.execute("UPDATE competitive_seasons SET status='active' WHERE id=?",(season_id,))
            conn.commit()
        except Exception:
            conn.rollback(); raise


def archive_competitive_season(season_id: int) -> int:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            season=conn.execute("SELECT * FROM competitive_seasons WHERE id=? AND status!='archived'",(season_id,)).fetchone()
            if not season: raise LookupError("Season not found or already archived")
            count=0
            for mode in sorted(MODES):
                rows=conn.execute("SELECT user_id,rating FROM competitive_ratings WHERE mode=? ORDER BY rating DESC,wins DESC,user_id LIMIT 100",(mode,)).fetchall()
                for rank,row in enumerate(rows,1):
                    cur=conn.execute("INSERT OR IGNORE INTO season_archive(season_id,mode,user_id,final_rating,final_rank,archived_at) VALUES(?,?,?,?,?,?)",(season_id,mode,row["user_id"],row["rating"],rank,_now()))
                    count += cur.rowcount
            conn.execute("UPDATE competitive_seasons SET status='archived' WHERE id=?",(season_id,))
            conn.commit(); return count
        except Exception:
            conn.rollback(); raise


def player_analytics(user_id: int) -> dict[str, Any]:
    with _conn() as conn:
        result = {}
        for mode in sorted(MODES):
            row = conn.execute("SELECT * FROM competitive_ratings WHERE user_id=? AND mode=?", (user_id, mode)).fetchone()
            result[mode] = dict(row) if row else {"rating": 1000, "wins": 0, "losses": 0, "games": 0, "peak_rating": 1000}
        games = conn.execute("SELECT COUNT(*) AS total,SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved,SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending FROM competitive_matches WHERE player1_id=? OR player2_id=?", (user_id, user_id)).fetchone()
        result["matches"] = dict(games)
        result["win_rate"] = round(100 * result["general"]["wins"] / max(1, result["general"]["games"]), 2)
        return result


def evaluate_player_risk(user_id: int) -> list[int]:
    """Create review-only flags for statistical anomalies; never auto-ban players."""
    with _conn() as conn:
        row = conn.execute("SELECT wins,losses,games,rating FROM competitive_ratings WHERE user_id=? AND mode='general'", (user_id,)).fetchone()
        if not row or int(row["games"]) < 10:
            return []
        win_rate = int(row["wins"]) / max(1, int(row["games"]))
        if win_rate < 0.90:
            return []
        exists = conn.execute("SELECT id FROM anti_abuse_flags WHERE user_id=? AND category='high_win_rate' AND status='open'", (user_id,)).fetchone()
        if exists:
            return []
        cur = conn.execute("INSERT INTO anti_abuse_flags(user_id,category,severity,details,created_at) VALUES(?,?,?,?,?)",
                           (user_id, "high_win_rate", "review", f"{row['wins']}/{row['games']} wins; win rate={win_rate:.1%}; rating={row['rating']}", _now()))
        conn.commit()
        return [int(cur.lastrowid)]


def create_achievement(data: dict[str, Any]) -> str:
    key=str(data.get("achievement_id") or "").strip().lower()
    title=str(data.get("title") or "").strip()
    category=data.get("category")
    trigger=str(data.get("trigger_key") or "").strip()
    target=int(data.get("target") or 0)
    if not key or len(key)>80 or not title or len(title)>100 or category not in {"daily","weekly","seasonal","permanent"} or not trigger or target<1 or target>1_000_000:
        raise ValueError("Invalid achievement definition")
    rewards={k:int(data.get(k) or 0) for k in ("reward_points","reward_coins","reward_gems","reward_bounty")}
    if any(v<0 or v>10_000_000 for v in rewards.values()): raise ValueError("Invalid achievement reward")
    with _conn() as conn:
        conn.execute("INSERT INTO achievement_catalog(achievement_id,title,description,category,trigger_key,target,reward_points,reward_coins,reward_gems,reward_bounty,title_reward,badge_reward,hidden,active,season_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(achievement_id) DO UPDATE SET title=excluded.title,description=excluded.description,category=excluded.category,trigger_key=excluded.trigger_key,target=excluded.target,reward_points=excluded.reward_points,reward_coins=excluded.reward_coins,reward_gems=excluded.reward_gems,reward_bounty=excluded.reward_bounty,title_reward=excluded.title_reward,badge_reward=excluded.badge_reward,hidden=excluded.hidden,active=excluded.active,season_id=excluded.season_id",
                     (key,title,str(data.get("description") or "")[:500],category,trigger,target,*[rewards[k] for k in ("reward_points","reward_coins","reward_gems","reward_bounty")],str(data.get("title_reward") or "")[:80],str(data.get("badge_reward") or "")[:80],int(bool(data.get("hidden"))),int(bool(data.get("active",True))),data.get("season_id"),_now()))
        conn.commit()
    return key


def _achievement_period_key(category: str, season_id: int | None = None) -> str:
    try:
        from config import TIMEZONE
        from zoneinfo import ZoneInfo
        local=datetime.now(ZoneInfo(TIMEZONE))
    except Exception:
        local=datetime.now(timezone.utc)
    if category == "daily": return local.date().isoformat()
    if category == "weekly": return local.strftime("%G-W%V")
    if category == "seasonal": return f"season:{season_id or 'current'}"
    return "all-time"


def _record_achievement_progress_in_connection(conn: sqlite3.Connection, user_id: int, trigger_key: str, amount: int = 1) -> list[str]:
    if amount <= 0: return []
    unlocked=[]
    rows=conn.execute("SELECT * FROM achievement_catalog WHERE trigger_key=? AND active=1",(trigger_key,)).fetchall()
    for achievement in rows:
        period=_achievement_period_key(achievement["category"],achievement["season_id"])
        conn.execute("INSERT OR IGNORE INTO player_achievements(user_id,achievement_id,period_key,progress) VALUES(?,?,?,0)",(user_id,achievement["achievement_id"],period))
        progress=conn.execute("SELECT progress,unlocked_at FROM player_achievements WHERE user_id=? AND achievement_id=? AND period_key=?",(user_id,achievement["achievement_id"],period)).fetchone()
        if progress["unlocked_at"]: continue
        new_progress=min(int(achievement["target"]),int(progress["progress"])+amount)
        unlocked_at=_now() if new_progress>=int(achievement["target"]) else None
        conn.execute("UPDATE player_achievements SET progress=?,unlocked_at=? WHERE user_id=? AND achievement_id=? AND period_key=?",(new_progress,unlocked_at,user_id,achievement["achievement_id"],period))
        if unlocked_at: unlocked.append(achievement["achievement_id"])
    return unlocked


def record_achievement_progress(user_id: int, trigger_key: str, amount: int = 1) -> list[str]:
    if isinstance(amount,bool) or not isinstance(amount,int) or amount<=0 or amount>1_000_000: raise ValueError("Invalid progress amount")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            _ensure_wallet(conn,user_id)
            unlocked=_record_achievement_progress_in_connection(conn,user_id,trigger_key,amount)
            conn.commit(); return unlocked
        except Exception:
            conn.rollback(); raise


def list_player_achievements(user_id: int) -> list[dict[str, Any]]:
    with _conn() as conn:
        rows=conn.execute("SELECT a.achievement_id,a.title,a.description,a.category,a.target,a.reward_points,a.reward_coins,a.reward_gems,a.reward_bounty,a.title_reward,a.badge_reward,a.hidden,p.period_key,p.progress,p.unlocked_at,p.claimed_at FROM achievement_catalog a LEFT JOIN player_achievements p ON p.achievement_id=a.achievement_id AND p.user_id=? AND p.period_key=(SELECT MAX(px.period_key) FROM player_achievements px WHERE px.user_id=? AND px.achievement_id=a.achievement_id) WHERE a.active=1 ORDER BY a.category,a.achievement_id",(user_id,user_id)).fetchall()
        return [dict(r) for r in rows if not r["hidden"] or r["unlocked_at"]]


def claim_achievement(user_id: int, achievement_id: str, period_key: str) -> dict[str, Any]:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            row=conn.execute("SELECT p.*,a.* FROM player_achievements p JOIN achievement_catalog a ON a.achievement_id=p.achievement_id WHERE p.user_id=? AND p.achievement_id=? AND p.period_key=? AND p.unlocked_at IS NOT NULL AND p.claimed_at IS NULL",(user_id,achievement_id,period_key)).fetchone()
            if not row: raise LookupError("Achievement is not unlocked or was already claimed")
            _ensure_wallet(conn,user_id)
            now=_now()
            deltas={"points":int(row["reward_points"]),"coins":int(row["reward_coins"]),"gems":int(row["reward_gems"]),"bounty":int(row["reward_bounty"])}
            for currency,delta in deltas.items():
                if not delta: continue
                conn.execute(f"UPDATE users SET {currency}={currency}+?,updated_at=? WHERE user_id=?",(delta,now,user_id))
                balance=conn.execute(f"SELECT {currency} FROM users WHERE user_id=?",(user_id,)).fetchone()[0]
                conn.execute("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,created_at) VALUES(?,?,?,?,?,?)",(user_id,currency,delta,balance,f"achievement reward: {achievement_id}",now))
            if deltas["points"]:
                points=conn.execute("SELECT points FROM users WHERE user_id=?",(user_id,)).fetchone()[0]
                conn.execute("UPDATE users SET rank=? WHERE user_id=?",(legacy_db.calculate_rank(points),user_id))
            conn.execute("UPDATE player_achievements SET claimed_at=? WHERE user_id=? AND achievement_id=? AND period_key=? AND claimed_at IS NULL",(now,user_id,achievement_id,period_key))
            conn.commit()
            return {"achievement_id":achievement_id,"rewards":deltas,"title_reward":row["title_reward"],"badge_reward":row["badge_reward"]}
        except Exception:
            conn.rollback(); raise


def create_abuse_flag(user_id: int, category: str, details: str, severity: str = "review") -> int:
    if severity not in {"low", "review", "high", "critical"}:
        raise ValueError("Invalid severity")
    with _conn() as conn:
        cur = conn.execute("INSERT INTO anti_abuse_flags(user_id,category,severity,details,created_at) VALUES(?,?,?,?,?)", (user_id, category[:60], severity, details[:1000], _now()))
        conn.commit()
        return int(cur.lastrowid)


def review_abuse_flag(flag_id: int, reviewer_id: int, decision: str) -> bool:
    if decision not in {"reviewed", "dismissed"}:
        raise ValueError("Invalid decision")
    with _conn() as conn:
        cur = conn.execute("UPDATE anti_abuse_flags SET status=?,reviewed_by=?,reviewed_at=? WHERE id=? AND status='open'", (decision, reviewer_id, _now(), flag_id))
        if cur.rowcount == 1:
            conn.execute("INSERT INTO audit_logs(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",(reviewer_id,"anti_abuse_flag_review",flag_id,decision,_now()))
        conn.commit()
        return cur.rowcount == 1
