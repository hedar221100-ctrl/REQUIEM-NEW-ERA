"""SQLite-safe backup and health helpers."""
from __future__ import annotations
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from contextlib import closing


def backup_database(db_path: str | Path, backup_dir: str | Path, keep: int = 14, min_interval_seconds: int = 3600) -> Path | None:
    source = Path(db_path).expanduser().resolve()
    target_dir = Path(backup_dir).expanduser().resolve()
    if not source.exists() or source.stat().st_size == 0:
        return None
    target_dir.mkdir(parents=True, exist_ok=True)
    existing = sorted(target_dir.glob("requiem_*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)
    now = datetime.now(timezone.utc)
    if existing and now.timestamp() - existing[0].stat().st_mtime < min_interval_seconds:
        return existing[0]
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    final = target_dir / f"requiem_{stamp}.sqlite3"
    temp = target_dir / f".{final.name}.tmp"
    try:
        with closing(sqlite3.connect(str(source), timeout=30)) as src, closing(sqlite3.connect(str(temp))) as dst:
            src.backup(dst)
            check = dst.execute("PRAGMA integrity_check").fetchone()
            if not check or check[0] != "ok":
                raise sqlite3.DatabaseError(f"Backup integrity check failed: {check}")
            dst.commit()
        os.replace(temp, final)
    finally:
        if temp.exists():
            temp.unlink()
    for old in sorted(target_dir.glob("requiem_*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)[max(1, keep):]:
        old.unlink(missing_ok=True)
    return final


def database_health(db_path: str | Path) -> dict:
    path = Path(db_path).expanduser().resolve()
    if not path.exists():
        return {"ok": False, "exists": False, "integrity": "missing", "foreign_key_errors": 0}
    with closing(sqlite3.connect(str(path), timeout=15)) as conn:
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        foreign_errors = len(conn.execute("PRAGMA foreign_key_check").fetchall())
        return {"ok": integrity == "ok" and foreign_errors == 0, "exists": True,
                "integrity": integrity, "foreign_key_errors": foreign_errors,
                "size_bytes": path.stat().st_size}


async def backup_loop(db_path: str | Path, backup_dir: str | Path, every_hours: int = 6, keep: int = 14) -> None:
    """Periodic backup worker. The caller owns cancellation during shutdown."""
    import asyncio
    interval = max(1, int(every_hours)) * 3600
    while True:
        await asyncio.sleep(interval)
        try:
            await asyncio.to_thread(backup_database, db_path, backup_dir, keep, 0)
        except Exception:
            # The application logger records this without printing DB contents.
            import logging
            logging.getLogger("requiem.backups").exception("Scheduled SQLite backup failed")
