import asyncio
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = str(Path(os.getenv("DB_PATH", str(ROOT / "database" / "requiem.db"))).expanduser().resolve())
STREAK_BASE_REWARD = 50
STREAK_WEEKLY_BONUS = 100
STREAK_BASE_REWARD_COINS = 100
STREAK_BASE_REWARD_GEMS = 1
STREAK_WEEKLY_BONUS_COINS = 500
STREAK_WEEKLY_BONUS_GEMS = 3

RANK_TIERS = [
    (0, "المبتدئ"), (100, "القرصان"), (500, "المجرم"), (1500, "السوبرنوفا"),
    (3500, "الشيتشيبوكاي"), (7000, "الإمبراطور"), (15000, "ملك القرصان"),
]

__all__ = [
    "DB_PATH", "RANK_TIERS", "STREAK_BASE_REWARD", "STREAK_WEEKLY_BONUS",
    "calculate_rank", "init_db", "async_init_db", "get_user_data", "claim_daily_streak",
    "add_points", "add_coins", "add_gems", "remove_coins", "remove_gems", "transfer_coins", "get_economy_history", "create_shop_order",
    "get_leaderboard", "get_user_rank_position", "get_island_progress", "complete_island_stage",
    "submit_grandline_proof", "get_pending_grandline_proofs", "review_grandline_proof",
    "submit_hunter_quest", "get_pending_submissions", "get_user_submissions", "review_submission",
    "add_tournament_points", "get_tournament_leaderboard", "log_action", "get_recent_logs",
    "has_claimed_battle_pass_tier", "claim_battle_pass_tier", "set_log_channel_id", "get_log_channel_id",
    "set_image", "get_image", "get_user_daily_missions", "complete_daily_mission",
    "get_user_weekly_missions", "complete_weekly_mission"
]

def _now() -> str: return datetime.now(timezone.utc).isoformat()
def _today_utc() -> str:
    """Legacy name retained; streak day follows configured community timezone."""
    try:
        from config import TIMEZONE
        zone = ZoneInfo(TIMEZONE)
    except Exception:
        zone = ZoneInfo("Asia/Baghdad")
    return datetime.now(zone).date().isoformat()

def calculate_rank(points: int) -> str:
    rank = RANK_TIERS[0][1]
    for threshold, name in RANK_TIERS:
        if points >= threshold: rank = name
        else: break
    return rank

def _connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn

@contextmanager
def _conn():
    conn = _connect()
    try: yield conn
    finally: conn.close()

async def _run(fn, *args, **kwargs): return await asyncio.to_thread(fn, *args, **kwargs)

def _ensure_columns(conn: sqlite3.Connection, table: str, columns: Dict[str, str]) -> None:
    cur = conn.cursor()
    existing = {r["name"] for r in cur.execute(f"PRAGMA table_info({table})").fetchall()}
    for name, ddl in columns.items():
        if name not in existing: cur.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")

def _init_schema_sync() -> None:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.cursor()
            cur.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', streak INTEGER DEFAULT 0, rank TEXT DEFAULT 'المبتدئ', points INTEGER DEFAULT 0)")
            _ensure_columns(conn, "users", {"last_streak_date": "TEXT", "created_at": "TEXT", "updated_at": "TEXT", "coins": "INTEGER DEFAULT 0", "gems": "INTEGER DEFAULT 0", "bounty": "INTEGER DEFAULT 0", "daily_index": "INTEGER DEFAULT 0", "weekly_index": "INTEGER DEFAULT 0", "last_daily_reset": "TEXT", "last_weekly_reset": "TEXT"})
        
            cur.execute("CREATE TABLE IF NOT EXISTS grandline_progress (user_id INTEGER NOT NULL, island_id TEXT NOT NULL, stage INTEGER DEFAULT 0, cleared_at TEXT, updated_at TEXT, PRIMARY KEY (user_id, island_id))")
            cur.execute("CREATE TABLE IF NOT EXISTS grandline_proofs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, island_id TEXT NOT NULL, stage INTEGER NOT NULL, image_url TEXT NOT NULL, description TEXT DEFAULT '', status TEXT DEFAULT 'pending', reviewer_id INTEGER, review_note TEXT DEFAULT '', submitted_at TEXT, reviewed_at TEXT)")
            _ensure_columns(conn, "grandline_proofs", {"progress_count": "INTEGER DEFAULT 1", "required_count": "INTEGER DEFAULT 1"})
        
            cur.execute("CREATE TABLE IF NOT EXISTS hunter_submissions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, quest_id TEXT NOT NULL, quest_name TEXT NOT NULL, image_url TEXT NOT NULL, description TEXT DEFAULT '', status TEXT DEFAULT 'pending', reviewer_id INTEGER, review_note TEXT DEFAULT '', submitted_at TEXT, reviewed_at TEXT, period_key TEXT)")
            _ensure_columns(conn, "hunter_submissions", {"progress_count": "INTEGER DEFAULT 1", "required_count": "INTEGER DEFAULT 1", "period_key": "TEXT"})
        
            cur.execute("CREATE TABLE IF NOT EXISTS tournament_points (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, tournament_id TEXT NOT NULL, points INTEGER NOT NULL DEFAULT 0, reason TEXT DEFAULT '', created_at TEXT)")
            cur.execute("CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER NOT NULL, action TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at TEXT)")
            cur.execute("CREATE TABLE IF NOT EXISTS economy_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('points','coins','gems','bounty')),delta INTEGER NOT NULL CHECK(delta<>0),balance_after INTEGER NOT NULL,reason TEXT NOT NULL DEFAULT '',actor_id INTEGER,created_at TEXT NOT NULL)")
            ledger_sql = cur.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='economy_transactions'").fetchone()[0] or ""
            if "'bounty'" not in ledger_sql:
                cur.execute("ALTER TABLE economy_transactions RENAME TO economy_transactions_legacy")
                cur.execute("CREATE TABLE economy_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('points','coins','gems','bounty')),delta INTEGER NOT NULL CHECK(delta<>0),balance_after INTEGER NOT NULL,reason TEXT NOT NULL DEFAULT '',actor_id INTEGER,created_at TEXT NOT NULL)")
                cur.execute("INSERT INTO economy_transactions(id,user_id,currency,delta,balance_after,reason,actor_id,created_at) SELECT id,user_id,currency,delta,balance_after,reason,actor_id,created_at FROM economy_transactions_legacy")
                cur.execute("DROP TABLE economy_transactions_legacy")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_economy_transactions_user ON economy_transactions(user_id,id DESC)")
            cur.execute("CREATE TABLE IF NOT EXISTS shop_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,item_id TEXT NOT NULL,item_name TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('coins','gems')),cost INTEGER NOT NULL CHECK(cost>0),status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','fulfilled')),created_at TEXT NOT NULL,fulfilled_by INTEGER,fulfilled_at TEXT)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_shop_orders_status ON shop_orders(status,id DESC)")
            cur.execute("CREATE TABLE IF NOT EXISTS guild_config (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER)")
            _ensure_columns(conn, "guild_config", {"streak_channel_id": "INTEGER"})
            cur.execute("CREATE TABLE IF NOT EXISTS custom_images (id TEXT PRIMARY KEY, url TEXT)")
            cur.execute("CREATE TABLE IF NOT EXISTS discord_command_registry (scope_id INTEGER NOT NULL, command_name TEXT NOT NULL, command_id INTEGER NOT NULL, synced_at TEXT NOT NULL, PRIMARY KEY(scope_id,command_name))")
            cur.execute("CREATE TABLE IF NOT EXISTS streak_claims (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,claim_date TEXT NOT NULL,streak INTEGER NOT NULL,points_awarded INTEGER NOT NULL,coins_awarded INTEGER NOT NULL,gems_awarded INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(user_id,claim_date))")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_streak_claims_user ON streak_claims(user_id,claim_date DESC)")
            conn.commit()
        except Exception:
            conn.rollback()
            raise

def init_db() -> None: _init_schema_sync()
async def async_init_db() -> None: await _run(_init_schema_sync)

def _get_user_sync(user_id: int, username: str = "") -> Dict[str, Any]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        if row is None:
            now_iso = _now()
            cur.execute("INSERT INTO users (user_id, username, streak, rank, points, coins, gems, created_at, updated_at) VALUES (?, ?, 0, ?, 0, 0, 0, ?, ?)", (user_id, username, RANK_TIERS[0][1], now_iso, now_iso))
            cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
        elif username and row["username"] != username:
            cur.execute("UPDATE users SET username = ?, updated_at = ? WHERE user_id = ?", (username, _now(), user_id))
            cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
        return dict(row)

async def get_user_data(user_id: int, username: str = "") -> Dict[str, Any]: return await _run(_get_user_sync, user_id, username)

def _claim_daily_streak_sync(user_id: int, username: str = "") -> Dict[str, Any]:
    from datetime import timedelta
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
            today = _today_utc()
            now_iso = _now()
            
            if row is None:
                cur.execute("INSERT INTO users (user_id, username, streak, rank, points, coins, gems, created_at, updated_at) VALUES (?, ?, 0, ?, 0, 0, 0, ?, ?)", (user_id, username, RANK_TIERS[0][1], now_iso, now_iso))
                cur.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
                row = cur.fetchone()

            last_date = row["last_streak_date"]
            if last_date == today:
                conn.commit()
                return {"success": False, "reason": "already_claimed", "streak": row["streak"] or 0}
            
            # التحقق من الأيام الفائتة
            new_streak = 1
            if last_date:
                last_dt = datetime.strptime(last_date, "%Y-%m-%d").date()
                today_dt = datetime.strptime(today, "%Y-%m-%d").date()
                if today_dt - last_dt == timedelta(days=1):
                    new_streak = (row["streak"] or 0) + 1 # متتالي
            
            weekly = (new_streak % 7 == 0)
            
            # الجوائز الأساسية (50 نقطة، 100 عملة، 1 جوهرة)
            awarded = 50 + (100 if weekly else 0)
            coins_awarded = 100 + (500 if weekly else 0)
            gems_awarded = 1 + (3 if weekly else 0)
            
            new_points = (row["points"] or 0) + awarded
            new_coins = (row["coins"] or 0) + coins_awarded
            new_gems = (row["gems"] or 0) + gems_awarded
            
            cur.execute("UPDATE users SET streak = ?, points = ?, rank = ?, coins = ?, gems = ?, last_streak_date = ?, updated_at = ? WHERE user_id = ?", (new_streak, new_points, calculate_rank(new_points), new_coins, new_gems, today, now_iso, user_id))
            cur.executemany("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)", [(user_id,"points",awarded,new_points,"daily streak reward",None,now_iso),(user_id,"coins",coins_awarded,new_coins,"daily streak reward",None,now_iso),(user_id,"gems",gems_awarded,new_gems,"daily streak reward",None,now_iso)])
            cur.execute("INSERT INTO streak_claims(user_id,claim_date,streak,points_awarded,coins_awarded,gems_awarded,created_at) VALUES(?,?,?,?,?,?,?)", (user_id,today,new_streak,awarded,coins_awarded,gems_awarded,now_iso))
            if cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='achievement_catalog'").fetchone():
                from utils.competitive import _record_achievement_progress_in_connection
                _record_achievement_progress_in_connection(conn, user_id, "daily_streak", 1)
            conn.commit()
            
            return {
                "success": True, 
                "streak": new_streak, 
                "points_awarded": awarded, 
                "coins_awarded": coins_awarded,
                "gems_awarded": gems_awarded,
                "weekly_bonus": weekly
            }
        except Exception:
            conn.rollback()
            raise

async def claim_daily_streak(user_id: int, username: str = "") -> Dict[str, Any]: return await _run(_claim_daily_streak_sync, user_id, username)

def _add_points_sync(user_id: int, amount: int, reason: str = "", actor_id: Optional[int] = None) -> Dict[str, Any]:
    if isinstance(user_id,bool) or not isinstance(user_id,int) or user_id <= 0:
        raise ValueError("Invalid user id")
    if isinstance(amount,bool) or not isinstance(amount,int) or amount == 0 or abs(amount) > 10_000_000:
        raise ValueError("Invalid points amount")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur=conn.cursor()
            now_iso=_now()
            row=cur.execute("SELECT points FROM users WHERE user_id=?",(user_id,)).fetchone()
            if row is None:
                if amount < 0:
                    raise ValueError("Insufficient points")
                new_points=amount
                cur.execute("INSERT INTO users(user_id,username,streak,rank,points,coins,gems,bounty,created_at,updated_at) VALUES(?, '',0,?,?,0,0,0,?,?)",(user_id,calculate_rank(new_points),new_points,now_iso,now_iso))
            else:
                current=int(row["points"] or 0)
                if current + amount < 0:
                    raise ValueError("Insufficient points")
                new_points=current+amount
                cur.execute("UPDATE users SET points=?,rank=?,updated_at=? WHERE user_id=?",(new_points,calculate_rank(new_points),now_iso,user_id))
            cur.execute("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)",(user_id,"points",amount,new_points,(reason or "points adjustment")[:250],actor_id,now_iso))
            conn.commit()
            return {"new_points":new_points,"rank":calculate_rank(new_points)}
        except Exception:
            conn.rollback()
            raise

async def add_points(user_id: int, amount: int, reason: str = "", actor_id: Optional[int] = None) -> Dict[str, Any]: return await _run(_add_points_sync, user_id, amount, reason, actor_id)

def _economy_action_sync(user_id: int, field: str, delta: int, reason: str = "", actor_id: Optional[int] = None) -> bool:
    """Apply a signed economy delta atomically and record its resulting balance."""
    if field not in {"coins", "gems"}:
        raise ValueError("Invalid currency")
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0:
        raise ValueError("Invalid user id")
    if isinstance(delta, bool) or not isinstance(delta, int) or delta == 0 or abs(delta) > 10_000_000:
        raise ValueError("Amount must be a non-zero integer within the allowed limit")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.cursor()
            if delta < 0:
                cur.execute(f"UPDATE users SET {field}={field}+?, updated_at=? WHERE user_id=? AND {field}>=?", (delta, _now(), user_id, -delta))
            else:
                # Positive rewards may target a player who has never used the bot.
                cur.execute("INSERT OR IGNORE INTO users(user_id,username,streak,rank,points,coins,gems,bounty,created_at,updated_at) VALUES(?,?,0,?,0,0,0,0,?,?)", (user_id, "", RANK_TIERS[0][1], _now(), _now()))
                cur.execute(f"UPDATE users SET {field}={field}+?, updated_at=? WHERE user_id=?", (delta, _now(), user_id))
            if cur.rowcount != 1:
                conn.rollback()
                return False
            balance = cur.execute(f"SELECT {field} FROM users WHERE user_id=?", (user_id,)).fetchone()[0]
            cur.execute("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)", (user_id, field, delta, balance, (reason or "bot economy action")[:250], actor_id, _now()))
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            raise


def _positive_amount(amount: int) -> int:
    if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0 or amount > 10_000_000:
        raise ValueError("Amount must be a positive integer within the allowed limit")
    return amount

async def add_coins(user_id: int, amount: int) -> bool:
    return await _run(_economy_action_sync, user_id, "coins", _positive_amount(amount), "coin reward")
async def add_gems(user_id: int, amount: int) -> bool:
    return await _run(_economy_action_sync, user_id, "gems", _positive_amount(amount), "gem reward")
async def remove_coins(user_id: int, amount: int) -> bool:
    return await _run(_economy_action_sync, user_id, "coins", -_positive_amount(amount), "coin spend")
async def remove_gems(user_id: int, amount: int) -> bool:
    return await _run(_economy_action_sync, user_id, "gems", -_positive_amount(amount), "gem spend")


def _transfer_coins_sync(from_id: int, to_id: int, amount: int) -> bool:
    _positive_amount(amount)
    if isinstance(from_id, bool) or isinstance(to_id, bool) or not isinstance(from_id, int) or not isinstance(to_id, int) or from_id <= 0 or to_id <= 0:
        raise ValueError("Invalid user id")
    if from_id == to_id:
        raise ValueError("Cannot transfer coins to the same user")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.cursor()
            sender = cur.execute("SELECT coins FROM users WHERE user_id=?", (from_id,)).fetchone()
            if sender is None or int(sender["coins"] or 0) < amount:
                conn.rollback()
                return False
            now = _now()
            cur.execute("INSERT OR IGNORE INTO users(user_id,username,streak,rank,points,coins,gems,bounty,created_at,updated_at) VALUES(?,?,0,?,0,0,0,0,?,?)", (to_id, "", RANK_TIERS[0][1], now, now))
            recipient = cur.execute("SELECT coins FROM users WHERE user_id=?", (to_id,)).fetchone()
            now = _now()
            cur.execute("UPDATE users SET coins=coins-?, updated_at=? WHERE user_id=? AND coins>=?", (amount, now, from_id, amount))
            if cur.rowcount != 1:
                conn.rollback()
                return False
            cur.execute("UPDATE users SET coins=coins+?, updated_at=? WHERE user_id=?", (amount, now, to_id))
            sender_balance = cur.execute("SELECT coins FROM users WHERE user_id=?", (from_id,)).fetchone()[0]
            recipient_balance = cur.execute("SELECT coins FROM users WHERE user_id=?", (to_id,)).fetchone()[0]
            cur.executemany("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)", [(from_id,"coins",-amount,sender_balance,f"transfer to {to_id}",from_id,now),(to_id,"coins",amount,recipient_balance,f"transfer from {from_id}",from_id,now)])
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            raise

async def transfer_coins(from_id: int, to_id: int, amount: int) -> bool:
    return await _run(_transfer_coins_sync, from_id, to_id, amount)


def _get_economy_history_sync(user_id: int, limit: int = 30) -> List[Dict[str, Any]]:
    if isinstance(limit, bool) or not isinstance(limit, int):
        limit = 30
    limit = max(1, min(limit, 100))
    with _conn() as conn:
        rows = conn.execute("SELECT id,user_id,currency,delta,balance_after,reason,actor_id,created_at FROM economy_transactions WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit)).fetchall()
        return [dict(row) for row in rows]

async def get_economy_history(user_id: int, limit: int = 30) -> List[Dict[str, Any]]:
    return await _run(_get_economy_history_sync, user_id, limit)

def _create_shop_order_sync(user_id: int, item_id: str, item_name: str, currency: str, cost: int) -> Optional[int]:
    if currency not in {"coins", "gems"}:
        raise ValueError("Invalid shop currency")
    cost = _positive_amount(cost)
    if isinstance(user_id,bool) or not isinstance(user_id,int) or user_id <= 0:
        raise ValueError("Invalid user id")
    item_id = str(item_id or "").strip()[:80]
    item_name = str(item_name or "").strip()[:120]
    if not item_id or not item_name:
        raise ValueError("Invalid shop item")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur=conn.cursor()
            cur.execute(f"UPDATE users SET {currency}={currency}-?,updated_at=? WHERE user_id=? AND {currency}>=?",(cost,_now(),user_id,cost))
            if cur.rowcount != 1:
                conn.rollback()
                return None
            now=_now()
            cur.execute("INSERT INTO shop_orders(user_id,item_id,item_name,currency,cost,status,created_at) VALUES(?,?,?,?,?,'pending',?)",(user_id,item_id,item_name,currency,cost,now))
            order_id=cur.lastrowid
            balance=cur.execute(f"SELECT {currency} FROM users WHERE user_id=?",(user_id,)).fetchone()[0]
            cur.execute("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)",(user_id,currency,-cost,balance,f"shop order #{order_id}: {item_name}",None,now))
            conn.commit()
            return int(order_id)
        except Exception:
            conn.rollback()
            raise

async def create_shop_order(user_id: int, item_id: str, item_name: str, currency: str, cost: int) -> Optional[int]:
    return await _run(_create_shop_order_sync,user_id,item_id,item_name,currency,cost)


def _get_leaderboard_sync(limit: int, offset: int, order: str) -> List[Dict[str, Any]]:
    order_sql = {"points": "points DESC", "streak": "streak DESC", "coins": "coins DESC", "bounty": "bounty DESC"}.get(order, "points DESC")
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT user_id, username, points, streak, coins, gems, bounty, rank FROM users ORDER BY {order_sql}, user_id ASC LIMIT ? OFFSET ?", (limit, offset))
        return [dict(r) for r in cur.fetchall()]

async def get_leaderboard(limit: int = 10, offset: int = 0, order: str = "points") -> List[Dict[str, Any]]: return await _run(_get_leaderboard_sync, limit, offset, order)

def _get_user_rank_position_sync(user_id: int, order: str) -> Optional[int]:
    order_col = "points" if order == "points" else "streak"
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT rnk FROM (SELECT user_id, RANK() OVER (ORDER BY {order_col} DESC) AS rnk FROM users) WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        return row["rnk"] if row else None

async def get_user_rank_position(user_id: int, order: str = "points") -> Optional[int]: return await _run(_get_user_rank_position_sync, user_id, order)

def _get_island_progress_sync(user_id: int) -> Dict[str, int]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT island_id, stage FROM grandline_progress WHERE user_id = ?", (user_id,))
        return {r["island_id"]: r["stage"] for r in cur.fetchall()}

async def get_island_progress(user_id: int) -> Dict[str, int]: return await _run(_get_island_progress_sync, user_id)

def _complete_island_stage_sync(user_id: int, island_id: str, stage: int) -> Dict[str, Any]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT stage FROM grandline_progress WHERE user_id = ? AND island_id = ?", (user_id, island_id))
        row = cur.fetchone()
        now_iso = _now()
        if row is None: cur.execute("INSERT INTO grandline_progress (user_id, island_id, stage, cleared_at, updated_at) VALUES (?, ?, ?, ?, ?)", (user_id, island_id, stage, now_iso, now_iso))
        else:
            new_stage = max(row["stage"], stage)
            cur.execute("UPDATE grandline_progress SET stage = ?, cleared_at = ?, updated_at = ? WHERE user_id = ? AND island_id = ?", (new_stage, now_iso, now_iso, user_id, island_id))
        conn.commit()
        cur.execute("SELECT stage FROM grandline_progress WHERE user_id = ? AND island_id = ?", (user_id, island_id))
        return {"island_id": island_id, "stage": cur.fetchone()["stage"]}

async def complete_island_stage(user_id: int, island_id: str, stage: int) -> Dict[str, Any]: return await _run(_complete_island_stage_sync, user_id, island_id, stage)

def _submit_grandline_proof_sync(user_id: int, island_id: str, stage: int, image_url: str, description: str = "", progress_count: int = 1, required_count: int = 1) -> int:
    if isinstance(progress_count, bool) or isinstance(required_count, bool) or not 1 <= int(progress_count) <= 100 or not 1 <= int(required_count) <= 100:
        raise ValueError("Invalid proof progress count")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            mission = conn.execute("SELECT required_count,active FROM dashboard_missions WHERE island_id=? AND stage=?", (island_id, stage)).fetchone()
            if not mission or not mission["active"]:
                raise LookupError("Mission not found or inactive")
            expected = conn.execute("SELECT COALESCE(MAX(stage),0)+1 FROM grandline_progress WHERE user_id=? AND island_id=?", (user_id, island_id)).fetchone()[0]
            if int(stage) != int(expected):
                raise ValueError(f"Complete stage {expected} before submitting this stage")
            if int(required_count) != int(mission["required_count"] or 1):
                raise ValueError("Mission proof count does not match the configured requirement")
            pending = conn.execute("SELECT 1 FROM grandline_proofs WHERE user_id=? AND island_id=? AND stage=? AND status='pending' LIMIT 1", (user_id, island_id, stage)).fetchone()
            approved = conn.execute("SELECT COALESCE(SUM(COALESCE(progress_count,1)),0) FROM grandline_proofs WHERE user_id=? AND island_id=? AND stage=? AND status='approved'", (user_id, island_id, stage)).fetchone()[0]
            if pending:
                raise ValueError("You already have a pending proof for this stage")
            if int(approved) >= int(required_count):
                raise ValueError("This stage has already been completed")
            cur = conn.execute("INSERT INTO grandline_proofs (user_id, island_id, stage, image_url, description, status, submitted_at, progress_count, required_count) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?)", (user_id, island_id, stage, image_url, description, _now(), int(progress_count), int(required_count)))
            conn.commit()
            return cur.lastrowid
        except Exception:
            conn.rollback()
            raise

async def submit_grandline_proof(user_id: int, island_id: str, stage: int, image_url: str, description: str = "", progress_count: int = 1, required_count: int = 1) -> int:
    return await _run(_submit_grandline_proof_sync, user_id, island_id, stage, image_url, description, progress_count, required_count)

def _get_pending_grandline_proofs_sync(limit: int) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM grandline_proofs WHERE status = 'pending' ORDER BY submitted_at ASC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]

async def get_pending_grandline_proofs(limit: int = 50) -> List[Dict[str, Any]]: return await _run(_get_pending_grandline_proofs_sync, limit)

def _review_grandline_proof_sync(proof_id: int, status: str, reviewer_id: int, note: str = "") -> Dict[str, Any]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM grandline_proofs WHERE id = ? AND status = 'pending'", (proof_id,))
        row = cur.fetchone()
        if not row: return {"success": False, "reason": "not_found"}
        cur.execute("UPDATE grandline_proofs SET status = ?, reviewer_id = ?, review_note = ?, reviewed_at = ? WHERE id = ?", (status, reviewer_id, note, _now(), proof_id))
        conn.commit()
        return {"success": True, "user_id": row["user_id"]}

async def review_grandline_proof(proof_id: int, status: str, reviewer_id: int, note: str = "") -> Dict[str, Any]: return await _run(_review_grandline_proof_sync, proof_id, status, reviewer_id, note)

def _submit_hunter_quest_sync(user_id: int, quest_id: str, quest_name: str, image_url: str, description: str = "", period_key: Optional[str] = None, progress_count: int = 1, required_count: int = 1) -> int:
    if isinstance(progress_count, bool) or isinstance(required_count, bool) or not 1 <= int(progress_count) <= 100 or not 1 <= int(required_count) <= 100:
        raise ValueError("Invalid proof progress count")
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        if quest_id in {"daily", "weekly"} and period_key:
            pending = conn.execute("SELECT 1 FROM hunter_submissions WHERE user_id=? AND quest_id=? AND quest_name=? AND period_key=? AND status='pending' LIMIT 1", (user_id, quest_id, quest_name, period_key)).fetchone()
            approved = conn.execute("SELECT COALESCE(SUM(COALESCE(progress_count,1)),0) FROM hunter_submissions WHERE user_id=? AND quest_id=? AND quest_name=? AND period_key=? AND status='approved'", (user_id, quest_id, quest_name, period_key)).fetchone()[0]
            if pending:
                raise ValueError("لديك إثبات معلق لهذه المهمة ضمن الفترة الحالية")
            if int(approved) >= int(required_count):
                raise ValueError("سبق أن أكملت هذه المهمة ضمن الفترة الحالية")
            configured = conn.execute("SELECT required_count FROM hunter_submissions WHERE user_id=? AND quest_id=? AND quest_name=? AND period_key=? LIMIT 1", (user_id, quest_id, quest_name, period_key)).fetchone()
            if configured and int(configured["required_count"] or 1) != int(required_count):
                raise ValueError("متطلبات المهمة تغيرت أثناء وجود تقدم مسجل")
        cur = conn.cursor()
        cur.execute("INSERT INTO hunter_submissions (user_id, quest_id, quest_name, image_url, description, status, submitted_at, period_key, progress_count, required_count) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)", (user_id, quest_id, quest_name, image_url, description, _now(), period_key, int(progress_count), int(required_count)))
        conn.commit()
        return cur.lastrowid

async def submit_hunter_quest(user_id: int, quest_id: str, quest_name: str, image_url: str, description: str = "", period_key: Optional[str] = None, progress_count: int = 1, required_count: int = 1) -> int:
    return await _run(_submit_hunter_quest_sync, user_id, quest_id, quest_name, image_url, description, period_key, progress_count, required_count)

def _get_pending_submissions_sync(limit: int) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM hunter_submissions WHERE status = 'pending' ORDER BY submitted_at ASC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]

async def get_pending_submissions(limit: int = 50) -> List[Dict[str, Any]]: return await _run(_get_pending_submissions_sync, limit)

def _get_user_submissions_sync(user_id: int, limit: int) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM hunter_submissions WHERE user_id = ? ORDER BY submitted_at DESC LIMIT ?", (user_id, limit))
        return [dict(r) for r in cur.fetchall()]

async def get_user_submissions(user_id: int, limit: int = 20) -> List[Dict[str, Any]]: return await _run(_get_user_submissions_sync, user_id, limit)

def _review_submission_sync(proof_id: int, status: str, reviewer_id: int, note: str = "") -> Dict[str, Any]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM hunter_submissions WHERE id = ? AND status = 'pending'", (proof_id,))
        row = cur.fetchone()
        if not row: return {"success": False, "reason": "not_found"}
        cur.execute("UPDATE hunter_submissions SET status = ?, reviewer_id = ?, review_note = ?, reviewed_at = ? WHERE id = ?", (status, reviewer_id, note, _now(), proof_id))
        conn.commit()
        return {"success": True, "user_id": row["user_id"]}

async def review_submission(proof_id: int, status: str, reviewer_id: int, note: str = "") -> Dict[str, Any]: return await _run(_review_submission_sync, proof_id, status, reviewer_id, note)

def _set_log_channel_sync(guild_id: int, channel_id: int):
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO guild_config (guild_id, log_channel_id) VALUES (?, ?)", (guild_id, channel_id))

async def set_log_channel_id(guild_id: int, channel_id: int): await _run(_set_log_channel_sync, guild_id, channel_id)

def _get_log_channel_sync(guild_id: int) -> Optional[int]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT log_channel_id FROM guild_config WHERE guild_id = ?", (guild_id,))
        row = cur.fetchone()
        return row["log_channel_id"] if row else None

async def get_log_channel_id(guild_id: int) -> Optional[int]: return await _run(_get_log_channel_sync, guild_id)

def _set_image_sync(item_id: str, url: str):
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO custom_images (id, url) VALUES (?, ?)", (item_id, url))

async def set_image(item_id: str, url: str): await _run(_set_image_sync, item_id, url)

def _get_image_sync(item_id: str) -> Optional[str]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT url FROM custom_images WHERE id = ?", (item_id,))
        row = cur.fetchone()
        return row["url"] if row else None

async def get_image(item_id: str) -> Optional[str]: return await _run(_get_image_sync, item_id)

async def get_user_daily_missions(user_id: int) -> list:
    data = await get_user_data(user_id)
    today = _today_utc()
    index = int(data.get("daily_index", 0) or 0) if data.get("last_daily_reset") == today else 0
    descriptions = ["العب 3 مباريات في الليج", "احصل على 5 قتلات (KOs)", "أكمل Treasure Map واحدة"]
    return [{"id": str(i), "mission_text": text, "reward": 1, "completed": i < index} for i, text in enumerate(descriptions)]

async def complete_daily_mission(user_id: int, mission_id: str) -> bool:
    # Daily missions advance only after a reviewed proof, never through a client-side claim.
    return False

async def get_user_weekly_missions(user_id: int) -> list:
    data = await get_user_data(user_id)
    week_key = datetime.now(timezone.utc).strftime("%G-W%V")
    index = int(data.get("weekly_index", 0) or 0) if data.get("last_weekly_reset") == week_key else 0
    descriptions = ["العب 15 مباراة في الليج", "احصل على 5 مرات MVP", "أكمل 5 مهام يومية"]
    return [{"id": str(i), "mission_text": text, "reward": 5, "completed": i < index} for i, text in enumerate(descriptions)]

async def complete_weekly_mission(user_id: int, mission_id: str) -> bool:
    # Weekly missions advance only after a reviewed proof.
    return False

def _add_tournament_points_sync(user_id: int, tournament_id: str, amount: int, reason: str = "") -> Dict[str, Any]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO tournament_points (user_id, tournament_id, points, reason, created_at) VALUES (?, ?, ?, ?, ?)", (user_id, tournament_id, amount, reason, _now()))
        conn.commit()
        return {"user_id": user_id, "tournament_id": tournament_id, "amount": amount}

async def add_tournament_points(user_id: int, tournament_id: str, amount: int, reason: str = "") -> Dict[str, Any]: 
    return await _run(_add_tournament_points_sync, user_id, tournament_id, amount, reason)

def _get_tournament_leaderboard_sync(tournament_id: str, limit: int) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT tp.user_id, COALESCE(u.username, '') AS username, SUM(tp.points) AS total FROM tournament_points tp LEFT JOIN users u ON u.user_id = tp.user_id WHERE tp.tournament_id = ? GROUP BY tp.user_id ORDER BY total DESC LIMIT ?", (tournament_id, limit))
        return [dict(r) for r in cur.fetchall()]

async def get_tournament_leaderboard(tournament_id: str, limit: int = 10) -> List[Dict[str, Any]]: 
    return await _run(_get_tournament_leaderboard_sync, tournament_id, limit)

def _log_action_sync(actor_id: int, action: str, target_id: Optional[int], details: str):
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO audit_logs (actor_id, action, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)", (actor_id, action, target_id, details, _now()))

async def log_action(actor_id: int, action: str, target_id: Optional[int] = None, details: str = ""): 
    await _run(_log_action_sync, actor_id, action, target_id, details)

def _get_recent_logs_sync(limit: int) -> List[Dict[str, Any]]:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in cur.fetchall()]

async def get_recent_logs(limit: int = 50) -> List[Dict[str, Any]]: 
    return await _run(_get_recent_logs_sync, limit)

def _has_claimed_bp_tier_sync(user_id: int, tier: int) -> bool:
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM audit_logs WHERE actor_id = ? AND action = 'battle_pass_claim' AND details LIKE ? LIMIT 1", (user_id, f"tier={tier}%"))
        return cur.fetchone() is not None

async def has_claimed_battle_pass_tier(user_id: int, tier: int) -> bool: 
    return await _run(_has_claimed_bp_tier_sync, user_id, tier)

def _claim_bp_tier_sync(user_id: int, tier: int, reward_points: int) -> dict:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM audit_logs WHERE actor_id = ? AND action = 'battle_pass_claim' AND details LIKE ? LIMIT 1", (user_id, f"tier={tier}%"))
            if cur.fetchone(): return {"success": False, "reason": "already_claimed"}
            cur.execute("SELECT points FROM users WHERE user_id = ?", (user_id,))
            row = cur.fetchone()
            if row is None: return {"success": False, "reason": "user_not_found"}
            new_points = (row["points"] or 0) + reward_points
            cur.execute("UPDATE users SET points = ?, rank = ?, updated_at = ? WHERE user_id = ?", (new_points, calculate_rank(new_points), _now(), user_id))
            cur.execute("INSERT INTO audit_logs (actor_id, action, target_id, details, created_at) VALUES (?, 'battle_pass_claim', ?, ?, ?)", (user_id, user_id, f"tier={tier} reward={reward_points}", _now()))
            conn.commit()
            return {"success": True, "new_points": new_points}
        except Exception:
            conn.rollback()
            raise

async def claim_battle_pass_tier(user_id: int, tier: int, reward_points: int) -> dict: 
    return await _run(_claim_bp_tier_sync, user_id, tier, reward_points)

# ================== League System ==================

def _init_league_tables_sync():
    with _conn() as conn:
        cur = conn.cursor()
        # جدول التحديات المباشرة
        cur.execute("""
            CREATE TABLE IF NOT EXISTS league_challenges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                challenger_id INTEGER NOT NULL,
                opponent_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                status TEXT DEFAULT 'pending',
                winner_id INTEGER,
                created_at TEXT
            )
        """)
        # جدول البطولات
        cur.execute("""
            CREATE TABLE IF NOT EXISTS tournaments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                size INTEGER NOT NULL,
                creator_id INTEGER NOT NULL,
                status TEXT DEFAULT 'registration',
                created_at TEXT
            )
        """)
        # جدول المشاركين في البطولة
        cur.execute("""
            CREATE TABLE IF NOT EXISTS tournament_players (
                tournament_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                PRIMARY KEY (tournament_id, user_id)
            )
        """)

async def init_league_tables():
    await _run(_init_league_tables_sync)

def _get_league_rank_sync(points: int) -> str:
    if points >= 5000: return "👑 Champion"
    if points >= 3500: return "💎 Diamond"
    if points >= 2000: return "💠 Platinum"
    if points >= 1000: return "🥇 Gold"
    if points >= 500: return "🥈 Silver"
    return "🥉 Bronze"

async def get_league_rank(points: int) -> str:
    return await _run(_get_league_rank_sync, points)

def _create_tournament_sync(name: str, size: int, creator_id: int) -> int:
    if size not in {4, 8, 16, 32}:
        raise ValueError("Tournament size must be 4, 8, 16, or 32")
    if not name or not name.strip() or len(name.strip()) > 100:
        raise ValueError("Tournament name must be 1-100 characters")
    with _conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO tournaments (name, size, creator_id, status, created_at) VALUES (?, ?, ?, 'registration', ?)", (name, size, creator_id, _now()))
        conn.commit()
        return cur.lastrowid

async def create_tournament(name: str, size: int, creator_id: int) -> int:
    return await _run(_create_tournament_sync, name, size, creator_id)

def _join_tournament_sync(tournament_id: int, user_id: int) -> bool:
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.cursor()
            cur.execute("SELECT size, status FROM tournaments WHERE id = ?", (tournament_id,))
            tournament = cur.fetchone()
            if not tournament or tournament["status"] != "registration":
                conn.rollback()
                return False
            count = cur.execute("SELECT COUNT(*) FROM tournament_players WHERE tournament_id = ?", (tournament_id,)).fetchone()[0]
            if count >= tournament["size"]:
                conn.rollback()
                return False
            cur.execute("INSERT INTO tournament_players (tournament_id, user_id) VALUES (?, ?)", (tournament_id, user_id))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            conn.rollback()
            return False
        except Exception:
            conn.rollback()
            raise

async def join_tournament(tournament_id: int, user_id: int) -> bool:
    return await _run(_join_tournament_sync, tournament_id, user_id)

# ================== Shortcuts ==================
def _init_shortcuts_sync():
    with _conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS shortcuts (
                trigger_text TEXT PRIMARY KEY,
                action_type TEXT NOT NULL,
                action_data TEXT
            )
        """)
        # إضافة اختصارات افتراضية
        conn.execute("INSERT OR IGNORE INTO shortcuts (trigger_text, action_type, action_data) VALUES ('t', 'text', '✅ البوت يعمل بشكل ممتاز!')")
        conn.execute("INSERT OR IGNORE INTO shortcuts (trigger_text, action_type, action_data) VALUES ('p', 'command', 'profile')")
        conn.execute("INSERT OR IGNORE INTO shortcuts (trigger_text, action_type, action_data) VALUES ('#test', 'text', '✅ هذا اختصار مخصص من الموقع!')")
        conn.commit()

async def init_shortcuts():
    await _run(_init_shortcuts_sync)

def _get_shortcuts_sync():
    with _conn() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM shortcuts").fetchall()]

async def get_shortcuts():
    return await _run(_get_shortcuts_sync)

def _save_shortcut_sync(trigger: str, action_type: str, action_data: str):
    with _conn() as conn:
        conn.execute("INSERT OR REPLACE INTO shortcuts (trigger_text, action_type, action_data) VALUES (?, ?, ?)", (trigger.lower().strip(), action_type, action_data))
        conn.commit()

async def save_shortcut(trigger: str, action_type: str, action_data: str):
    await _run(_save_shortcut_sync, trigger, action_type, action_data)

def _delete_shortcut_sync(trigger: str):
    with _conn() as conn:
        conn.execute("DELETE FROM shortcuts WHERE trigger_text = ?", (trigger.lower().strip(),))
        conn.commit()

async def delete_shortcut(trigger: str):
    await _run(_delete_shortcut_sync, trigger)

# ── Persisted Discord Slash Command registry ───────────────────────────────
def _save_synced_commands_sync(scope_id: int, commands: list[dict[str, Any]]) -> int:
    if isinstance(scope_id, bool) or not isinstance(scope_id, int) or scope_id < 0:
        raise ValueError("Invalid command scope")
    now = _now()
    with _conn() as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute("DELETE FROM discord_command_registry WHERE scope_id=?", (scope_id,))
            saved = 0
            for item in commands:
                name = str(item.get("name") or "").strip()[:120]
                command_id = item.get("id")
                if name and isinstance(command_id, int) and command_id > 0:
                    conn.execute("INSERT INTO discord_command_registry(scope_id,command_name,command_id,synced_at) VALUES(?,?,?,?)", (scope_id, name, command_id, now))
                    saved += 1
            conn.commit()
            return saved
        except Exception:
            conn.rollback()
            raise

async def save_synced_commands(scope_id: int, commands: list[dict[str, Any]]) -> int:
    return await _run(_save_synced_commands_sync, scope_id, commands)

def _get_synced_command_id_sync(command_name: str, guild_id: int = 0) -> Optional[int]:
    with _conn() as conn:
        row = conn.execute("SELECT command_id FROM discord_command_registry WHERE scope_id IN (?,0) AND command_name=? ORDER BY scope_id DESC LIMIT 1", (guild_id, command_name)).fetchone()
        return int(row["command_id"]) if row else None

async def get_synced_command_id(command_name: str, guild_id: int = 0) -> Optional[int]:
    return await _run(_get_synced_command_id_sync, command_name, guild_id)


def _get_streak_history_sync(user_id: int, limit: int = 30) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 100))
    with _conn() as conn:
        return [dict(r) for r in conn.execute("SELECT claim_date,streak,points_awarded,coins_awarded,gems_awarded,created_at FROM streak_claims WHERE user_id=? ORDER BY claim_date DESC LIMIT ?", (user_id, limit)).fetchall()]

async def get_streak_history(user_id: int, limit: int = 30) -> list[dict[str, Any]]:
    return await _run(_get_streak_history_sync, user_id, limit)
