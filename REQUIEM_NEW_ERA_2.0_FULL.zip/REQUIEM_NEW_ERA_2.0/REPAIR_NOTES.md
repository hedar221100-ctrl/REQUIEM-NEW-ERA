# REQUIEM: NEW ERA 2.0 — Audit & Repair Notes

## Baseline audit
- Source archive integrity: ZIP CRC test passed.
- The supplied archive contained 57 files across 69 ZIP entries and no live `.db`, `.sqlite`, or `.sqlite3` database.
- The project uses Python/Discord.py, FastAPI, SQLite, and a static JavaScript/CSS/HTML dashboard.
- Baseline test suite before this change: 30 pytest tests passed; Python compileall passed.
- `discord.py` was not installed in the build environment. Discord Gateway, OAuth with real credentials, and real interaction callbacks were not executed.

## Changes in 2.0

### Economy and data safety
- Positive rewards create a wallet for a player who has never invoked the bot.
- Positive dashboard adjustments initialize a wallet after verifying the target is a member of the selected Discord guild; negative adjustments still require sufficient balance.
- Coin transfers create a recipient wallet atomically and preserve ledger entries.
- Existing schema initialization now runs in a SQLite `BEGIN IMMEDIATE` transaction.
- SQLite-consistent pre-migration backups, integrity checking, periodic backups, and retention were added.
- Streak claims are recorded in `streak_claims`; the daily boundary uses configured `TIMEZONE` (default `Asia/Baghdad`).

### Discord shortcuts
- Synced Slash Command IDs are persisted per global/guild scope.
- Shortcut responses use official command mentions only when a synced ID exists; shortcuts do not invoke a Slash Command on behalf of a player.
- A protected command synchronization endpoint was added.

### Competitive engine
- Separate General and Tournament ELO ratings.
- 1v1 matchmaking queue, queue status recovery, duplicate-match prevention, rivals, match history, and analytics.
- Ranked proof submissions enter the existing shared proof review queue; ELO is changed only after staff approval.
- Direct challenges and tournament results update their corresponding ELO mode after approval.
- Tournament size 32 is supported in the single-elimination bracket path.
- Daily/weekly/seasonal/permanent achievement catalog, hidden achievements, progress triggers, titles/badges metadata, and one-time reward claims.
- Black Market cosmetic items, daily/weekly/seasonal/permanent rotations, atomic purchases, inventory, and equip-by-category.
- Wanted Board, weekly/monthly winners, season archive snapshots, and Hall of Fame queries.
- Rule-based high-win-rate flags are review-only; no automatic bans are performed.

### Web and staff experience
- A player portal is separated from the staff dashboard.
- Dashboard sections were added for competitive rankings, Wanted Board, market/inventory, achievements, tournaments, challenges, streaks, announcements, and audit logs.
- Staff access supports Discord role IDs and optional user ID allowlists for Owner/Admin/Moderator/Proof Reviewer.
- Member lookup can search the selected guild and initialize a wallet for a member who has not used the bot.
- Economy supply and 7-day net ledger movement are exposed to staff.
- Original project assets and uploads were retained; two REQUIEM promotional poster assets were added.

## Test results in the build environment
- `pytest -q`: 51 tests passed.
- `python test_phase1.py`: ALL PASSED.
- `python -m unittest discover -s tests -v`: 17 tests passed (the run emitted non-fatal SQLite ResourceWarnings from existing tests).
- `python -m compileall -q .`: passed.
- `node --check web/static/app.js`: passed.
- `node --check web/static/player.js`: passed.
- FastAPI app import and OpenAPI generation: passed; 65 OpenAPI paths at the time of audit.

## Known limitations / deployment validation
- The original ZIP did not include a live database file. Do not point `DB_PATH` at a new empty file if production data exists; set it to the original production SQLite file. The code creates a pre-migration backup when that file exists.
- Discord Gateway commands, persistent Discord components, OAuth2 role lookup, announcement delivery, and Discord member search require a real bot token, OAuth client, and test guild. They were not run in this environment.
- Group-stage then knockout tournaments are not implemented; current tournaments are single-elimination.
- Ranked proof handling currently accepts one proof submission per match and treats the submitter as the proposed winner. There is no separate ranked counter-proof/appeal workflow yet; staff must verify the screenshot before approval.
- Anti-Smurf is a review signal only (90%+ win rate after 10 approved General matches), not an automated detection verdict or ban.
- Achievement progress only advances for wired events (ranked/tournament wins and matches, streak claims, approved proofs, completed Grand Line and Battle Pass missions). Other custom triggers require an event integration.
- Shop rotations require staff to create and tag cosmetic items; the catalog starts empty and items are cosmetic only.
- Season archives snapshot current ELO at archive time; they do not reconstruct historic rankings from older records.
