"""الإعدادات: كلشي ينقرا من متغيرات البيئة. التوكن ما ينكتب بالكود أبداً."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("DB_PATH", str(BASE_DIR / "database" / "requiem.db"))).resolve()
BACKUP_DIR = BASE_DIR / "database" / "backups"
ASSETS_DIR = BASE_DIR / "assets"

TOKEN = os.getenv("DISCORD_TOKEN", "")
TIMEZONE = os.getenv("TIMEZONE", "Asia/Baghdad")
BACKUP_EVERY_HOURS = max(1, int(os.getenv("BACKUP_EVERY_HOURS", "6")))
KEEP_BACKUPS = max(1, int(os.getenv("KEEP_BACKUPS", "14")))
