"""صلاحيات الأوامر الإدارية."""
import discord
from discord import app_commands


def is_admin(interaction: discord.Interaction) -> bool:
    perms = getattr(interaction.user, "guild_permissions", None)
    return bool(perms and (perms.administrator or perms.manage_guild))


def admin_only():
    """يمنع الأعضاء العاديين من استخدام الأمر."""
    async def check(interaction: discord.Interaction) -> bool:
        if is_admin(interaction):
            return True
        raise app_commands.CheckFailure("هذا الأمر للإدارة فقط 🚫")
    return app_commands.check(check)
