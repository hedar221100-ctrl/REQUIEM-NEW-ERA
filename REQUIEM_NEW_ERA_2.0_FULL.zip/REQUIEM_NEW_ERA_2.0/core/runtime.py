"""Shared runtime references when the bot and dashboard run in one process."""
bot = None
