import sqlite3, tempfile, pathlib
from database import db

tmp = pathlib.Path(tempfile.mkdtemp()); p = tmp / "t.db"
db.init_db(p); db.init_db(p)  # مرتين: ما يضيع شي
with db.tx(p) as c:
    tables = {r[0] for r in c.execute("select name from sqlite_master where type='table'")}
need = {"users","factions","islands","missions","mission_submissions","proofs","tournaments","tournament_matches","seasons","battle_pass_progress","achievements","rewards","events","audit_logs","progress_ledger","settings"}
assert need <= tables, need - tables
print("1) الجداول كلها موجودة")

with db.tx(p) as c:
    c.execute("insert into users(discord_id,display_name) values (1,'luffy')")
    db.log_action(c, 1, "test", "x")
db.init_db(p)
with db.tx(p) as c:
    assert c.execute("select count(*) from users").fetchone()[0] == 1
print("2) إعادة التشغيل ما تمسح البيانات")

with db.tx(p) as c:
    c.execute("insert into proofs(submitter_id,image_sha256) values (1,'abc')")
try:
    with db.tx(p) as c:
        c.execute("insert into proofs(submitter_id,image_sha256) values (2,'abc')")
    raise SystemExit("FAIL")
except sqlite3.IntegrityError:
    print("3) نفس الصورة انرفضت")

with db.tx(p) as c:
    c.execute("insert into progress_ledger(event_key,user_id,source,xp) values ('m1:u1',1,'mission',50)")
try:
    with db.tx(p) as c:
        c.execute("insert into progress_ledger(event_key,user_id,source,xp) values ('m1:u1',1,'mission',50)")
    raise SystemExit("FAIL")
except sqlite3.IntegrityError:
    print("4) الإنجاز ما ينحسب مرتين")

try:
    with db.tx(p) as c:
        c.execute("insert into users(discord_id) values (99)")
        raise RuntimeError("boom")
except RuntimeError:
    pass
with db.tx(p) as c:
    assert c.execute("select count(*) from users where discord_id=99").fetchone()[0] == 0
print("5) الخطأ يرجّع العملية (rollback)")

b = tmp / "bk"
for _ in range(5): db.backup(p, b, keep=3)
files = list(b.glob("*.db")); assert len(files) == 3
chk = sqlite3.connect(files[-1]); assert chk.execute("select count(*) from users").fetchone()[0] == 1; chk.close()
print("6) النسخ الاحتياطي يشتغل ويحذف القديم")
print("ALL PASSED")
