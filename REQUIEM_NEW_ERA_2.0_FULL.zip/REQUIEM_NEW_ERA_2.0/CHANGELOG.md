# سجل التغييرات — REQUIEM: NEW ERA 2.0

## 2.0.0 — 2026-11-06

### Added
- Competitive engine: General ELO, Tournament ELO, reviewed ranked matches, and rating leaderboards.
- 1v1 matchmaking queue, rivals, player analytics, and player-facing Discord commands.
- Black Market cosmetic catalog, idempotent purchases, inventory, and equip-by-category.
- Achievement catalog with daily, weekly, seasonal, permanent, hidden achievements, progress triggers, and one-time claims.
- Competitive seasons, archive snapshots, Wanted Board, and hall-of-fame query support.
- Player portal separated from the staff dashboard.
- Discord role-based Owner/Admin/Moderator/Proof Reviewer authorization.
- Persisted Slash Command ID registry and a protected command synchronization endpoint.
- SQLite-consistent backups, integrity checks, periodic backups, and a retention policy.
- Streak claim history and Baghdad-configured local-day calculation.
- New integration and regression tests.

### Fixed
- Positive coin/gem/points rewards can create a wallet for a new player.
- Positive admin economy adjustments can initialize a wallet after confirming guild membership.
- Discord member search now queries cached/server members and initializes their wallet when selected.
- Coin transfers create a recipient wallet atomically.
- Tournament size 32 is accepted by the bracket registration/start path.
- Competitive proof results enter the existing admin proof review queue; ELO changes only after approval.
- Challenge and tournament approvals update their separate ELO modes.
- Command shortcuts show the official Slash Command mention only when a synced command ID is persisted; they never invoke Slash Commands on behalf of a player.

### Notes / limitations
- The source ZIP contained no live SQLite database file. Existing production DB data must be supplied at deployment via the original `DB_PATH`.
- Discord Gateway, real OAuth, and real guild interactions require deployment credentials and were not exercised in this build environment.
- Group-stage tournaments, ranked dispute workflow, and fully automatic anti-smurf enforcement are not implemented; anti-smurf is review-only.
