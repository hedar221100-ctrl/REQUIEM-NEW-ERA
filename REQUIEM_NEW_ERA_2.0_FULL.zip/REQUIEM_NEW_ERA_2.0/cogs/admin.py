import asyncio
import discord
from discord.ext import commands
from discord import app_commands
from utils.db import set_image
from web.store import review_proof, edit_mission_description

COLOR_SUCCESS = 0x2ECC71
COLOR_DANGER = 0xE74C3C
COLOR_GOLD = 0xD5AE69

def is_guild_admin(interaction: discord.Interaction) -> bool:
    return bool(interaction.guild and (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator))

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="review", description="عرض تعليمات مراجعة إثباتات اللاعبين")
    @app_commands.default_permissions(manage_guild=True)
    async def review(self, interaction: discord.Interaction):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server.", ephemeral=True)
        await interaction.response.send_message(
            "⚓ **مركز مراجعة REQUIEM**\nتظهر الإثباتات في لوحة التحكم، ويمكن أيضاً مراجعة الرسائل التي أرسلها البوت إلى قناة السجلات.\n\n"
            "افتح Dashboard → Review Proofs لقبول أو رفض الإثباتات. تُصرف المكافآت مرة واحدة فقط.",
            ephemeral=True,
        )

    @app_commands.command(name="add_image", description="إضافة صورة لشخصية أو جزيرة")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(item_id="معرّف الشخصية أو الجزيرة")
    async def add_image(self, interaction: discord.Interaction, item_id: str):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server.", ephemeral=True)
        await interaction.response.send_message(f"📸 ارفع صورة واحدة لـ `{item_id}` في هذه القناة خلال 60 ثانية.", ephemeral=True)
        try:
            msg = await self.bot.wait_for("message", timeout=60.0, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel_id and any((a.content_type or "").startswith("image/") for a in m.attachments))
            attachment = next(a for a in msg.attachments if (a.content_type or "").startswith("image/"))
            await set_image(item_id, attachment.url)
            await msg.reply("✅ تم حفظ الصورة بنجاح.")
        except asyncio.TimeoutError:
            await interaction.followup.send("⌛ انتهى الوقت. حاول مرة أخرى.", ephemeral=True)

    @app_commands.command(name="edit_mission", description="تعديل نص مهمة في إحدى الجزر")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(island_id="معرّف الجزيرة", stage="رقم المرحلة", description="النص الجديد للمهمة")
    async def edit_mission(self, interaction: discord.Interaction, island_id: str, stage: app_commands.Range[int, 1, 100], description: str):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server.", ephemeral=True)
        if len(description.strip()) < 3 or len(description) > 1000:
            return await interaction.response.send_message("❌ يجب أن يكون وصف المهمة بين 3 و1000 حرف.", ephemeral=True)
        try:
            await edit_mission_description(island_id, stage, description.strip())
            await interaction.response.send_message(f"✅ تم تحديث المهمة رقم **{stage}** في `{island_id}`.", ephemeral=True)
        except LookupError:
            await interaction.response.send_message("❌ لم أجد هذه الجزيرة أو المهمة.", ephemeral=True)

class AdminReviewView(discord.ui.View):
    def __init__(self, proof_type: str, proof_id: int):
        super().__init__(timeout=None)
        self.proof_type = proof_type
        self.proof_id = proof_id
        self._reviewed = False
        # Unique persistent component IDs let Discord route old review messages
        # after a bot restart without confusing two different proof records.
        action_ids = {"موافقة ✅": "approve", "قبول مؤقت (تقدم)": "progress", "رفض ❌": "reject"}
        for child in self.children:
            suffix = action_ids.get(child.label)
            if suffix:
                child.custom_id = f"requiem_review:{proof_type}:{proof_id}:{suffix}"
            if child.label == "قبول مؤقت (تقدم)" and proof_type != "grandline":
                child.disabled = True

    @discord.ui.button(label="موافقة ✅", style=discord.ButtonStyle.success, custom_id="admin_approve")
    async def approve_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server لمراجعة الإثباتات.", ephemeral=True)
        if self._reviewed:
            return await interaction.response.send_message("تمت مراجعة هذا الإثبات مسبقاً.", ephemeral=True)
        await interaction.response.defer()
        try:
            result = await review_proof(self.proof_type, self.proof_id, "approved", interaction.user.id, "تمت الموافقة عبر Discord")
        except LookupError:
            return await interaction.followup.send("⚠️ هذا الإثبات تمت مراجعته مسبقاً أو لم يعد موجوداً.", ephemeral=True)
        
        self._reviewed = True
        for child in self.children:
            child.disabled = True
        if interaction.message:
            await interaction.message.edit(view=self)
            
        reward = result["reward"]
        if self.proof_type == "competitive":
            message = f"⚔️ تمت مراجعة نتيجة Ranked.\n📈 ELO: {reward.get('elo_delta_p1', 0)} / {reward.get('elo_delta_p2', 0)}"
        elif self.proof_type == "league":
            message = f"⚔️ تمت الموافقة على نتيجة المباراة.\n🏆 **+{reward['tournament_points']} نقطة بطولة** · 🪙 **+{reward['coins']:,} عملة**"
        elif self.proof_type == "battle_pass" and reward.get("mission_progress"):
            progress = reward["mission_progress"]
            message = f"🎟️ تقدم مهمة Battle Pass: **{progress['current']}/{progress['required']}**"
            if progress["completed"]:
                message += f"\n🎁 المكافأة: ⭐ {reward['points']:,} · 🪙 {reward['coins']:,} · 💎 {reward['gems']:,}"
        elif self.proof_type == "streak":
            message = f"🔥 تمت الموافقة على تحدي الستريك.\n⭐ **+{reward['points']:,} نقطة** · 🪙 **+{reward['coins']:,} عملة** · 💎 **+{reward['gems']:,} جوهرة**"
        elif self.proof_type == "grandline" and reward.get("mission_progress"):
            progress = reward["mission_progress"]
            message = f"🗺️ تقدم المهمة: **{progress['current']}/{progress['required']}**"
            if progress["completed"]:
                message += f"\n🎁 المكافأة: ⭐ {reward['points']:,} · 🪙 {reward['coins']:,} · 💎 {reward['gems']:,}"
        else:
            message = (f"⭐ **+{reward['points']:,} نقطة** · 🪙 **+{reward['coins']:,} عملة** · 💎 **+{reward['gems']:,} جوهرة**")
            
        await interaction.followup.send("✅ تمت الموافقة وصرف المكافأة.\n" + message)
        await self._notify_player(interaction, result["user_id"], True, reward, "")

    @discord.ui.button(label="قبول مؤقت (تقدم)", style=discord.ButtonStyle.primary, custom_id="admin_progress", emoji="⏳")
    async def progress_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server.", ephemeral=True)
        if self._reviewed:
            return await interaction.response.send_message("تمت مراجعة هذا الإثبات مسبقاً.", ephemeral=True)
        
        await interaction.response.defer()
        try:
            if self.proof_type != "grandline":
                return await interaction.followup.send("⚠️ هذا الخيار مخصص لمراحل Grand Line متعددة الإثباتات.", ephemeral=True)
            result = await review_proof(self.proof_type, self.proof_id, "approved", interaction.user.id, "تم اعتماد الإثبات كتقدم عبر Discord")
            self._reviewed = True
            for child in self.children:
                child.disabled = True
            if interaction.message:
                await interaction.message.edit(view=self)
            progress = result["reward"].get("mission_progress") or {}
            message = f"✅ تم قبول الإثبات. التقدم الحالي **{progress.get('current', 1)}/{progress.get('required', 1)}**."
            if progress.get("completed"):
                reward = result["reward"]
                message += f"\n🎁 اكتملت المهمة وصُرفت المكافأة: ⭐ {reward['points']:,} · 🪙 {reward['coins']:,} · 💎 {reward['gems']:,}"
            await interaction.followup.send(message)
            await self._notify_player(interaction, result["user_id"], True, result["reward"], "")
        except LookupError as e:
            await interaction.followup.send(f"⚠️ {str(e)}", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"⚠️ خطأ غير متوقع: {str(e)}", ephemeral=True)

    @discord.ui.button(label="رفض ❌", style=discord.ButtonStyle.danger, custom_id="admin_reject")
    async def reject_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server لمراجعة الإثباتات.", ephemeral=True)
        if self._reviewed:
            return await interaction.response.send_message("تمت مراجعة هذا الإثبات مسبقاً.", ephemeral=True)
        await interaction.response.send_modal(RejectReasonModal(self.proof_type, self.proof_id, self))

    async def _notify_player(self, interaction, user_id, approved, reward=None, reason=""):
        try:
            user = await interaction.client.fetch_user(user_id)
            if approved:
                if self.proof_type == "competitive":
                    await user.send(f"⚔️ **تمت مراجعة نتيجة Ranked!**\n📈 تغيّر ELO للاعبين: {reward.get('elo_delta_p1', 0)} / {reward.get('elo_delta_p2', 0)}")
                elif self.proof_type == "league":
                    await user.send(f"🎉 **تم قبول إثبات مباراة الليج!**\n🏆 +{reward['tournament_points']} نقطة بطولة\n🪙 +{reward['coins']:,} عملة")
                elif self.proof_type == "battle_pass" and reward.get("mission_progress"):
                    progress = reward["mission_progress"]
                    detail = f"تقدم المهمة: {progress['current']}/{progress['required']}"
                    if progress["completed"]:
                        detail += f"\n🎁 ⭐ +{reward['points']:,} · 🪙 +{reward['coins']:,} · 💎 +{reward['gems']:,}"
                    await user.send(f"🎟️ **تم قبول إثبات مهمة Battle Pass!**\n{detail}")
                elif self.proof_type == "streak":
                    await user.send(f"🔥 **تم قبول تحدي الستريك!**\n⭐ +{reward['points']:,} نقطة\n🪙 +{reward['coins']:,} عملة\n💎 +{reward['gems']:,} جوهرة")
                elif self.proof_type == "grandline" and reward.get("mission_progress"):
                    progress = reward["mission_progress"]
                    detail = f"تقدم المهمة: {progress['current']}/{progress['required']}"
                    if progress["completed"]:
                        detail += f"\n🎁 ⭐ +{reward['points']:,} · 🪙 +{reward['coins']:,} · 💎 +{reward['gems']:,}"
                    await user.send(f"🗺️ **تم اعتماد إثبات Grand Line!**\n{detail}")
                else:
                    await user.send(f"🎉 **تم قبول إثباتك في REQUIEM!**\n⭐ +{reward['points']:,} نقطة\n🪙 +{reward['coins']:,} عملة\n💎 +{reward['gems']:,} جوهرة")
            else:
                await user.send(f"❌ **تم رفض إثباتك في REQUIEM.**\n**السبب:** {reason}")
        except (discord.Forbidden, discord.HTTPException):
            pass

class RejectReasonModal(discord.ui.Modal):
    def __init__(self, proof_type, proof_id, parent_view):
        super().__init__(title="سبب رفض الإثبات")
        self.proof_type = proof_type
        self.proof_id = proof_id
        self.parent_view = parent_view
        self.reason_input = discord.ui.TextInput(label="سبب الرفض", required=True, max_length=300, style=discord.TextStyle.paragraph, placeholder="اكتب سبباً واضحاً للاعب...")
        self.add_item(self.reason_input)

    async def on_submit(self, interaction: discord.Interaction):
        if not is_guild_admin(interaction):
            return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server.", ephemeral=True)
        if self.parent_view._reviewed:
            return await interaction.response.send_message("تمت مراجعة هذا الإثبات مسبقاً.", ephemeral=True)
        reason = self.reason_input.value.strip()
        try:
            result = await review_proof(self.proof_type, self.proof_id, "rejected", interaction.user.id, reason)
        except LookupError:
            return await interaction.response.send_message("⚠️ هذا الإثبات تمت مراجعة مسبقاً أو لم يعد موجوداً.", ephemeral=True)
        self.parent_view._reviewed = True
        for child in self.parent_view.children:
            child.disabled = True
        if interaction.message:
            await interaction.message.edit(view=self.parent_view)
        await interaction.response.send_message("✅ تم رفض الإثبات وتسجيل السبب.", ephemeral=True)
        await self.parent_view._notify_player(interaction, result["user_id"], False, reason=reason)

async def setup(bot):
    await bot.add_cog(AdminCog(bot))