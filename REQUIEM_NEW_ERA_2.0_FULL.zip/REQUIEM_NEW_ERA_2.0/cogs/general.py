from __future__ import annotations

import asyncio
from datetime import datetime, timezone, timedelta
from typing import List, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.db import (
    get_user_data, claim_daily_streak, add_points,
    get_leaderboard, get_user_rank_position,
    get_island_progress, complete_island_stage,
    submit_hunter_quest, get_user_submissions,
    get_tournament_leaderboard,
    RANK_TIERS, STREAK_BASE_REWARD, STREAK_WEEKLY_BONUS,
    get_log_channel_id
)

DAILY_MISSIONS = [
    {"desc": "العب 3 مباريات في الليج", "required": 3},
    {"desc": "احصل على 5 قتلات (KOs)", "required": 1},
    {"desc": "أكمل Treasure Map واحده", "required": 1}
]

WEEKLY_MISSIONS = [
    {"desc": "العب 15 مباراة في الليج", "required": 15},
    {"desc": "احصل على 5 مرات MVP", "required": 5},
    {"desc": "أكمل 5 مهام يومية", "required": 5}
]

CHARACTERS = {
    "luffy_g5": {"name": "Luffy (Gear 5)", "type": "Extreme", "class": "Runner", "element": "Dark", "img": "https://static.wikia.nocookie.net/onepiece/images/7/7c/Monkey_D._Luffy_Anime_Post_Timeskip_Infobox.png"},
    "kaido": {"name": "Kaido", "type": "Extreme", "class": "Defender", "element": "Blue", "img": "https://static.wikia.nocookie.net/onepiece/images/9/9e/Kaido_Anime_Infobox.png"},
    "shanks": {"name": "Shanks", "type": "Extreme", "class": "Runner", "element": "Light", "img": "https://static.wikia.nocookie.net/onepiece/images/6/6d/Shanks_Anime_Infobox.png"},
    "blackbeard": {"name": "Blackbeard", "type": "Extreme", "class": "Attacker", "element": "Dark", "img": "https://static.wikia.nocookie.net/onepiece/images/3/3f/Marshall_D._Teach_Anime_Infobox.png"},
    "whitebeard": {"name": "Whitebeard", "type": "Extreme", "class": "Runner", "element": "Light", "img": "https://static.wikia.nocookie.net/onepiece/images/4/4c/Edward_Newgate_Anime_Infobox.png"},
    "roger": {"name": "Gol D. Roger", "type": "Extreme", "class": "Attacker", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/0/0e/Gol_D._Roger_Anime_Infobox.png"},
    "big_mom": {"name": "Big Mom", "type": "Bounty Fest", "class": "Defender", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/6/6b/Charlotte_Linlin_Anime_Infobox.png"},
    "katakuri": {"name": "Katakuri", "type": "Bounty Fest", "class": "Runner", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/1/1b/Charlotte_Katakuri_Anime_Infobox.png"},
    "king": {"name": "King", "type": "Bounty Fest", "class": "Runner", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/0/0c/King_Anime_Infobox.png"},
    "yamato": {"name": "Yamato", "type": "Bounty Fest", "class": "Attacker", "element": "Blue", "img": "https://static.wikia.nocookie.net/onepiece/images/9/9a/Yamato_Anime_Infobox.png"},
    "law": {"name": "Trafalgar Law", "type": "Bounty Fest", "class": "Runner", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/6/6f/Trafalgar_D._Water_Law_Anime_Infobox.png"},
    "kid": {"name": "Eustass Kid", "type": "Bounty Fest", "class": "Attacker", "element": "Blue", "img": "https://static.wikia.nocookie.net/onepiece/images/1/1d/Eustass_Kid_Anime_Infobox.png"},
    "zoro": {"name": "Roronoa Zoro", "type": "Bounty Fest", "class": "Attacker", "element": "Green", "img": "https://static.wikia.nocookie.net/onepiece/images/1/1b/Roronoa_Zoro_Anime_Post_Timeskip_Infobox.png"},
    "sanji": {"name": "Vinsmoke Sanji", "type": "Bounty Fest", "class": "Attacker", "element": "Blue", "img": "https://static.wikia.nocookie.net/onepiece/images/2/2c/Vinsmoke_Sanji_Anime_Post_Timeskip_Infobox.png"},
    "ace": {"name": "Portgas D. Ace", "type": "Bounty Fest", "class": "Attacker", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/3/3e/Portgas_D._Ace_Anime_Infobox.png"},
    "marco": {"name": "Marco", "type": "Bounty Fest", "class": "Defender", "element": "Blue", "img": "https://static.wikia.nocookie.net/onepiece/images/4/4c/Marco_Anime_Infobox.png"},
    "oden": {"name": "Kozuki Oden", "type": "Bounty Fest", "class": "Attacker", "element": "Red", "img": "https://static.wikia.nocookie.net/onepiece/images/7/7c/Kozuki_Oden_Anime_Infobox.png"},
    "sabo": {"name": "Sabo", "type": "Bounty Fest", "class": "Runner", "element": "Green", "img": "https://static.wikia.nocookie.net/onepiece/images/8/8d/Sabo_Anime_Infobox.png"},
    "doflamingo": {"name": "Doflamingo", "type": "Bounty Fest", "class": "Attacker", "element": "Blue", "img": "https://static.wikia.nocookie.net/onepiece/images/7/7b/Donquixote_Doflamingo_Anime_Infobox.png"},
}

ISLANDS = [
    {
        "id": "logue_town", "name": "Logue Town", "emoji": "🏘️", "min_points": 0, "desc": "بداية الرحلة ونهاية العصر الذهبي للقراصنة.",
        "missions": [
            {"desc": "احصل على 5 قتلات (KOs) في مباراة واحدة. (ارفع صورة شاشة النتائج)", "character": None, "alternatives": []},
            {"desc": "اعبأ شريط العلم (Flag Gauge) مرة واحدة على الأقل. (ارفع صورة شاشة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز في مباراة الليج. (ارفع صورة شاشة الانتصار)", "character": None, "alternatives": []}
        ]
    },
    {
        "id": "reverse_mountain", "name": "Reverse Mountain", "emoji": "⛰️", "min_points": 100, "desc": "بوابة الـ Grand Line، حيث تتلاقى البحار.",
        "missions": [
            {"desc": "أخذ العلم (Capture Flag) 3 مرات في مباراة. (ارفع صورة شاشة النتائج)", "character": None, "alternatives": []},
            {"desc": "احصل على 10 قتلات (KOs) في مباراة الليج. (ارفع صورة شاشة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز في مباراة باستخدام Law وفريقك يضمه. (ارفع صورة التشكيلة والنتائج)", "character": "law", "alternatives": ["kid", "zoro"]}
        ]
    },
    {
        "id": "whiskey_peak", "name": "Whiskey Peak", "emoji": "🏔️", "min_points": 250, "desc": "جزيرة جواسيس Baroque Works.",
        "missions": [
            {"desc": "احصل على لقب MVP في مباراة الليج. (ارفع صورة شاشة الـ MVP)", "character": None, "alternatives": []},
            {"desc": "اعبأ شريط العلم (Fill Gauge) مرتين في مباراة. (ارفع صورة شاشة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز في مباراة الليج وفريقك يضم Sanji. (ارفع صورة التشكيلة والنتائج)", "character": "sanji", "alternatives": ["zoro", "ace"]}
        ]
    },
    {
        "id": "little_garden", "name": "Little Garden", "emoji": "🌴", "min_points": 500, "desc": "أرض العمالقة من عصر القراصنة القدامى.",
        "missions": [
            {"desc": "أنهِ مباراة كـ Defender واحصل على 5 قتلات. (ارفع صورة النتائج)", "character": "big_mom", "alternatives": ["kaido", "marco"]},
            {"desc": "فز في مباراة الليج وفريقك يضم Luffy (Gear 5). (ارفع صورة التشكيلة والنتائج)", "character": "luffy_g5", "alternatives": ["kaido", "shanks"]},
            {"desc": "احصل على 8 قتلات (KOs) في مباراة تحالف (Alliance). (ارفع صورة شاشة النتائج)", "character": None, "alternatives": []}
        ]
    },
    {
        "id": "drum_island", "name": "Drum Island", "emoji": "❄️", "min_points": 800, "desc": "مملكة الثلج والطبيب الساحر.",
        "missions": [
            {"desc": "أخذ العلم (Capture Flag) 5 مرات في مباراة واحدة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز في مباراة الليج وفريقك يضم Ace. (ارفع صورة التشكيلة والنتائج)", "character": "ace", "alternatives": ["sabo", "marco"]},
            {"desc": "احصل على لقب MVP مرتين كـ Attacker. (ارفع صور شاشات الـ MVP)", "character": None, "alternatives": []}
        ]
    },
    {
        "id": "alabasta", "name": "Alabasta", "emoji": "🏜️", "min_points": 1200, "desc": "مملكة الصحراء ومعركة Baroque Works الكبرى.",
        "missions": [
            {"desc": "احصل على 15 قتلة (KO) في مباراة واحدة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز 3 مرات وفريقك يضم Shanks. (ارفع صور التشكيلة والنتائج)", "character": "shanks", "alternatives": ["roger", "blackbeard"]},
            {"desc": "اعبأ شريط العلم بالكامل (100% Flag Gauge) في مباراة. (ارفع صورة النتائج)", "character": "whitebeard", "alternatives": ["roger"]}
        ]
    },

    {
        "id": "skypiea", "name": "Skypiea", "emoji": "☁️", "min_points": 1800, "desc": "أرض السماء وقصة النار الذهبية.",
        "missions": [
            {"desc": "فز في مباراة الـ Boss (Enel) وفريقك يضم Luffy. (ارفع صورة الانتصار)", "character": "luffy_g5", "alternatives": ["kaido", "shanks"]},
            {"desc": "احصل على 20 قتلة (KO) في مباراة واحدة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "أخذ العلم 7 مرات في مباراة تحالف. (ارفع صورة النتائج)", "character": "ace", "alternatives": ["sabo", "marco"]}
        ]
    },
    {
        "id": "water_7", "name": "Water 7", "emoji": "🌊", "min_points": 2500, "desc": "مدينة الصناعة ومقر حكومة العالم.",
        "missions": [
            {"desc": "فز 5 مرات في الليج وفريقك يضم Yamato. (ارفع صور النتائج)", "character": "yamato", "alternatives": ["katakuri"]},
            {"desc": "اعبأ شريط العلم 3 مرات في مباراة واحدة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز في مباراة ضد الـ CP9 وفريقك يضم Law. (ارفع صورة الانتصار)", "character": "law", "alternatives": ["zoro", "sanji"]}
        ]
    },
    {
        "id": "enies_lobby", "name": "Enies Lobby", "emoji": "⚖️", "min_points": 3500, "desc": "معركة إنقاذ الرفيق ضد الـ CP9.",
        "missions": [
            {"desc": "احصل على MVP 3 مرات وفريقك يضم Big Mom. (ارفع صور MVP)", "character": "big_mom", "alternatives": ["kaido", "marco"]},
            {"desc": "احصل على 25 قتلة (KO) في مباراة واحدة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "فز 3 مرات في الليج وفريقك يضم Luffy (Gear 5). (ارفع صور النتائج)", "character": "luffy_g5", "alternatives": ["kaido", "shanks"]}
        ]
    },
    {
        "id": "thriller_bark", "name": "Thriller Bark", "emoji": "💀", "min_points": 4500, "desc": "سفينة الأشباح العائمة.",
        "missions": [
            {"desc": "اهزم Moria في البوس وفريقك يضم King. (ارفع صورة الانتصار)", "character": "king", "alternatives": ["katakuri", "yamato"]},
            {"desc": "أخذ العلم (Capture Flag) 10 مرات في مباراة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "أكمل Treasure Map وفريقك يضم Oden. (ارفع صورة المكافآت)", "character": "oden", "alternatives": ["ace", "marco"]}
        ]
    },
    {
        "id": "marineford", "name": "Marineford", "emoji": "⚔️", "min_points": 6000, "desc": "حرب القمة — أعظم معركة في التاريخ.",
        "missions": [
            {"desc": "فز 10 مرات في الليج وفريقك يضم Shanks. (ارفع صور النتائج)", "character": "shanks", "alternatives": ["luffy_g5"]},
            {"desc": "احصل على 30 قتلة (KO) في مباراة واحدة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "اهزم Whitebeard في البوس وفريقك يضم Kaido. (ارفع صورة الانتصار)", "character": "kaido", "alternatives": ["big_mom", "luffy_g5"]}
        ]
    },
    {
        "id": "wano", "name": "Wano", "emoji": "🌸", "min_points": 8000, "desc": "أرض الساموراي ومعركة الأباطرة.",
        "missions": [
            {"desc": "فز 15 مرة في الليج وفريقك يضم Luffy (Gear 5). (ارفع صور النتائج)", "character": "luffy_g5", "alternatives": ["shanks", "kaido"]},
            {"desc": "احصل على 40 قتلة (KO) واعبأ العلم 5 مرات في مباراة. (ارفع صورة النتائج)", "character": None, "alternatives": []},
            {"desc": "اهزم Kaido في الـ Boss وفريقك يضم Yamato. (ارفع صورة الانتصار)", "character": "yamato", "alternatives": ["katakuri"]}
        ]
    }
]

HUNTER_QUESTS = [
    {"id": "hq_01", "name": "صيد في East Blue", "reward_coins": 500, "reward_gems": 1, "desc": "احصل على 10 قتلات (KOs) في مباريات الليج."},
    {"id": "hq_02", "name": "صائد المكافآت البرونزي", "reward_coins": 800, "reward_gems": 1, "desc": "أخذ العلم (Capture Flag) 5 مرات."},
    {"id": "hq_03", "name": "تحالف الـ Alliance", "reward_coins": 1000, "reward_gems": 2, "desc": "اعبأ شريط العلم بالكامل (100% Gauge)."},
    {"id": "hq_04", "name": "أسطورة الـ Treasure Map", "reward_coins": 1500, "reward_gems": 2, "desc": "احصل على 15 قتلة (KO) في مباراة."},
    {"id": "hq_05", "name": "بطل الـ Boss Battle", "reward_coins": 2000, "reward_gems": 3, "desc": "احصل على لقب MVP في مباراة الليج."},
    {"id": "hq_06", "name": "ملك الستريك الأسبوعي", "reward_coins": 3000, "reward_gems": 5, "desc": "حافظ على ستريك 7 أيام متتالية في البوت."},
]

BATTLE_PASS_TIERS = [
    {"tier": 1, "required": 300, "reward": 100, "label": "🪙 حقيبة عملات"},
    {"tier": 2, "required": 600, "reward": 150, "label": "💎 كيس جواهر"},
    {"tier": 3, "required": 1000, "reward": 250, "label": "🏅 لقب Supernova"},
    {"tier": 4, "required": 1500, "reward": 400, "label": "🔥 لقب Warlord"},
    {"tier": 5, "required": 2500, "reward": 600, "label": "👑 لقب Emperor"},
    {"tier": 6, "required": 4000, "reward": 900, "label": "⚓ لقب Pirate King"},
    {"tier": 7, "required": 6000, "reward": 1500, "label": "🌋 لقب Legend"},
]

CURRENT_TOURNAMENT_ID = "season_1_requiem"
LEADERBOARD_PAGE_SIZE = 10
LEAGUE_PAGE_SIZE = 10
COLOR_MAIN, COLOR_SUCCESS, COLOR_DANGER, COLOR_GOLD, COLOR_OCEAN = 0xE67E22, 0x2ECC71, 0xE74C3C, 0xF1C40F, 0x3498DB

def _today_utc(): return datetime.now(timezone.utc).date().isoformat()
def _can_claim_today(d): return not d or d != _today_utc()
def _format_medal(p): return {1: "🥇", 2: "🥈", 3: "🥉"}.get(p, f"`#{p}`")
def _find_island(i_id): return next((i for i in ISLANDS if i["id"] == i_id), None)
def _find_quest(q_id): return next((q for q in HUNTER_QUESTS if q["id"] == q_id), None)
def _set_button_state(v, c_id, dis):
    for c in v.children:
        if getattr(c, "custom_id", None) == c_id and isinstance(c, discord.ui.Button): c.disabled = dis
def _next_rank_info(p):
    for t, n in RANK_TIERS:
        if t > p: return {"name": n, "remaining": t - p}
    return None

class GeneralCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setup", description="تحديد قناة السجلات وقناة الستريك")
    @app_commands.default_permissions(manage_guild=True)
    async def setup_logs(self, interaction: discord.Interaction, log_channel: discord.TextChannel, streak_channel: discord.TextChannel):
      if not interaction.guild or not (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator):
          return await interaction.response.send_message("❌ تحتاج صلاحية Manage Server.", ephemeral=True)
      from utils.db import _conn
      with _conn() as conn:
          conn.execute("CREATE TABLE IF NOT EXISTS guild_config (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER, streak_channel_id INTEGER)")
          conn.execute(
              "INSERT INTO guild_config(guild_id,log_channel_id,streak_channel_id) VALUES(?,?,?) "
              "ON CONFLICT(guild_id) DO UPDATE SET log_channel_id=excluded.log_channel_id,streak_channel_id=excluded.streak_channel_id",
              (interaction.guild_id, log_channel.id, streak_channel.id),
          )
      await interaction.response.send_message(f"✅ تم تعيين قناة السجلات إلى {log_channel.mention} وقناة الستريك إلى {streak_channel.mention}!", ephemeral=True)

    @app_commands.command(name="profile", description="عرض بطاقة اللاعب")
    async def profile(self, interaction: discord.Interaction, member: discord.Member = None):
      target = member or interaction.user
      data = await get_user_data(target.id, target.name)
      pos = await get_user_rank_position(target.id)
    
      # حساب المستوى (كل 1000 نقطة = مستوى)
      level = (data["points"] // 1000) + 1
    
      embed = discord.Embed(title=f"⚓ بروفايل: {target.display_name}", description="إحصائياتك في REQUIEM.", color=COLOR_MAIN)
      if target.display_avatar: embed.set_thumbnail(url=target.display_avatar.url)
    
      embed.add_field(name="🏆 الرتبة", value=data["rank"], inline=True)
      embed.add_field(name="📊 المستوى", value=f"Level {level}", inline=True)
      embed.add_field(name="🔥 الستريك اليومي", value=f"{data['streak']} يوم", inline=True)
    
      embed.add_field(name="☠ Bounty", value=f"{data.get('bounty', 0):,}", inline=True)
      embed.add_field(name="⭐ نقاط الترتيب", value=f"{data['points']:,}", inline=True)
      embed.add_field(name="🪙 العملات", value=f"{data.get('coins', 0):,}", inline=True)
      embed.add_field(name="💎 الجواهر", value=f"{data.get('gems', 0):,}", inline=True)
    
      if pos: 
          embed.add_field(name="📊 المركز", value=_format_medal(pos), inline=True)
        
      nxt = _next_rank_info(data["points"])
      if nxt: 
          embed.add_field(name="🎯 القادم", value=f"**{nxt['name']}** — باقي **{nxt['remaining']}**", inline=False)
        
      embed.set_footer(text="REQUIEM: NEW ERA")
    
      can_claim = (target.id == interaction.user.id and _can_claim_today(data["last_streak_date"]))
      await interaction.response.send_message(embed=embed, view=ProfileView(target.id, can_claim))

    @app_commands.command(name="grandline", description="خريطة المغامرة")
    async def grandline(self, interaction: discord.Interaction):
        data = await get_user_data(interaction.user.id, interaction.user.name)
        progress = await get_island_progress(interaction.user.id)
        cleared = sum(1 for i in ISLANDS if i["missions"] and progress.get(i["id"], 0) >= len(i["missions"]))
        unlocked = sum(1 for i in ISLANDS if data["points"] >= i["min_points"])
        embed = discord.Embed(title="🗺️ GRAND LINE", description=f"الجزر المفتوحة: **{unlocked}/{len(ISLANDS)}**\nالجزر المكتملة: **{cleared}/{len(ISLANDS)}**\nنقاطك: **{data['points']}**", color=COLOR_OCEAN)
        await interaction.response.send_message(embed=embed, view=GrandLineMapView(data["points"], progress))

    @app_commands.command(name="hunters", description="مهام الصيادين")
    async def hunters(self, interaction: discord.Interaction):
        embed = discord.Embed(title="🏹 LEGEND HUNTERS", description="ارفع إثباتاتك من زر رفع الإثبات.", color=COLOR_SUCCESS)
        for q in HUNTER_QUESTS: embed.add_field(name=f"📜 {q['name']}", value=f"{q['desc']}\n**المكافأة:** {q['reward_coins']} 🪙 + {q['reward_gems']} 💎", inline=False)          
        await interaction.response.send_message(embed=embed, view=HuntersMainView(interaction.user.id))

    @app_commands.command(name="pass", description="الباس")
    async def battle_pass(self, interaction: discord.Interaction):
      from web.store import get_bp_tiers, has_claimed_bp_tier
      data = await get_user_data(interaction.user.id, interaction.user.name)
      tiers = await get_bp_tiers()
      claimed = [t["tier"] for t in tiers if await has_claimed_bp_tier(interaction.user.id, t["tier"])]
    
      embed = discord.Embed(title="🎁 BATTLE PASS", description=f"نقاطك: **{data['points']}**", color=COLOR_GOLD)
      for t in tiers:
          status = "✅ مستلم" if t["tier"] in claimed else ("🎁 متاح" if data["points"] >= t["required_points"] else f"🔒 يحتاج {t['required_points']}")
          embed.add_field(name=f"Tier {t['tier']} — {t['label']}", value=f"{status}\n🪙 {t['reward_coins']} | 💎 {t['reward_gems']}", inline=False)
        
      view = BattlePassView(interaction.user.id, data["points"], tiers, claimed)
      await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="leaderboard", description="الصدارة")
    @app_commands.choices(order=[app_commands.Choice(name="💎 نقاط الترتيب", value="points"), app_commands.Choice(name="☠ Bounty", value="bounty"), app_commands.Choice(name="⭐ الستريك", value="streak"), app_commands.Choice(name="🪙 العملات", value="coins")])
    async def leaderboard(self, interaction: discord.Interaction, order: app_commands.Choice[str] = None):
        view = LeaderboardView(order.value if order else "points", interaction.user.id)
        embed, has_next = await view.build_page()
        view.sync_buttons(has_next)
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="daily", description="عرض المهام اليومية")
    async def daily(self, interaction: discord.Interaction):
      daily_period_key = _today_utc()
      data = await get_user_data(interaction.user.id, interaction.user.name)
      today = _today_utc()
      daily_idx = data.get("daily_index", 0)
    
      if data.get("last_daily_reset") != today:
          daily_idx = 0
          from utils.db import _conn
          with _conn() as conn:
              conn.execute("UPDATE users SET daily_index=0, last_daily_reset=? WHERE user_id=?", (today, interaction.user.id))
    
      if daily_idx >= len(DAILY_MISSIONS):
          return await interaction.response.send_message("✅ لقد أكملت جميع المهام اليومية! عد غداً.", ephemeral=True)
        
      current_mission = DAILY_MISSIONS[daily_idx]
      req = current_mission.get("required", 1)
     
      embed = discord.Embed(title="📅 المهام اليومية", description=f"المهمة الحالية ({daily_idx + 1}/{len(DAILY_MISSIONS)}):\n**{current_mission['desc']}**\n\n(تتطلب **{req}** إثباتات)", color=COLOR_GOLD)
    
      view = discord.ui.View()
      btn = discord.ui.Button(label="رفع إثبات المهمة", style=discord.ButtonStyle.success, emoji="📸")
    
      async def submit_callback(inter: discord.Interaction):
          await inter.response.send_message(f"📸 **المهمة تتطلب ({req}) صور. يمكنك إرسالها كلها في رسالة واحدة أو صورة تلو الأخرى.**", ephemeral=False)
        
          images = []
          seen_hashes = set()
        
          while len(images) < req:
              try:
                  msg = await inter.client.wait_for("message", timeout=120.0, check=lambda m: m.author.id == inter.user.id and m.channel.id == inter.channel.id and any((a.content_type or '').startswith('image/') for a in m.attachments))
                  for attachment in msg.attachments:
                      if len(images) >= req: break
                      if not (attachment.content_type or '').startswith('image/'):
                          continue
                    
                      # منع التكرار باستخدام الرابط
                      if attachment.url in seen_hashes:
                          await msg.reply("⚠️ لقد أرسلت هذه الصورة مسبقاً. يرجى إرسال صورة مختلفة.")
                          continue
                      
                      seen_hashes.add(attachment.url)
                      images.append(attachment.url)
                     
                  if len(images) < req:
                      await msg.reply(f"✅ تم استلام ({len(images)}/{req}). أرسل الصور المتبقية.")
              except asyncio.TimeoutError:
                  return await inter.followup.send(f"❌ انتهى الوقت. أرسلت {len(images)} من أصل {req} صور.", ephemeral=True)
         
          # حفظ الإثبات في قاعدة البيانات
          submission_id = await submit_hunter_quest(inter.user.id, "daily", current_mission["desc"], images[0], "daily_mission", daily_period_key, len(images), req)
          await inter.followup.send("✅ تم استلام جميع الصور. سيتم مراجعتها من قبل الإدارة.", ephemeral=True)
        
          # إرسال الإشعار لقناة السجلات
          log_channel_id = await get_log_channel_id(inter.guild.id)
          if log_channel_id:
              log_channel = inter.guild.get_channel(log_channel_id)
              if log_channel:
                  from cogs.admin import AdminReviewView
                
                  # إنشاء إمبيدات متعددة لعرض الصور كصور حقيقية
                  embeds = []
                  for i, url in enumerate(images):
                      emb = discord.Embed(url="https://requiem.bot", title=f"إثبات المهمة اليومية - صورة {i+1}")
                      emb.set_image(url=url)
                      embeds.append(emb)
                 
                  log_embed = discord.Embed(title="📸 إثبات مهام يومية", color=COLOR_GOLD)
                  log_embed.add_field(name="اللاعب", value=inter.user.mention)
                  log_embed.add_field(name="المهمة", value=current_mission["desc"])
                  log_embed.add_field(name="عدد الصور", value=str(len(images)))
                 
                  view = AdminReviewView(proof_type="hunter", proof_id=submission_id)
                  await log_channel.send(embeds=[log_embed] + embeds, view=view)
                
      btn.callback = submit_callback
      view.add_item(btn)
      await interaction.response.send_message(embed=embed, view=view) 

    @app_commands.command(name="weekly", description="عرض المهام الأسبوعية")
    async def weekly(self, interaction: discord.Interaction):
        week_key = datetime.now(timezone.utc).strftime("%G-W%V")
        data = await get_user_data(interaction.user.id, interaction.user.name)
        weekly_idx = int(data.get("weekly_index", 0) or 0)
        if data.get("last_weekly_reset") != week_key:
            weekly_idx = 0
            from utils.db import _conn
            with _conn() as conn:
                conn.execute("UPDATE users SET weekly_index=0, last_weekly_reset=? WHERE user_id=?", (week_key, interaction.user.id))

        if weekly_idx >= len(WEEKLY_MISSIONS):
            return await interaction.response.send_message("✅ لقد أكملت جميع المهام الأسبوعية!", ephemeral=True)

        current_mission = WEEKLY_MISSIONS[weekly_idx]
        required = int(current_mission.get("required", 1))
        embed = discord.Embed(
            title="📆 المهام الأسبوعية",
            description=f"المهمة الحالية ({weekly_idx + 1}/{len(WEEKLY_MISSIONS)}):\n**{current_mission['desc']}**\n\nتتطلب **{required}** إثباتات.",
            color=COLOR_OCEAN,
        )
        view = discord.ui.View(timeout=180)
        button = discord.ui.Button(label="رفع إثبات المهمة", style=discord.ButtonStyle.success, emoji="📸")

        async def submit_callback(inter: discord.Interaction):
            if inter.user.id != interaction.user.id:
                return await inter.response.send_message("هذه المهمة ليست لك.", ephemeral=True)
            await inter.response.send_message(f"📸 أرسل {required} صورة إثبات في هذه القناة خلال 120 ثانية.", ephemeral=True)
            images = []
            seen = set()
            try:
                while len(images) < required:
                    msg = await inter.client.wait_for(
                        "message", timeout=120,
                        check=lambda m: m.author.id == inter.user.id and m.channel.id == inter.channel_id
                        and any((a.content_type or '').startswith('image/') for a in m.attachments),
                    )
                    for attachment in msg.attachments:
                        if not (attachment.content_type or '').startswith('image/'):
                            continue
                        if attachment.url in seen:
                            await msg.reply("⚠️ هذه الصورة أُرسلت مسبقاً. أرسل صورة مختلفة.")
                            continue
                        seen.add(attachment.url)
                        images.append(attachment.url)
                        if len(images) >= required:
                            break
                    if len(images) < required:
                        await msg.reply(f"✅ استلمت {len(images)}/{required}. أرسل المتبقي.")
            except asyncio.TimeoutError:
                return await inter.followup.send(f"انتهى الوقت. استلمت {len(images)} من {required} صور.", ephemeral=True)

            submission_id = await submit_hunter_quest(
                inter.user.id, "weekly", current_mission["desc"], images[0], "weekly_mission",
                week_key, len(images), required
            )
            await inter.followup.send("✅ تم حفظ إثبات المهمة الأسبوعية وإرساله للمراجعة.", ephemeral=True)
            log_channel_id = await get_log_channel_id(inter.guild.id)
            log_channel = inter.guild.get_channel(log_channel_id) if log_channel_id else None
            if log_channel:
                from cogs.admin import AdminReviewView
                log_embed = discord.Embed(title="📸 إثبات مهمة أسبوعية", color=COLOR_OCEAN)
                log_embed.add_field(name="اللاعب", value=inter.user.mention)
                log_embed.add_field(name="المهمة", value=current_mission["desc"])
                log_embed.add_field(name="عدد الصور", value=str(len(images)))
                proof_embeds = []
                for index, url in enumerate(images, 1):
                    image_embed = discord.Embed(title=f"إثبات أسبوعي — صورة {index}")
                    image_embed.set_image(url=url)
                    proof_embeds.append(image_embed)
                await log_channel.send(embeds=[log_embed, *proof_embeds], view=AdminReviewView("hunter", submission_id))
            else:
                await inter.followup.send("⚠️ لم تُضبط قناة السجلات؛ أبلغ الإدارة لتعيينها عبر /setup.", ephemeral=True)

        button.callback = submit_callback
        view.add_item(button)
        await interaction.response.send_message(embed=embed, view=view)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        # Custom shortcuts are evaluated independently from the streak channel.
        # This avoids the old early-return bug that disabled shortcuts unless a
        # streak channel had already been configured.
        try:
            from web import store as dashboard_store
            shortcuts = await dashboard_store.get_shortcuts()
            incoming = message.content.strip().casefold()
            for shortcut in shortcuts:
                trigger = str(shortcut.get("trigger_text") or "").strip().casefold()
                if not trigger:
                    continue
                bare_trigger = trigger.lstrip("!")
                accepted_triggers = {trigger, bare_trigger, f"!{bare_trigger}"}
                if incoming not in accepted_triggers:
                    continue

                action_type = shortcut.get("action_type")
                action_data = str(shortcut.get("action_data") or "").strip()
                if action_type == "text":
                    response = action_data
                    response = response.replace("{user}", message.author.display_name)
                    response = response.replace("{username}", message.author.name)
                    response = response.replace("{mention}", message.author.mention)
                    response = response.replace("{server}", message.guild.name)
                    response = response.replace("{channel}", message.channel.mention)
                    await message.channel.send(response)
                elif action_type == "command":
                    command = self.bot.tree.get_command(action_data)
                    if command is None:
                        await message.channel.send("⚠️ الأمر المرتبط بهذا الاختصار لم يعد متاحاً. حدّث الاختصار من لوحة التحكم.")
                    else:
                        from utils.db import get_synced_command_id
                        command_id = await get_synced_command_id(command.qualified_name, message.guild.id)
                        if command_id:
                            await message.channel.send(f"الأمر المرتبط بهذا الاختصار: </{command.qualified_name}:{command_id}>")
                        else:
                            await message.channel.send(f"الأمر `/{command.qualified_name}` موجود لكنه غير مسجل في مزامنة Discord لهذا السيرفر بعد. اطلب من الإدارة مزامنة الأوامر.")
                break
        except Exception as exc:
            print(f"⚠️ تعذر تنفيذ اختصار مخصص: {exc!r}")

        # Preserve the existing automatic daily-streak workflow.
        from utils.db import _conn
        with _conn() as conn:
            row = conn.execute("SELECT streak_channel_id FROM guild_config WHERE guild_id = ?", (message.guild.id,)).fetchone()

        if not row or not row["streak_channel_id"]:
            return

        if message.channel.id == row["streak_channel_id"]:
            streak_image = next((a for a in message.attachments if (a.content_type or "").startswith("image/")), None)
            if streak_image is None:
                return await message.reply("⚠️ يرجى إرفاق صورة لإثبات الستريك اليومي.")

            res = await claim_daily_streak(message.author.id, message.author.name)
            if not res["success"]:
                if res["reason"] == "already_claimed":
                    return await message.reply(f"⏳ لقد سجلت ستريك اليوم بالفعل! ستريكك الحالي: **{res['streak']} يوم**")
                return

            embed = discord.Embed(title=f"⭐ تم تسجيل الستريك التلقائي! — {res['streak']} يوم", description=f"💎 **+{res['points_awarded']} نقطة**\n🪙 **+{res['coins_awarded']} عملة**\n💠 **+{res['gems_awarded']} جوهرة**", color=COLOR_SUCCESS)
            if res["weekly_bonus"]:
                embed.description += "\n🎁 **بونص أسبوعي!**"
            embed.set_image(url=streak_image.url)
            await message.reply(embed=embed)

class ProfileView(discord.ui.View):
    def __init__(self, owner_id, can_claim):
        super().__init__(timeout=180)
        self.owner_id = owner_id
        self._lock = asyncio.Lock()
        if not can_claim:
            self.streak_btn.disabled = True
            self.streak_btn.label = "تم تسجيل ستريك اليوم ✅"
            self.streak_btn.style = discord.ButtonStyle.secondary

    @discord.ui.button(label="تسجيل الستريك اليومي", style=discord.ButtonStyle.green, emoji="⭐", custom_id="profile_streak")
    async def streak_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.owner_id: return await interaction.response.send_message("❌ هذا الزر ليس لك!", ephemeral=True)
        if self._lock.locked(): return await interaction.response.send_message("⏳ انتظر...", ephemeral=True)
        async with self._lock:
            res = await claim_daily_streak(interaction.user.id, interaction.user.name)
            if not res["success"]:
                if res["reason"] == "already_claimed":
                    button.disabled = True; button.label = "تم تسجيل ستريك اليوم ✅"; button.style = discord.ButtonStyle.secondary
                    await interaction.response.edit_message(view=self)
                    await interaction.followup.send(f"⏳ سجلت اليوم بالفعل! ستريكك: **{res['streak']} يوم**", ephemeral=True)
                return
            button.disabled = True; button.label = "تم تسجيل ستريك اليوم ✅"; button.style = discord.ButtonStyle.secondary
            data = await get_user_data(interaction.user.id, interaction.user.name)
            embed = discord.Embed(title=f"⭐ ستريك {res['streak']} يوم", description=f"💎 **+{res['points_awarded']} نقطة**", color=COLOR_SUCCESS)
            if res["weekly_bonus"]: embed.description += f"\n🎁 بونص أسبوعي: +{STREAK_WEEKLY_BONUS}!"
            embed.add_field(name="🏆 الرتبة", value=data["rank"]).add_field(name="💎 إجمالي النقاط", value=data["points"])
            await interaction.response.edit_message(embed=embed, view=self)

class GrandLineMapView(discord.ui.View):
    def __init__(self, points, progress):
        super().__init__(timeout=180)
        self.add_item(IslandSelect(points, progress))

    @discord.ui.button(label="رجوع للخريطة", style=discord.ButtonStyle.secondary, emoji="🗺️", custom_id="gl_back_map", row=1)
    async def back_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        data = await get_user_data(interaction.user.id, interaction.user.name)
        progress = await get_island_progress(interaction.user.id)
        cleared = sum(1 for i in ISLANDS if i["missions"] and progress.get(i["id"], 0) >= len(i["missions"]))
        unlocked = sum(1 for i in ISLANDS if data["points"] >= i["min_points"])
        embed = discord.Embed(title="🗺️ GRAND LINE", description=f"الجزر المفتوحة: **{unlocked}/{len(ISLANDS)}**\nالجزر المكتملة: **{cleared}/{len(ISLANDS)}**\nنقاطك: **{data['points']}**", color=COLOR_OCEAN)
        await interaction.response.edit_message(embed=embed, view=GrandLineMapView(data["points"], progress))

class IslandSelect(discord.ui.Select):
    def __init__(self, points, progress):
        options = []
        for i in ISLANDS:
            cleared = progress.get(i["id"], 0)
            total = len(i["missions"])
            if total == 0:
                desc = "📝 لا توجد مهام بعد"
            elif points < i["min_points"]:
                desc = f"🔒 يحتاج {i['min_points']} نقطة"
            else:
                desc = f"✅ مكتملة ({cleared}/{total})" if cleared >= total else f"📍 ({cleared}/{total})"
            options.append(discord.SelectOption(label=f"{i['emoji']} {i['name']}", value=i["id"], description=desc[:100]))
        super().__init__(placeholder="اختر جزيرة...", options=options[:25])
        self.points = points
        self.progress = progress

    async def callback(self, interaction: discord.Interaction):
        island = _find_island(self.values[0])
        if self.points < island["min_points"]: 
            return await interaction.response.send_message(f"🔒 تحتاج {island['min_points']} نقطة!", ephemeral=True)
        
        cleared = self.progress.get(island["id"], 0)
        embed = discord.Embed(title=f"{island['emoji']} {island['name']}", description=island["desc"], color=COLOR_OCEAN)
        
        # 1. صورة الجزيرة (كبيرة في المنتصف)
        if island.get("image"): 
            embed.set_image(url=island["image"])
            
        embed.add_field(name="📍 المراحل", value=f"**{cleared}/{len(island['missions'])}**")
        
        if not island["missions"]:
            embed.add_field(name="📝 حالة الجزيرة", value="لم تتم إضافة مهام لهذه الجزيرة بعد.", inline=False)
        elif cleared < len(island["missions"]):
            mission = island["missions"][cleared]
            mission_text = mission["desc"]
            
            # 2. صورة الشخصية (صغيرة في الزاوية بجانب الاسم)
            if mission["character"]:
                char = CHARACTERS.get(mission["character"])
                if char:
                    mission_text += f"\n**الشخصية المطلوبة:** {char['name']} ({char['type']} | {char['class']} | {char['element']})"
                    if mission["alternatives"]:
                        alts = [CHARACTERS[a]["name"] for a in mission["alternatives"] if a in CHARACTERS]
                        mission_text += f"\n**بدائل مسموحة:** {', '.join(alts)}"
                    
                    custom_img = await get_image(mission["character"])
                    if custom_img: 
                        embed.set_thumbnail(url=custom_img)
                    elif char.get("img") and char["img"].startswith("http"): 
                        embed.set_thumbnail(url=char["img"])
                        
            embed.add_field(name="🎯 المهمة الحالية", value=mission_text, inline=False)
        else:
            embed.add_field(name="🏆 الحالة", value="✅ مكتملة!", inline=False)
            
        await interaction.response.edit_message(embed=embed, view=IslandDetailView(island["id"], cleared, len(island["missions"]), interaction.user.id))

class IslandDetailView(discord.ui.View):
    def __init__(self, island_id, current_stage, max_stages, user_id):
        super().__init__(timeout=180)
        self.island_id = island_id
        self.current_stage = current_stage
        self.max_stages = max_stages
        self.user_id = user_id

        if max_stages == 0:
            self.next_stage_btn.disabled = True
            self.next_stage_btn.label = "لا توجد مهام"
        elif current_stage >= max_stages:
            self.next_stage_btn.disabled = True
            self.next_stage_btn.label = "مكتملة ✅"

    @discord.ui.button(label="رفع إثبات المرحلة", style=discord.ButtonStyle.green, emoji="📸", custom_id="gl_next_stage")
    async def next_stage_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)

        progress = await get_mission_progress(interaction.user.id, self.island_id, self.current_stage)
        if progress["pending"]: 
            return await interaction.response.send_message("⏳ لديك إثبات قيد المراجعة بالفعل.", ephemeral=True)
        if progress["approved"] >= progress["required"]:
            await complete_island_stage(interaction.user.id, self.island_id, self.current_stage + 1)
            return await interaction.response.send_message("🎉 لقد أكملت هذه المهمة بالكامل!", ephemeral=True)

        island = _find_island(self.island_id)
        mission = island["missions"][self.current_stage]
        req = progress["required"]

        embed = discord.Embed(title="📸 إثبات المهمة", description=f"{mission['desc']}\n\n**التقدم:** {progress['approved']}/{req}\n\n(تتطلب **{req}** إثباتات)", color=COLOR_OCEAN)

        # 1. صورة الجزيرة (كبيرة في المنتصف)
        if island.get("image"):
            embed.set_image(url=island["image"])

        # 2. صورة الشخصية (صغيرة في الزاوية)
        if mission["character"]:
            char = CHARACTERS.get(mission["character"])
            if char:
                char_info = f"\n**الشخصية المطلوبة:** {char['name']} ({char['type']} | {char['class']} | {char['element']})"
                embed.description += char_info
                
                custom_img = await get_image(mission["character"])
                if custom_img: 
                    embed.set_thumbnail(url=custom_img)
                elif char.get("img") and char["img"].startswith("http"): 
                    embed.set_thumbnail(url=char["img"])

        await interaction.response.send_message(embed=embed, ephemeral=False)
        await interaction.followup.send(f"📸 **المهمة تتطلب ({req}) صور. يرجى إرسالها الآن (يمكنك إرسالها كلها أو صورة تلو الأخرى).**", ephemeral=True)

        images = []
        seen_hashes = set()
        
        while len(images) < req:
            try:
                msg = await interaction.client.wait_for("message", timeout=120.0, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel.id and any((a.content_type or '').startswith('image/') for a in m.attachments))
                for attachment in msg.attachments:
                    if len(images) >= req: break
                    if not (attachment.content_type or '').startswith('image/'):
                        continue
                    if attachment.url in seen_hashes:
                        await msg.reply("⚠️ لقد أرسلت هذه الصورة مسبقاً. يرجى إرسال صورة مختلفة.")
                        continue
                    seen_hashes.add(attachment.url)
                    images.append(attachment.url)
                if len(images) < req:
                    await msg.reply(f"✅ تم استلام ({len(images)}/{req}). أرسل الصور المتبقية.")
            except asyncio.TimeoutError:
                return await interaction.followup.send(f"❌ انتهى الوقت. أرسلت {len(images)} من أصل {req} صور.", ephemeral=True)

        proof_description = mission['desc'] + ("\nإثباتات إضافية: " + " ".join(images[1:]) if len(images) > 1 else "")
        proof_id = await submit_grandline_proof(interaction.user.id, self.island_id, self.current_stage + 1, images[0], proof_description, len(images), req)
        await interaction.followup.send("✅ تم استلام جميع الصور. سيتم مراجعتها.", ephemeral=True)
        
        log_channel_id = await get_log_channel_id(interaction.guild_id)
        if log_channel_id:
            log_channel = interaction.guild.get_channel(log_channel_id)
            if log_channel:
                from cogs.admin import AdminReviewView
                embeds = []
                for i, url in enumerate(images):
                    emb = discord.Embed(url="https://requiem.bot", title=f"إثبات الجزيرة - صورة {i+1}")
                    emb.set_image(url=url)
                    embeds.append(emb)
                
                log_embed = discord.Embed(title="📸 إثبات مرحلة جديد", color=COLOR_OCEAN)
                log_embed.add_field(name="اللاعب", value=interaction.user.mention)
                log_embed.add_field(name="الجزيرة", value=island["name"])
                log_embed.add_field(name="المهمة", value=mission["desc"])
                log_embed.add_field(name="عدد الصور", value=str(len(images)))
                
                view = AdminReviewView(proof_type="grandline", proof_id=proof_id)
                await log_channel.send(embeds=[log_embed] + embeds, view=view)

class HuntersMainView(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=180)
        self.user_id = user_id

    @discord.ui.button(label="رفع إثبات المهمة", style=discord.ButtonStyle.success, emoji="📸", custom_id="hunter_submit")
    async def submit_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)
        await interaction.response.send_message("اختر المهمة:", view=HunterQuestSelectView(interaction.user.id), ephemeral=True)

    @discord.ui.button(label="إثباتاتي", style=discord.ButtonStyle.secondary, emoji="📂", custom_id="hunter_history")
    async def history_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)
        subs = await get_user_submissions(interaction.user.id, limit=10)
        embed = discord.Embed(title="📂 إثباتاتك", color=COLOR_SUCCESS)
        if not subs: 
            embed.description = "لا يوجد إثباتات."
        else:
            lines = [f"{'⏳' if s['status']=='pending' else '✅' if s['status']=='approved' else '❌'} `#{s['id']}` **{s['quest_name']}**" for s in subs]
            embed.description = "\n".join(lines)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class HunterQuestSelectView(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=120)
        options = [discord.SelectOption(label=q["name"], value=q["id"], description=f"مكافأة: +{q['reward']} 💎") for q in HUNTER_QUESTS[:25]]
        self.add_item(HunterQuestSelect(options, user_id))

class HunterQuestSelect(discord.ui.Select):
    def __init__(self, options, user_id):
        super().__init__(placeholder="اختر مهمة...", options=options)
        self.user_id = user_id

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)
        quest = _find_quest(self.values[0])
        req = 1 # الهانتر حالياً تتطلب صورة واحدة، يمكنك تغييرها لاحقاً
        
        embed = discord.Embed(title="📸 إثبات مهمة صياد", description=f"**المهمة:** {quest['name']}\n{quest['desc']}\n\n(تتطلب **{req}** صورة)", color=COLOR_SUCCESS)
        await interaction.response.send_message(embed=embed, ephemeral=False)
        
        images = []
        seen_hashes = set()
        await interaction.followup.send(f"📸 **يرجى إرسال ({req}) صور. يمكنك إرسالها الآن.**", ephemeral=True)
        
        while len(images) < req:
            try:
                msg = await interaction.client.wait_for("message", timeout=120.0, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel.id and any((a.content_type or '').startswith('image/') for a in m.attachments))
                for attachment in msg.attachments:
                    if len(images) >= req: break
                    if not (attachment.content_type or '').startswith('image/'):
                        continue
                    if attachment.url in seen_hashes:
                        await msg.reply("⚠️ لقد أرسلت هذه الصورة مسبقاً.")
                        continue
                    seen_hashes.add(attachment.url)
                    images.append(attachment.url)
                if len(images) < req:
                    await msg.reply(f"✅ تم استلام ({len(images)}/{req}). أرسل الصور المتبقية.")
            except asyncio.TimeoutError:
                return await interaction.followup.send(f"❌ انتهى الوقت. أرسلت {len(images)} من أصل {req}.", ephemeral=True)

        proof_description = " ".join(images[1:]) if len(images) > 1 else ""
        submission_id = await submit_hunter_quest(interaction.user.id, quest["id"], quest["name"], images[0], proof_description, None, len(images), req)
        await interaction.followup.send("✅ تم استلام إثباتك. سيتم مراجعته.", ephemeral=True)
        
        log_channel_id = await get_log_channel_id(interaction.guild_id)
        if log_channel_id:
            log_channel = interaction.guild.get_channel(log_channel_id)
            if log_channel:
                from cogs.admin import AdminReviewView
                embeds = []
                for i, url in enumerate(images):
                    emb = discord.Embed(url="https://requiem.bot", title=f"إثبات صياد - صورة {i+1}")
                    emb.set_image(url=url)
                    embeds.append(emb)
                
                log_embed = discord.Embed(title="📸 إثبات مهمة صياد جديد", color=COLOR_SUCCESS)
                log_embed.add_field(name="اللاعب", value=interaction.user.mention)
                log_embed.add_field(name="المهمة", value=quest["name"])
                log_embed.add_field(name="عدد الصور", value=str(len(images)))
                
                view = AdminReviewView(proof_type="hunter", proof_id=submission_id)
                await log_channel.send(embeds=[log_embed] + embeds, view=view)

class LeagueView(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=180)
        self.user_id = user_id

    @discord.ui.button(label="تسجيل نتيجة مباراة", style=discord.ButtonStyle.green, emoji="⚔️", custom_id="league_submit_result")
    async def submit_result_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id: return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)
        await interaction.response.send_message("📸 **يرجى إرسال صورة نتيجة المباراة هنا في الشات الآن** (لديك 60 ثانية).", ephemeral=False)
        try:
            msg = await interaction.client.wait_for("message", timeout=60.0, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel_id and any((a.content_type or '').startswith('image/') for a in m.attachments))
            image_url = next(a.url for a in msg.attachments if (a.content_type or '').startswith('image/'))
            from utils.db import get_log_channel_id
            from web.store import submit_league_proof
            proof_id = await submit_league_proof(interaction.user.id, image_url, "")
            log_channel_id = await get_log_channel_id(interaction.guild_id)
            log_channel = interaction.guild.get_channel(log_channel_id) if log_channel_id else None
            if log_channel:
                log_embed = discord.Embed(title="⚔️ إثبات مباراة ليج جديد", color=COLOR_DANGER)
                log_embed.add_field(name="اللاعب", value=interaction.user.mention)
                log_embed.set_image(url=image_url)
                from cogs.admin import AdminReviewView
                view = AdminReviewView(proof_type="league", proof_id=proof_id)
                await log_channel.send(embed=log_embed, view=view)
                await msg.reply("✅ تم حفظ إثبات المباراة وإرساله للإدارة للمراجعة.")
            else:
                await msg.reply("⚠️ تم حفظ إثباتك، لكن لم تُحدد قناة سجلات صالحة للمراجعة بعد. أخبر الإدارة بتعيينها عبر /setup أو لوحة التحكم.")
        except asyncio.TimeoutError:
            await interaction.followup.send("❌ انتهى الوقت.", ephemeral=True)

    @discord.ui.button(label="تحديث", style=discord.ButtonStyle.primary, emoji="🔄", custom_id="league_refresh")
    async def refresh_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        rows = await get_tournament_leaderboard(CURRENT_TOURNAMENT_ID, limit=LEAGUE_PAGE_SIZE)
        embed = discord.Embed(title=f"⚔️ CHAMPIONS LEAGUE", color=COLOR_DANGER)
        if not rows: embed.description = "لا يوجد لاعبون بعد. كن أول من يسجل فوزه!"
        else:
            lines = [f"{_format_medal(i)} **{r['username'] or r['user_id']}** — {r['total']} 💎" for i, r in enumerate(rows, 1)]
            embed.description = "\n".join(lines)
        await interaction.response.edit_message(embed=embed, view=self)

class BattlePassView(discord.ui.View):
    def __init__(self, user_id, points, tiers, claimed_tiers):
        super().__init__(timeout=180)
        self.user_id, self.points, self.tiers, self.claimed_tiers = user_id, points, tiers, claimed_tiers
        self._lock = asyncio.Lock()
        
        options = []
        for t in tiers:
            if points >= t["required_points"] and t["tier"] not in claimed_tiers:
                options.append(discord.SelectOption(label=f"Tier {t['tier']} — {t['label']}", value=str(t["tier"]), description=f"مكافأة: {t['reward_coins']} 🪙 + {t['reward_gems']} 💎"))
        
        if options: 
            self.claim_select.options = options[:25]
        else:
            self.claim_select.disabled = True
            self.claim_select.options = [discord.SelectOption(label="لا مكافآت متاحة", value="0")]

    @discord.ui.select(placeholder="🎁 اختر مكافأة...", custom_id="bp_claim_select", options=[discord.SelectOption(label="جارٍ التحميل...", value="0")])
    async def claim_select(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user.id != self.user_id: 
            return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)
        if select.values[0] == "0": 
            return await interaction.response.send_message("لا توجد مكافآت.", ephemeral=True)
        tier_num = int(select.values[0])
        tier_data = next((t for t in self.tiers if t["tier"] == tier_num), None)
        
        if self._lock.locked(): 
            return await interaction.response.send_message("⏳ انتظر...", ephemeral=True)
        async with self._lock:
            # استخدام دالة السحب من store.py
            from web.store import claim_bp_tier
            res = await claim_bp_tier(interaction.user.id, tier_num, tier_data["required_points"], tier_data["reward_coins"], tier_data["reward_gems"])
            if not res["success"]: 
                return await interaction.response.send_message("⚠️ خطأ أو مستلمة مسبقاً.", ephemeral=True)
            
            data = await get_user_data(interaction.user.id, interaction.user.name)
            self.points = data["points"]
            self.claimed_tiers.append(tier_num)
            
            new_opts = [discord.SelectOption(label=f"Tier {t['tier']}", value=str(t["tier"])) for t in self.tiers if self.points >= t["required_points"] and t["tier"] not in self.claimed_tiers]
            if not new_opts:
                select.disabled = True
                select.options = [discord.SelectOption(label="لا مكافآت", value="0")]
            else: 
                select.options = new_opts[:25]
                
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"🎉 استلمت **Tier {tier_num}**!\n🪙 +{res['coins']} عملة\n💎 +{res['gems']} جوهرة", ephemeral=True)

class LeaderboardView(discord.ui.View):
    def __init__(self, order, viewer_id):
        super().__init__(timeout=180)
        self.order, self.viewer_id, self.page = order, viewer_id, 0
    async def _load(self):
        rows = await get_leaderboard(limit=LEADERBOARD_PAGE_SIZE + 1, offset=self.page * LEADERBOARD_PAGE_SIZE, order=self.order)
        return rows[:LEADERBOARD_PAGE_SIZE], len(rows) > LEADERBOARD_PAGE_SIZE
    def _build_embed(self, rows):
        embed = discord.Embed(title=f"📊 لوحة الصدارة", color=COLOR_OCEAN)
        if not rows: embed.description = "لا يوجد لاعبون."
        else:
            value_key = {"points": "points", "streak": "streak", "coins": "coins", "bounty": "bounty"}.get(self.order, "points")
            value_label = {"points": "نقطة", "streak": "يوم", "coins": "عملة", "bounty": "Bounty"}.get(value_key, "")
            lines = [f"{_format_medal(self.page * LEADERBOARD_PAGE_SIZE + i + 1)} **{r['username'] or r['user_id']}** — {int(r.get(value_key, 0)):,} {value_label}" for i, r in enumerate(rows)]
            embed.description = "\n".join(lines)
        embed.set_footer(text=f"الصفحة {self.page + 1}")
        return embed
    def sync_buttons(self, has_next):
        _set_button_state(self, "lb_prev", self.page == 0)
        _set_button_state(self, "lb_next", not has_next)
    async def build_page(self):
        rows, has_next = await self._load()
        return self._build_embed(rows), has_next
    async def _refresh(self, interaction: discord.Interaction):
        embed, has_next = await self.build_page()
        self.sync_buttons(has_next)
        await interaction.response.edit_message(embed=embed, view=self)
    @discord.ui.button(label="السابق", style=discord.ButtonStyle.secondary, custom_id="lb_prev")
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page > 0: self.page -= 1
        await self._refresh(interaction)
    @discord.ui.button(label="التالي", style=discord.ButtonStyle.secondary, custom_id="lb_next")
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.page += 1
        await self._refresh(interaction)
    @discord.ui.button(label="تبديل", style=discord.ButtonStyle.primary, emoji="🔄", custom_id="lb_toggle")
    async def toggle_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.order = "streak" if self.order == "points" else "points"
        self.page = 0
        await self._refresh(interaction)


async def setup(bot):
    await bot.add_cog(GeneralCog(bot))