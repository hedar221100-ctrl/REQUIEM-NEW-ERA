import discord
from discord.ext import commands
from discord import app_commands
import asyncio
from utils.db import (
    get_tournament_leaderboard, add_tournament_points, get_league_rank,
    create_tournament, join_tournament, get_user_data, _conn, _now, get_log_channel_id
)
from web.store import (
    start_tournament, get_user_tournament_match, submit_tournament_match_proof,
    create_direct_challenge, update_direct_challenge,
    submit_direct_challenge_proof, get_recoverable_challenges,
)
from cogs.general import CHARACTERS

COLOR_DANGER = 0xE74C3C
COLOR_GOLD = 0xF1C40F
COLOR_OCEAN = 0x3498DB
COLOR_SUCCESS = 0x2ECC71

class LeagueCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="league", description="عرض لوحة الصدارة ورتبتك الحالية")
    async def league(self, interaction: discord.Interaction):
        rows = await get_tournament_leaderboard("season_1_requiem", limit=10)
        data = await get_user_data(interaction.user.id, interaction.user.name)
        
        # حساب نقاط البطولة للاعب
        with _conn() as conn:
            pts = conn.execute("SELECT COALESCE(SUM(points), 0) FROM tournament_points WHERE user_id = ? AND tournament_id = 'season_1_requiem'", (interaction.user.id,)).fetchone()[0]
            
        rank_name = await get_league_rank(pts)
        
        embed = discord.Embed(title="⚔️ CHAMPIONS LEAGUE", description=f"**رتبتك الحالية:** {rank_name} ({pts} نقطة)", color=COLOR_DANGER)
        
        if not rows:
            embed.add_field(name="الترتيب", value="لا يوجد لاعبون بعد.", inline=False)
        else:
            lines = []
            for i, r in enumerate(rows, 1):
                medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"`#{i}`")
                lines.append(f"{medal} **{r['username'] or r['user_id']}** — {r['total']} 💎")
            embed.add_field(name="🏆 أفضل 10 لاعبين", value="\n".join(lines), inline=False)
            
        await interaction.response.send_message(embed=embed, view=LeagueView(interaction.user.id))

    @app_commands.command(name="challenge", description="تحدي لاعب آخر في مباراة مباشرة")
    async def challenge(self, interaction: discord.Interaction, opponent: discord.Member):
        if interaction.guild is None:
            return await interaction.response.send_message("❌ التحديات المباشرة متاحة داخل السيرفر فقط.", ephemeral=True)
        if opponent.id == interaction.user.id: return await interaction.response.send_message("❌ لا يمكنك تحدي نفسك!", ephemeral=True)
        if opponent.bot: return await interaction.response.send_message("❌ لا يمكنك تحدي بوت!", ephemeral=True)
        
        try:
            challenge_id = await create_direct_challenge(interaction.guild_id, interaction.channel_id, interaction.user.id, opponent.id)
        except ValueError as exc:
            return await interaction.response.send_message(f"❌ {exc}", ephemeral=True)
        view = ChallengeView(challenge_id, interaction.user.id, opponent.id)
        await interaction.response.send_message(f"⚔️ **تحدي مباشر!**\n{opponent.mention} هل تقبل التحدي من {interaction.user.mention}؟", view=view)
        message = await interaction.original_response()
        await update_direct_challenge(challenge_id, "pending", challenge_message_id=message.id)

    @app_commands.command(name="tournament", description="إنشاء أو الانضمام إلى بطولة")
    @app_commands.describe(action="إنشاء أو انضمام أو بدء", name="اسم البطولة (للإنشاء فقط)", size="حجم البطولة 4، 8، 16، 32 (للإنشاء فقط)", tournament_id="معرّف بطولة محددة لبدئها")
    @app_commands.choices(action=[
        app_commands.Choice(name="إنشاء بطولة جديدة", value="create"),
        app_commands.Choice(name="الانضمام لبطولة", value="join"),
        app_commands.Choice(name="بدء البطولة (للمشرفين)", value="start")
    ])
    async def tournament(self, interaction: discord.Interaction, action: str, name: str = None, size: int = 8, tournament_id: int = None):
        if action == "create":
            if not name: return await interaction.response.send_message("❌ يرجى كتابة اسم البطولة.", ephemeral=True)
            try:
                t_id = await create_tournament(name, size, interaction.user.id)
            except ValueError as exc:
                return await interaction.response.send_message(f"❌ {exc}", ephemeral=True)
            embed = discord.Embed(title=f"🏆 بطولة: {name}", description=f"الحجم: {size} لاعبين.\nاضغط على الزر للانضمام!", color=COLOR_GOLD)
            await interaction.response.send_message(embed=embed, view=TournamentJoinView(t_id, size))
        
        elif action == "start":
            if not interaction.guild or not (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator):
                return await interaction.response.send_message("❌ بدء البطولة متاح للإدارة فقط.", ephemeral=True)
            with _conn() as conn:
                if tournament_id:
                    active = conn.execute("SELECT id,name,size FROM tournaments WHERE id=? AND status='registration'", (tournament_id,)).fetchone()
                else:
                    active = conn.execute("SELECT id,name,size FROM tournaments WHERE status='registration' ORDER BY id DESC LIMIT 1").fetchone()
            if not active:
                return await interaction.response.send_message("❌ لا توجد بطولة بانتظار البدء.", ephemeral=True)
            try:
                matches = await start_tournament(int(active["id"]))
            except (LookupError, ValueError) as exc:
                return await interaction.response.send_message(f"❌ {exc}", ephemeral=True)
            lines = [f"المباراة **#{m['match_number']}**: <@{m['player1_id']}> ضد <@{m['player2_id']}>" for m in matches]
            embed = discord.Embed(title=f"🏆 بدأت بطولة {active['name']}", description="\n".join(lines), color=COLOR_GOLD)
            embed.set_footer(text="يستخدم اللاعبون /tournament_match لإرسال نتيجة المباراة.")
            await interaction.response.send_message(embed=embed)

        elif action == "join":
            with _conn() as conn:
                active = conn.execute("SELECT id, name FROM tournaments WHERE status = 'registration' ORDER BY id DESC LIMIT 1").fetchone()
            if not active: return await interaction.response.send_message("❌ لا توجد بطولات مفتوحة للانضمام حالياً.", ephemeral=True)
            success = await join_tournament(active["id"], interaction.user.id)
            if success:
                await interaction.response.send_message(f"✅ انضممت بنجاح لبطولة **{active['name']}**!", ephemeral=True)
            else:
                await interaction.response.send_message("❌ تعذر الانضمام (البطولة ممتلئة أو أنت منضم بالفعل).", ephemeral=True)

    @app_commands.command(name="tournament_match", description="إرسال إثبات نتيجة مباراتك في البطولة الحالية")
    async def tournament_match(self, interaction: discord.Interaction):
        match = await get_user_tournament_match(interaction.user.id)
        if not match:
            return await interaction.response.send_message("❌ لا توجد لك مباراة بطولة نشطة حالياً.", ephemeral=True)
        opponent_id = match["player2_id"] if match["player1_id"] == interaction.user.id else match["player1_id"]
        await interaction.response.send_message(f"📸 أرسل صورة نتيجة مباراتك ضد <@{opponent_id}> في هذه القناة خلال 120 ثانية.", ephemeral=True)
        try:
            msg = await self.bot.wait_for("message", timeout=120, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel_id and any((a.content_type or '').startswith('image/') for a in m.attachments))
            attachment = next(a for a in msg.attachments if (a.content_type or '').startswith('image/'))
            result = await submit_tournament_match_proof(interaction.user.id, attachment.url, f"Tournament: {match['tournament_name']} vs {opponent_id}")
            log_id = await get_log_channel_id(interaction.guild_id)
            log_channel = interaction.guild.get_channel(log_id) if log_id else None
            if log_channel:
                from cogs.admin import AdminReviewView
                embed = discord.Embed(title="🏆 إثبات مباراة بطولة", color=COLOR_GOLD)
                embed.add_field(name="البطولة", value=match['tournament_name'])
                embed.add_field(name="اللاعب مقدم الإثبات", value=interaction.user.mention)
                embed.add_field(name="الخصم", value=f"<@{opponent_id}>")
                embed.set_image(url=attachment.url)
                await log_channel.send(embed=embed, view=AdminReviewView("league", result["proof_id"]))
                await msg.reply("✅ تم إرسال نتيجة المباراة للإدارة للمراجعة.")
            else:
                await msg.reply("⚠️ تم حفظ النتيجة، لكن قناة السجلات غير مضبوطة. أبلغ الإدارة عبر /setup.")
        except asyncio.TimeoutError:
            await interaction.followup.send("⌛ انتهى وقت رفع الإثبات.", ephemeral=True)
        except LookupError as exc:
            await interaction.followup.send(f"❌ {exc}", ephemeral=True)

    @app_commands.command(name="give_league_role", description="منح رتبة البطل لصاحب المركز الأول (للمشرفين)")
    @app_commands.default_permissions(manage_guild=True)
    async def give_role(self, interaction: discord.Interaction, role: discord.Role):
        rows = await get_tournament_leaderboard("season_1_requiem", limit=1)
        if not interaction.guild or not (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator):
            return await interaction.response.send_message("❌ هذا الأمر متاح للإدارة فقط.", ephemeral=True)
        if not rows: return await interaction.response.send_message("❌ لا يوجد لاعبون.", ephemeral=True)
        
        winner = interaction.guild.get_member(rows[0]["user_id"])
        if not winner: return await interaction.response.send_message("❌ اللاعب غير موجود في السيرفر.", ephemeral=True)
        
        await winner.add_roles(role)
        await interaction.response.send_message(f"👑 تم منح رتبة {role.mention} للبطل {winner.mention}!")

# ================== Views ==================

class LeagueMainView(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=180)
        self.user_id = user_id

    @discord.ui.button(label="تسجيل إثبات مباراة", style=discord.ButtonStyle.success, emoji="⚔️")
    async def submit_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("📸 يرجى إرسال صورة نتيجة المباراة في الشات الآن.", ephemeral=True)
        # سيتم استقبالها عن طريق النظام القديم (أو يمكن تطويره لاحقاً)

class ChallengeView(discord.ui.View):
    def __init__(self, challenge_id, challenger_id, opponent_id):
        super().__init__(timeout=None)
        self.challenge_id = challenge_id
        self.challenger_id = challenger_id
        self.opponent_id = opponent_id
        for child in self.children:
            suffix = "accept" if child.label.startswith("قبول") else "reject"
            child.custom_id = f"requiem_direct_challenge:{challenge_id}:{suffix}"

    @discord.ui.button(label="قبول التحدي ✅", style=discord.ButtonStyle.success, custom_id="direct_challenge_accept")
    async def accept_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.opponent_id:
            return await interaction.response.send_message("❌ هذا التحدي ليس لك!", ephemeral=True)
        thread = None
        try:
            thread = await interaction.channel.create_thread(
                name=f"⚔️ تحدي: {interaction.user.name} vs {self.challenger_id}",
                type=discord.ChannelType.private_thread,
            )
            challenger = interaction.guild.get_member(self.challenger_id) or await interaction.guild.fetch_member(self.challenger_id)
            await thread.add_user(challenger)
            await thread.add_user(interaction.user)
            result_view = ChallengeResultView(self.challenge_id, self.challenger_id, self.opponent_id)
            embed = discord.Embed(title="⚔️ المباراة بدأت!", description="اتفقوا على الشخصيات ثم ارفعوا صورة النتيجة. ستراجع الإدارة الإثبات قبل اعتماد الفائز.", color=COLOR_DANGER)
            result_message = await thread.send(content=f"<@{self.challenger_id}> {interaction.user.mention}", embed=embed, view=result_view)
            await update_direct_challenge(self.challenge_id, "active", thread_id=thread.id, result_message_id=result_message.id)
            await interaction.response.edit_message(content="✅ تم قبول التحدي! توجه إلى الغرفة الخاصة.", view=None)
        except LookupError as exc:
            if thread is not None:
                try:
                    await thread.delete()
                except discord.HTTPException:
                    pass
            await interaction.response.send_message("⚠️ تم قبول/رفض هذا التحدي بالفعل من الطرف الآخر.", ephemeral=True)
        except (discord.Forbidden, discord.HTTPException):
            await interaction.response.send_message("❌ تعذر إنشاء غرفة التحدي. تحقق من صلاحيات إنشاء وإدارة الـThreads.", ephemeral=True)

    @discord.ui.button(label="رفض ❌", style=discord.ButtonStyle.danger, custom_id="direct_challenge_reject")
    async def reject_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.opponent_id:
            return await interaction.response.send_message("❌ هذا التحدي ليس لك!", ephemeral=True)
        try:
            await update_direct_challenge(self.challenge_id, "rejected")
        except LookupError:
            return await interaction.response.send_message("⚠️ تم التعامل مع هذا التحدي مسبقاً.", ephemeral=True)
        await interaction.response.edit_message(content="❌ تم رفض التحدي.", view=None)

class ChallengeResultView(discord.ui.View):
    def __init__(self, challenge_id, p1_id, p2_id):
        super().__init__(timeout=None)
        self.challenge_id = challenge_id
        self.p1_id = p1_id
        self.p2_id = p2_id
        for child in self.children:
            child.custom_id = f"requiem_direct_challenge:{challenge_id}:result"

    @discord.ui.button(label="رفع إثبات الفوز", style=discord.ButtonStyle.primary, emoji="📸", custom_id="direct_challenge_result")
    async def submit_proof(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id not in [self.p1_id, self.p2_id]:
            return await interaction.response.send_message("❌ أنت لست جزءاً من هذه المباراة.", ephemeral=True)
        
        await interaction.response.send_message("📸 يرجى إرسال صورة الفوز هنا في الشات الآن.", ephemeral=True)
        try:
            msg = await interaction.client.wait_for("message", timeout=120.0, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel.id and any((a.content_type or '').startswith('image/') for a in m.attachments))
            image_url = next(a.url for a in msg.attachments if (a.content_type or '').startswith('image/'))
            
            # Persist the proof first, then attach the real database ID to review controls.
            from utils.db import get_log_channel_id
            opponent_id = self.p2_id if interaction.user.id == self.p1_id else self.p1_id
            proof_id = await submit_direct_challenge_proof(
                self.challenge_id, interaction.user.id, image_url, f"Direct challenge result vs user {opponent_id}"
            )
            log_ch_id = await get_log_channel_id(interaction.guild_id)
            log_channel = interaction.guild.get_channel(log_ch_id) if log_ch_id else None
            if log_channel:
                from cogs.admin import AdminReviewView
                log_embed = discord.Embed(title="⚔️ إثبات تحدي مباشر", color=COLOR_DANGER)
                log_embed.add_field(name="اللاعب مقدم الإثبات", value=interaction.user.mention)
                log_embed.add_field(name="الخصم", value=f"<@{opponent_id}>")
                log_embed.set_image(url=image_url)
                await log_channel.send(embed=log_embed, view=AdminReviewView(proof_type="league", proof_id=proof_id))
                await msg.reply("✅ تم حفظ الإثبات وإرساله للإدارة للمراجعة.")
            else:
                await msg.reply("⚠️ تم حفظ الإثبات، لكن قناة السجلات غير مضبوطة. أبلغ الإدارة لتعيينها عبر /setup.")
            if interaction.message:
                await interaction.message.edit(content="⏳ تم حفظ الإثبات وهو قيد مراجعة الإدارة. إذا رُفض، يمكنك رفع إثبات آخر من الزر نفسه.", view=self)
        except asyncio.TimeoutError:
            await interaction.followup.send("❌ انتهى الوقت.", ephemeral=True)
        except LookupError as exc:
            await interaction.followup.send(f"❌ {exc}", ephemeral=True)

class TournamentJoinView(discord.ui.View):
    def __init__(self, tournament_id, size):
        super().__init__(timeout=None)
        self.tournament_id = tournament_id
        self.size = size
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.custom_id = f"requiem_tournament_join:{tournament_id}"

    @discord.ui.button(label="انضمام للبطولة 🏆", style=discord.ButtonStyle.success, custom_id="requiem_tournament_join")
    async def join_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        success = await join_tournament(self.tournament_id, interaction.user.id)
        if success:
            await interaction.response.send_message("✅ تم انضمامك للبطولة بنجاح!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ البطولة ممتلئة أو أنت منضم بالفعل.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(LeagueCog(bot))
    for challenge in await get_recoverable_challenges():
        if challenge["status"] == "pending" and challenge.get("challenge_message_id"):
            bot.add_view(ChallengeView(challenge["id"], challenge["challenger_id"], challenge["opponent_id"]), message_id=challenge["challenge_message_id"])
        elif challenge["status"] in {"active", "result_pending"} and challenge.get("result_message_id"):
            bot.add_view(ChallengeResultView(challenge["id"], challenge["challenger_id"], challenge["opponent_id"]), message_id=challenge["result_message_id"])