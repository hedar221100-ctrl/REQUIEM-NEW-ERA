import discord
from discord.ext import commands
from discord import app_commands
from utils.db import get_user_data, transfer_coins, create_shop_order

COLOR_GOLD = 0xF1C40F
COLOR_SUCCESS = 0x2ECC71
COLOR_DANGER = 0xE74C3C

SHOP_ITEMS = {
    "vip_role": {"name": "رتبة VIP", "cost": 5000, "currency": "coins", "desc": "احصل على رتبة VIP في السيرفر!"},
    "custom_role": {"name": "رتبة مخصصة", "cost": 10000, "currency": "coins", "desc": "اصنع رتبة باسمك ولونك!"},
    "lootbox": {"name": "صندوق حظ", "cost": 5, "currency": "gems", "desc": "افتح صندوق واحصل على جائزة عشوائية!"},
    "legendary_title": {"name": "لقب أسطوري", "cost": 20, "currency": "gems", "desc": "احصل على لقب (ملك القراصنة) بجانب اسمك!"}
}

class EconomyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="balance", description="عرض رصيدك من العملات والجواهر")
    async def balance(self, interaction: discord.Interaction, member: discord.Member = None):
        target = member or interaction.user
        data = await get_user_data(target.id, target.name)
        embed = discord.Embed(title=f"💳 محفظة {target.display_name}", color=COLOR_GOLD)
        embed.add_field(name="☠ Bounty", value=f"**{data.get('bounty', 0):,}**", inline=True)
        embed.add_field(name="🪙 العملات", value=f"**{data['coins']:,}**", inline=True)
        embed.add_field(name="💎 الجواهر", value=f"**{data['gems']:,}**", inline=True)
        if target.display_avatar: embed.set_thumbnail(url=target.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="transfer", description="تحويل عملات إلى عضو آخر")
    @app_commands.describe(member="العضو الذي تريد التحويل له", amount="المبلغ الذي تريد تحويله")
    async def transfer(self, interaction: discord.Interaction, member: discord.Member, amount: int):
        if amount <= 0: return await interaction.response.send_message("❌ يجب أن يكون المبلغ أكبر من 0.", ephemeral=True)
        if member.id == interaction.user.id: return await interaction.response.send_message("❌ لا يمكنك تحويل عملات لنفسك.", ephemeral=True)
        if member.bot: return await interaction.response.send_message("❌ لا يمكنك التحويل لبوت.", ephemeral=True)

        success = await transfer_coins(interaction.user.id, member.id, amount)
        if success:
            embed = discord.Embed(title="✅ تم التحويل بنجاح", description=f"لقد حولت **{amount:,}** 🪙 إلى {member.mention}.", color=COLOR_SUCCESS)
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message("❌ رصيدك غير كافٍ لإتمام العملية.", ephemeral=True)

    @app_commands.command(name="shop", description="عرض متجر السيرفر")
    async def shop(self, interaction: discord.Interaction):
        embed = discord.Embed(title="🛒 متجر REQUIEM", description="اشتري الأشياء باستخدام العملات أو الجواهر.", color=COLOR_GOLD)
        for item_id, item in SHOP_ITEMS.items():
            currency_icon = "🪙" if item["currency"] == "coins" else "💎"
            embed.add_field(name=f"{item['name']} — {item['cost']:,} {currency_icon}", value=f"{item['desc']}\n**ID:** `{item_id}`", inline=False)
        embed.set_footer(text="استخدم /buy <ID> لشراء العنصر")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="buy", description="شراء عنصر من المتجر")
    @app_commands.describe(item_id="معرف العنصر (مكتوب في المتجر)")
    async def buy(self, interaction: discord.Interaction, item_id: str):
        item = SHOP_ITEMS.get(item_id.lower())
        if not item: return await interaction.response.send_message("❌ العنصر غير موجود.", ephemeral=True)

        currency_icon = "🪙" if item["currency"] == "coins" else "💎"
        order_id = await create_shop_order(interaction.user.id, item_id.lower(), item["name"], item["currency"], item["cost"])
        if order_id is None:
            return await interaction.response.send_message(f"❌ لا تملك ما يكفي من {currency_icon}.", ephemeral=True)

        embed = discord.Embed(title="🧾 تم تسجيل طلب الاستبدال", description=f"تم خصم **{item['cost']:,}** {currency_icon} وتسجيل طلب **{item['name']}**.\nرقم الطلب: **#{order_id}**\nالحالة: **بانتظار تسليم الإدارة**.", color=COLOR_SUCCESS)
        await interaction.response.send_message(embed=embed, ephemeral=True)

        # إرسال إشعار للإدارة
        from utils.db import get_log_channel_id
        log_ch_id = await get_log_channel_id(interaction.guild_id)
        if log_ch_id:
            log_ch = interaction.guild.get_channel(log_ch_id)
            if log_ch:
                log_embed = discord.Embed(title="🛒 عملية شراء جديدة", color=COLOR_GOLD)
                log_embed.add_field(name="اللاعب", value=interaction.user.mention)
                log_embed.add_field(name="العنصر", value=item['name'])
                log_embed.add_field(name="رقم الطلب", value=f"#{order_id}")
                log_embed.add_field(name="الحالة", value="بانتظار التسليم")
                await log_ch.send(embed=log_embed)

async def setup(bot):
    await bot.add_cog(EconomyCog(bot))