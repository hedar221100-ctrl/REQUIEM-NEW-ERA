import asyncio
import discord
from discord import app_commands
from discord.ext import commands

from web.store import get_user_bp_missions, submit_bp_mission_proof
from utils.db import get_log_channel_id
from cogs.admin import AdminReviewView


class BattlePassTasksCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="bp_tasks", description="عرض مهام موسم Battle Pass وإرسال إثبات")
    async def bp_tasks(self, interaction: discord.Interaction):
        if interaction.guild is None:
            return await interaction.response.send_message("هذا الأمر متاح داخل السيرفر فقط.", ephemeral=True)
        missions = await get_user_bp_missions(interaction.user.id)
        if not missions:
            return await interaction.response.send_message("لا توجد مهام Battle Pass نشطة حالياً.", ephemeral=True)

        embed = discord.Embed(
            title="🎟️ مهام Battle Pass الموسمية",
            description="اختر مهمة، ثم أرسل صورة الإثبات في هذه القناة. ستراجعها الإدارة من نفس مركز مراجعة الإثباتات.",
            color=0xD6AD55,
        )
        for mission in missions[:6]:
            embed.add_field(
                name=f"{mission['title']} · {mission['season_name']}",
                value=(f"{mission['description'][:400]}\n"
                       f"**التقدم:** {min(int(mission['user_progress']), int(mission['required_count']))}/{mission['required_count']}"
                       f"{' · مكتملة' if mission['claimed_at'] else ''}\n"
                       f"**المكافأة:** ⭐ {mission['reward_points']:,} · 🪙 {mission['reward_coins']:,} · 💎 {mission['reward_gems']:,}"),
                inline=False,
            )
        available_missions = [m for m in missions if not m['claimed_at']]
        options = [discord.SelectOption(label=m['title'][:100], value=str(m['id']), description=m['season_name'][:100]) for m in available_missions[:25]]
        if not options:
            return await interaction.response.send_message(embed=embed, ephemeral=True)
        view = discord.ui.View(timeout=180)
        select = discord.ui.Select(placeholder="اختر المهمة الموسمية...", options=options)

        async def select_callback(select_interaction: discord.Interaction):
            if select_interaction.user.id != interaction.user.id:
                return await select_interaction.response.send_message("هذه القائمة ليست لك.", ephemeral=True)
            mission_id = int(select.values[0])
            mission = next((m for m in available_missions if int(m['id']) == mission_id), None)
            if mission is None:
                return await select_interaction.response.send_message("المهمة لم تعد متاحة.", ephemeral=True)
            await select_interaction.response.send_message(
                f"📸 أرسل صورة إثبات **{mission['title']}** في هذه القناة خلال 120 ثانية.",
                ephemeral=True,
            )
            try:
                msg = await self.bot.wait_for(
                    "message", timeout=120,
                    check=lambda m: m.author.id == select_interaction.user.id
                    and m.channel.id == select_interaction.channel_id
                    and any((a.content_type or '').startswith('image/') for a in m.attachments),
                )
                attachment = next(a for a in msg.attachments if (a.content_type or '').startswith('image/'))
                proof_id = await submit_bp_mission_proof(
                    select_interaction.user.id, mission_id, attachment.url,
                    f"Battle Pass seasonal mission: {mission['title']}",
                )
                await msg.reply("✅ تم حفظ الإثبات وإرساله للمراجعة.")
                log_id = await get_log_channel_id(select_interaction.guild_id)
                log_channel = select_interaction.guild.get_channel(log_id) if log_id else None
                if log_channel:
                    log_embed = discord.Embed(title="🎟️ إثبات مهمة Battle Pass", color=0xD6AD55)
                    log_embed.add_field(name="اللاعب", value=select_interaction.user.mention)
                    log_embed.add_field(name="الموسم", value=mission['season_name'])
                    log_embed.add_field(name="المهمة", value=mission['title'])
                    log_embed.set_image(url=attachment.url)
                    await log_channel.send(embed=log_embed, view=AdminReviewView("battle_pass", proof_id))
                else:
                    await msg.reply("⚠️ تم حفظ الإثبات، لكن قناة السجلات غير مضبوطة. أبلغ الإدارة لتعيينها عبر /setup.")
            except asyncio.TimeoutError:
                await select_interaction.followup.send("انتهى وقت رفع الإثبات.", ephemeral=True)
            except LookupError as exc:
                await select_interaction.followup.send(f"تعذر إرسال الإثبات: {exc}", ephemeral=True)

        select.callback = select_callback
        view.add_item(select)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(BattlePassTasksCog(bot))
