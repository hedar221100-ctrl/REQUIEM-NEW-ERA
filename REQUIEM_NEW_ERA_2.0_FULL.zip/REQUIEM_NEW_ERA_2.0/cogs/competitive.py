"""Player-facing competitive commands for REQUIEM: NEW ERA 2.0."""
from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.competitive import (
    get_player_ratings, queue_for_match, leave_matchmaking, set_rival,
    list_rivals, player_analytics, submit_competitive_match_proof,
    player_inventory, leaderboard, wanted_board, list_player_achievements, claim_achievement,
)
from utils.db import get_user_data, get_log_channel_id

COLOR_GOLD = 0xD6AD55
COLOR_CRIMSON = 0x7E2029


class CompetitiveCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="rank", description="عرض تصنيفك وإحصائياتك التنافسية")
    async def rank(self, interaction: discord.Interaction):
        data = await get_user_data(interaction.user.id, interaction.user.name)
        ratings = await __import__("asyncio").to_thread(get_player_ratings, interaction.user.id)
        stats = await __import__("asyncio").to_thread(player_analytics, interaction.user.id)
        embed = discord.Embed(title=f"🏴‍☠️ ملف {interaction.user.display_name}", color=COLOR_GOLD)
        embed.add_field(name="☠ Bounty", value=f"{data.get('bounty', 0):,}", inline=True)
        embed.add_field(name="⭐ Points", value=f"{data.get('points', 0):,}", inline=True)
        embed.add_field(name="🏅 الرتبة", value=data.get("rank", "المبتدئ"), inline=True)
        embed.add_field(name="General ELO", value=f"{ratings['general']['rating']:,} · {ratings['general']['wins']}W/{ratings['general']['losses']}L", inline=False)
        embed.add_field(name="Tournament ELO", value=f"{ratings['tournament']['rating']:,} · {ratings['tournament']['wins']}W/{ratings['tournament']['losses']}L", inline=False)
        embed.add_field(name="Win Rate", value=f"{stats['win_rate']}%", inline=True)
        embed.add_field(name="المباريات", value=str(stats["matches"].get("approved", 0)), inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="matchmake", description="ابحث عن خصم قريب من تصنيفك")
    async def matchmake(self, interaction: discord.Interaction):
        result = await __import__("asyncio").to_thread(queue_for_match, interaction.user.id, "general", 250)
        if result["status"] == "waiting":
            return await interaction.response.send_message(
                f"🔎 تمت إضافتك إلى قائمة البحث. تصنيفك الحالي **{result['rating']} ELO**. استخدم `/matchleave` لإلغاء البحث.", ephemeral=True)
        opponent_id = int(result["opponent_id"])
        embed = discord.Embed(title="⚔️ تم العثور على خصم", description=f"<@{interaction.user.id}> ضد <@{opponent_id}>\nمعرّف المباراة: **#{result['match_id']}**\nبعد انتهاء المباراة، يرفع أحد اللاعبين صورة النتيجة عبر `/match_result`.", color=COLOR_CRIMSON)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="matchleave", description="إلغاء البحث عن خصم")
    async def matchleave(self, interaction: discord.Interaction):
        left = await __import__("asyncio").to_thread(leave_matchmaking, interaction.user.id)
        await interaction.response.send_message("تم إلغاء البحث." if left else "ليس لديك بحث نشط حالياً.", ephemeral=True)

    @app_commands.command(name="match_result", description="إرسال إثبات نتيجة مباراة Ranked للمراجعة")
    @app_commands.describe(match_id="معرّف المباراة", image="صورة شاشة نتيجة المباراة", description="ملاحظة اختيارية")
    async def match_result(self, interaction: discord.Interaction, match_id: app_commands.Range[int, 1, 2_000_000_000], image: discord.Attachment, description: str = ""):
        if not image.content_type or not image.content_type.startswith("image/"):
            return await interaction.response.send_message("يجب إرفاق صورة صالحة لنتيجة المباراة.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await __import__("asyncio").to_thread(submit_competitive_match_proof, int(match_id), interaction.user.id, image.url, description)
        except (LookupError, ValueError) as exc:
            return await interaction.followup.send(f"تعذر إرسال الإثبات: {exc}", ephemeral=True)
        guild_id = interaction.guild_id
        log_id = await get_log_channel_id(guild_id) if guild_id else None
        channel = interaction.guild.get_channel(log_id) if interaction.guild and log_id else None
        if channel:
            from cogs.admin import AdminReviewView
            embed = discord.Embed(title="⚔️ إثبات Ranked جديد", description=f"المباراة **#{match_id}**\nاللاعب مقدم الإثبات: {interaction.user.mention}", color=COLOR_GOLD)
            embed.set_image(url=image.url)
            await channel.send(embed=embed, view=AdminReviewView("competitive", int(match_id)))
        await interaction.followup.send("تم حفظ الإثبات وإرساله إلى مراجعة الإدارة. لن يتغير ELO قبل الموافقة.", ephemeral=True)

    @app_commands.command(name="rival", description="تسجيل لاعب كمنافس لك")
    async def rival(self, interaction: discord.Interaction, opponent: discord.Member):
        try:
            await __import__("asyncio").to_thread(set_rival, interaction.user.id, opponent.id)
            await interaction.response.send_message(f"⚔️ تمت إضافة {opponent.mention} إلى قائمة منافسيك.", ephemeral=True)
        except ValueError as exc:
            await interaction.response.send_message(str(exc), ephemeral=True)

    @app_commands.command(name="rivals", description="عرض قائمة منافسيك")
    async def rivals(self, interaction: discord.Interaction):
        rows = await __import__("asyncio").to_thread(list_rivals, interaction.user.id)
        if not rows:
            return await interaction.response.send_message("لم تسجل أي منافس بعد. استخدم `/rival`.", ephemeral=True)
        await interaction.response.send_message("⚔️ منافسوك: " + " · ".join(f"<@{r['rival_id']}>" for r in rows), ephemeral=True)

    @app_commands.command(name="inventory", description="عرض مقتنياتك التجميلية")
    async def inventory(self, interaction: discord.Interaction):
        rows = await __import__("asyncio").to_thread(player_inventory, interaction.user.id)
        if not rows:
            return await interaction.response.send_message("حقيبتك فارغة حالياً.", ephemeral=True)
        lines = [f"• **{r['name']}** — {r['category']} ({'مجهز' if r['equipped'] else 'غير مجهز'})" for r in rows[:25]]
        await interaction.response.send_message("🎒 **مقتنياتك**\n" + "\n".join(lines), ephemeral=True)

    @app_commands.command(name="achievements", description="عرض إنجازاتك اليومية والموسمية")
    async def achievements(self, interaction: discord.Interaction):
        rows = await __import__("asyncio").to_thread(list_player_achievements, interaction.user.id)
        if not rows:
            return await interaction.response.send_message("لا توجد إنجازات مفعلة حالياً.", ephemeral=True)
        lines=[]
        for row in rows[:20]:
            status = "🏆 مكتمل" if row.get("unlocked_at") else f"{row.get('progress',0)}/{row['target']}"
            claim = " · جاهز للاستلام" if row.get("unlocked_at") and not row.get("claimed_at") else ""
            lines.append(f"• **{row['title']}** — {status}{claim}")
        await interaction.response.send_message("🏅 **إنجازاتك**\n" + "\n".join(lines), ephemeral=True)

    @app_commands.command(name="achievement_claim", description="استلام مكافأة إنجاز مكتمل")
    @app_commands.describe(achievement_id="معرّف الإنجاز", period_key="مفتاح الفترة الظاهر في صفحة الإنجازات")
    async def achievement_claim_command(self, interaction: discord.Interaction, achievement_id: str, period_key: str):
        try:
            result = await __import__("asyncio").to_thread(claim_achievement, interaction.user.id, achievement_id, period_key)
            rewards=result["rewards"]
            await interaction.response.send_message(f"🎁 تم استلام المكافأة: ⭐ {rewards['points']} · 🪙 {rewards['coins']} · 💎 {rewards['gems']} · ☠ {rewards['bounty']}", ephemeral=True)
        except LookupError as exc:
            await interaction.response.send_message(str(exc), ephemeral=True)

    @app_commands.command(name="wanted", description="عرض أبرز المتصدرين في REQUIEM")
    async def wanted(self, interaction: discord.Interaction):
        data = await __import__("asyncio").to_thread(wanted_board, 5)
        rows = data["bounty"]
        description = "\n".join(f"**{i+1}.** <@{r['user_id']}> — {r['bounty']:,} Bounty" for i, r in enumerate(rows)) or "لا توجد بيانات بعد."
        embed = discord.Embed(title="☠ REQUIEM Wanted Board", description=description, color=COLOR_GOLD)
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(CompetitiveCog(bot))
