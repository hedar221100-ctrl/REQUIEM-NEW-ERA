import discord
from discord.ext import commands
from discord import app_commands
from web.store import get_streak_challenges, submit_streak_proof
from utils.db import get_log_channel_id
import asyncio

class StreakCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="streak", description="عرض تحديات الستريك وإرسال الإثبات")
    async def streak(self, interaction: discord.Interaction):
        challenges = await get_streak_challenges()
        if not challenges:
            return await interaction.response.send_message("لا توجد تحديات ستريك حالياً.", ephemeral=True)
        
        embed = discord.Embed(title="🔥 تحديات الستريك (Streak)", description="أكمل التحديات لتحصل على جوائز ضخمة!", color=0xE67E22)
        for c in challenges:
            embed.add_field(
                name=f"🏆 {c['name']}", 
                value=f"{c['description']}\n**المطلوب:** {c['required_wins']} انتصارات متتالية\n**المكافأة:** {c['reward_points']}⭐ | {c['reward_coins']}🪙 | {c['reward_gems']}💎", 
                inline=False
            )
        
        view = StreakSelectView(challenges, interaction.user.id)
        await interaction.response.send_message(embed=embed, view=view)

class StreakSelectView(discord.ui.View):
    def __init__(self, challenges, user_id):
        super().__init__(timeout=180)
        self.user_id = user_id
        options = [discord.SelectOption(label=c["name"], value=str(c["id"]), description=f"يتطلب {c['required_wins']} انتصارات") for c in challenges[:25]]
        self.add_item(StreakSelect(options, user_id))

class StreakSelect(discord.ui.Select):
    def __init__(self, options, user_id):
        super().__init__(placeholder="اختر تحدي الستريك...", options=options)
        self.user_id = user_id

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id: return await interaction.response.send_message("❌ ليس لك!", ephemeral=True)
        
        challenge_id = int(self.values[0])
        await interaction.response.send_message("📸 **يرجى إرسال صورة إثبات إتمام الستريك هنا في الشات الآن** (لديك 60 ثانية).", ephemeral=False)
        
        try:
            msg = await interaction.client.wait_for("message", timeout=60.0, check=lambda m: m.author.id == interaction.user.id and m.channel.id == interaction.channel_id and any((a.content_type or '').startswith('image/') for a in m.attachments))
            image_url = next(a.url for a in msg.attachments if (a.content_type or '').startswith('image/'))
            
            proof_id = await submit_streak_proof(interaction.user.id, challenge_id, image_url)
            await msg.reply("✅ تم استلام إثبات الستريك الخاص بك، وسيتم مراجعته من قبل الإدارة.")

            log_channel_id = await get_log_channel_id(interaction.guild_id)
            if log_channel_id:
                log_channel = interaction.guild.get_channel(log_channel_id)
                if log_channel:
                    from cogs.admin import AdminReviewView
                    log_embed = discord.Embed(title="🔥 إثبات ستريك جديد", color=0xE67E22)
                    log_embed.add_field(name="اللاعب", value=interaction.user.mention)
                    log_embed.add_field(name="التحدي", value=next((c['name'] for c in challenges if int(c['id']) == challenge_id), str(challenge_id)))
                    log_embed.set_image(url=image_url)
                    await log_channel.send(embed=log_embed, view=AdminReviewView("streak", proof_id))
                    
        except asyncio.TimeoutError:
            await interaction.followup.send("❌ انتهى الوقت.", ephemeral=True)
        except LookupError as exc:
            await interaction.followup.send(f"❌ {exc}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(StreakCog(bot))