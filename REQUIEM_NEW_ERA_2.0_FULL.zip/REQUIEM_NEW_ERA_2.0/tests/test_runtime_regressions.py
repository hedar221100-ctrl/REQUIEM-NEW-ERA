import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _class_methods(path, class_name):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            return {item.name: item for item in node.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))}
    return {}


def test_message_listener_is_defined_inside_general_cog():
    methods = _class_methods(ROOT / "cogs" / "general.py", "GeneralCog")
    assert "on_message" in methods
    assert any(
        isinstance(decorator, ast.Call)
        and isinstance(decorator.func, ast.Attribute)
        and decorator.func.attr == "listener"
        for decorator in methods["on_message"].decorator_list
    )


def test_admin_review_ids_are_proof_specific_and_restored_on_startup():
    admin_source = (ROOT / "cogs" / "admin.py").read_text(encoding="utf-8")
    main_source = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "requiem_review:{proof_type}:{proof_id}:{suffix}" in admin_source
    assert "self.add_view(AdminReviewView(proof[\"type\"], int(proof[\"id\"])))" in main_source


def test_challenge_and_seasonal_mission_flows_use_real_review_records():
    league_source = (ROOT / "cogs" / "league.py").read_text(encoding="utf-8")
    task_source = (ROOT / "cogs" / "battle_pass_tasks.py").read_text(encoding="utf-8")
    assert "proof_id=0" not in league_source
    assert "submit_direct_challenge_proof" in league_source
    assert "submit_bp_mission_proof" in task_source
    assert 'AdminReviewView("battle_pass", proof_id)' in task_source


def test_seasonal_battle_pass_routes_are_registered():
    from web.app import app

    paths = {route.path for route in app.routes}
    assert "/api/battlepass/seasons" in paths
    assert "/api/battlepass/missions" in paths
    assert "/api/battlepass/missions/{mission_id}" in paths


def test_admin_api_requires_a_selected_manageable_guild():
    from web.app import app, selected_guild

    protected = {
        "/api/islands", "/api/economy/adjust", "/api/proofs/review",
        "/api/battlepass/seasons", "/api/battlepass/missions",
        "/api/shortcuts", "/api/settings",
    }
    for path in protected:
        route = next(route for route in app.routes if getattr(route, "path", None) == path)
        assert any(dependency.call is selected_guild for dependency in route.dependant.dependencies), path


def test_role_hierarchy_supports_discord_role_ids(monkeypatch):
    from web.app import _staff_allowed
    monkeypatch.setenv("REQUIEM_ADMIN_ROLE_IDS", "123,456")
    monkeypatch.setenv("REQUIEM_PROOF_REVIEWER_ROLE_IDS", "789")
    user = {"id": "42"}
    guild = {"roles": ["789"]}
    assert _staff_allowed(user, guild, "proof_reviewer") is True
    assert _staff_allowed(user, guild, "admin") is False
    guild["roles"] = ["123"]
    assert _staff_allowed(user, guild, "admin") is True
    assert _staff_allowed(user, guild, "moderator") is True
