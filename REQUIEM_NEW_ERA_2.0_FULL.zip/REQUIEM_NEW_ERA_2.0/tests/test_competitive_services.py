from contextlib import closing
import asyncio
import sqlite3
import pytest
from utils import db
from utils import competitive


def setup(tmp_path, monkeypatch):
    path = tmp_path / "competitive.sqlite3"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    db.init_db()
    competitive.init_competitive_schema()
    return path


def test_elo_is_pending_until_admin_approval_and_idempotent(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    match_id = competitive.create_competitive_match(101, 202, "general", "match:101:202:1")
    assert competitive.create_competitive_match(101, 202, "general", "match:101:202:1") == match_id
    assert competitive.get_player_ratings(101)["general"]["games"] == 0
    competitive.submit_competitive_match_proof(match_id, 101, "https://example.test/elo.png", "result")
    result = competitive.review_competitive_match(match_id, "approved", 900, winner_id=101)
    assert result["status"] == "approved"
    ratings_a = competitive.get_player_ratings(101)["general"]
    ratings_b = competitive.get_player_ratings(202)["general"]
    assert ratings_a["wins"] == 1 and ratings_a["games"] == 1
    assert ratings_b["losses"] == 1 and ratings_b["games"] == 1
    assert ratings_a["rating"] > 1000 > ratings_b["rating"]
    with pytest.raises(LookupError):
        competitive.review_competitive_match(match_id, "approved", 900, winner_id=101)


def test_tournament_and_general_elo_are_separate(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    mid = competitive.create_competitive_match(1, 2, "tournament", "tournament:1")
    competitive.submit_competitive_match_proof(mid, 2, "https://example.test/tournament.png", "result")
    competitive.review_competitive_match(mid, "approved", 77, winner_id=2)
    ratings = competitive.get_player_ratings(2)
    assert ratings["tournament"]["wins"] == 1
    assert ratings["general"]["games"] == 0


def test_matchmaking_pairs_nearest_rating_and_cannot_self_match(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    first = competitive.queue_for_match(11)
    assert first["status"] == "waiting"
    second = competitive.queue_for_match(22)
    assert second["status"] == "matched"
    assert second["opponent_id"] == 11
    assert competitive.leave_matchmaking(11) is False


def test_inventory_purchase_is_atomic_and_idempotent(tmp_path, monkeypatch):
    path = setup(tmp_path, monkeypatch)
    with closing(sqlite3.connect(path)) as conn:
        conn.execute("INSERT INTO users(user_id,username,coins,gems,bounty,points) VALUES(1,'buyer',100,0,0,0)")
        conn.commit()
    competitive.upsert_cosmetic("poster_gold", "Golden Poster", "profile_frame", "coins", 40, "rare")
    result = competitive.purchase_cosmetic(1, "poster_gold", "buy:1:poster_gold")
    again = competitive.purchase_cosmetic(1, "poster_gold", "buy:1:poster_gold")
    assert result == again
    with closing(sqlite3.connect(path)) as conn:
        assert conn.execute("SELECT coins FROM users WHERE user_id=1").fetchone()[0] == 60
        assert conn.execute("SELECT COUNT(*) FROM player_inventory WHERE user_id=1").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM economy_transactions WHERE user_id=1").fetchone()[0] == 1


def test_rivals_wanted_board_and_abuse_flags(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    competitive.set_rival(10, 20)
    assert competitive.list_rivals(10)[0]["rival_id"] == 20
    flag = competitive.create_abuse_flag(10, "suspicious_winrate", "manual review", "high")
    assert competitive.review_abuse_flag(flag, 99, "reviewed") is True
    assert competitive.review_abuse_flag(flag, 99, "dismissed") is False
    assert "general_elo" in competitive.wanted_board()


def test_direct_challenge_proof_approval_updates_general_elo(tmp_path, monkeypatch):
    from web import store
    path = tmp_path / "challenge-elo.sqlite3"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    import asyncio
    asyncio.run(store.initialize())
    challenge_id = asyncio.run(store.create_direct_challenge(1, 10, 1001, 1002))
    asyncio.run(store.update_direct_challenge(challenge_id, "active"))
    proof_id = asyncio.run(store.submit_direct_challenge_proof(challenge_id, 1001, "https://example.test/proof.png", "result"))
    asyncio.run(store.review_proof("league", proof_id, "approved", 900, "verified"))
    assert competitive.get_player_ratings(1001)["general"]["wins"] == 1
    assert competitive.get_player_ratings(1002)["general"]["losses"] == 1


def test_tournament_size_32_is_supported(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    asyncio.run(db.init_league_tables())
    tournament_id = asyncio.run(db.create_tournament("32-player cup", 32, 55))
    assert tournament_id > 0


def test_cosmetic_equipping_is_category_exclusive(tmp_path, monkeypatch):
    path = setup(tmp_path, monkeypatch)
    with closing(sqlite3.connect(path)) as conn:
        conn.execute("INSERT INTO users(user_id,username,coins,gems,bounty,points) VALUES(1,'collector',100,0,0,0)")
        conn.commit()
    competitive.upsert_cosmetic("frame_a", "Frame A", "profile_frame", "coins", 10)
    competitive.upsert_cosmetic("frame_b", "Frame B", "profile_frame", "coins", 10)
    competitive.purchase_cosmetic(1, "frame_a", "buy:a:unique")
    competitive.purchase_cosmetic(1, "frame_b", "buy:b:unique")
    assert competitive.equip_inventory_item(1, "frame_a") is True
    assert competitive.equip_inventory_item(1, "frame_b") is True
    items = competitive.player_inventory(1)
    assert sum(int(item["equipped"]) for item in items) == 1
    assert next(item for item in items if item["item_id"] == "frame_b")["equipped"] == 1


def test_season_archive_is_persistent_and_one_time(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    competitive.create_competitive_match(1, 2, "general", "season-match-1")
    competitive.submit_competitive_match_proof(1, 1, "https://example.test/season.png", "result")
    competitive.review_competitive_match(1, "approved", 9, winner_id=1)
    season_id = competitive.create_competitive_season("Season One", "2026-01-01", "2026-02-01")
    competitive.activate_competitive_season(season_id)
    archived = competitive.archive_competitive_season(season_id)
    assert archived >= 1
    assert competitive.list_competitive_seasons()[0]["status"] == "archived"
    with pytest.raises(LookupError):
        competitive.archive_competitive_season(season_id)


def test_anti_smurf_signal_is_review_only_and_not_a_ban(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    for n in range(10):
        mid = competitive.create_competitive_match(500, 600+n, "general", f"risk-match-{n}")
        competitive.submit_competitive_match_proof(mid, 500, f"https://example.test/risk-{n}.png", "result")
        competitive.review_competitive_match(mid, "approved", 99, winner_id=500)
    with competitive._conn() as conn:
        flag = conn.execute("SELECT * FROM anti_abuse_flags WHERE user_id=500 AND category='high_win_rate'").fetchone()
    assert flag is not None
    assert flag["status"] == "open"
    assert flag["severity"] == "review"


def test_ranked_proof_uses_shared_admin_review_and_only_then_changes_elo(tmp_path, monkeypatch):
    from web import store
    path = tmp_path / "ranked-proof.sqlite3"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(store.initialize())
    match_id = competitive.create_competitive_match(301, 302, "general", "ranked-proof:301:302")
    competitive.submit_competitive_match_proof(match_id, 301, "https://example.test/ranked.png", "Victory screenshot")
    pending = asyncio.run(store.list_proofs("pending"))
    assert any(p["type"] == "competitive" and p["id"] == match_id for p in pending)
    assert competitive.get_player_ratings(301)["general"]["games"] == 0
    result = asyncio.run(store.review_proof("competitive", match_id, "approved", 900, "verified"))
    assert result["user_id"] == 301
    assert result["reward"]["elo_delta_p1"] > 0
    assert competitive.get_player_ratings(301)["general"]["wins"] == 1
    with pytest.raises(LookupError):
        asyncio.run(store.review_proof("competitive", match_id, "approved", 900, "duplicate"))


def test_achievement_unlock_and_reward_claim_are_one_time(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    competitive.create_achievement({
        "achievement_id": "first_win", "title": "First Victory", "description": "Win one ranked match",
        "category": "permanent", "trigger_key": "general_win", "target": 1,
        "reward_points": 50, "reward_coins": 25, "reward_gems": 1, "reward_bounty": 10,
        "title_reward": "Rookie Hunter", "badge_reward": "first_win", "active": True,
    })
    from web import store
    path = __import__("pathlib").Path(db.DB_PATH)
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(store.initialize())
    mid = competitive.create_competitive_match(70, 71, "general", "achievement-match-1")
    competitive.submit_competitive_match_proof(mid, 70, "https://example.test/win.png", "win")
    asyncio.run(store.review_proof("competitive", mid, "approved", 99, "verified"))
    rows = competitive.list_player_achievements(70)
    unlocked = next(x for x in rows if x["achievement_id"] == "first_win")
    assert unlocked["unlocked_at"] is not None
    claimed = competitive.claim_achievement(70, "first_win", unlocked["period_key"])
    assert claimed["rewards"]["points"] == 50
    with pytest.raises(LookupError):
        competitive.claim_achievement(70, "first_win", unlocked["period_key"])
    with competitive._conn() as conn:
        assert conn.execute("SELECT coins FROM users WHERE user_id=70").fetchone()[0] == 25
        assert conn.execute("SELECT COUNT(*) FROM economy_transactions WHERE user_id=70 AND reason='achievement reward: first_win'").fetchone()[0] == 4


def test_hidden_achievement_is_hidden_until_unlocked(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    competitive.create_achievement({"achievement_id":"secret","title":"Secret","category":"permanent","trigger_key":"special","target":1,"hidden":True})
    assert competitive.list_player_achievements(808) == []
    competitive.record_achievement_progress(808,"special")
    assert len(competitive.list_player_achievements(808)) == 1


def test_daily_weekly_seasonal_shop_rotation_and_purchase_guard(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    with competitive._conn() as conn:
        conn.execute("INSERT INTO users(user_id,username,coins,gems,bounty,points) VALUES(1,'shopper',1000,0,0,0)")
    for i in range(8):
        competitive.upsert_cosmetic(f"daily_{i}", f"Daily {i}", "frame", "coins", 10, rotation="daily")
    current = competitive.rotating_shop("daily", 6)
    assert len(current) == 6
    selected = current[0]["item_id"]
    competitive.purchase_cosmetic(1, selected, "daily-purchase:1")
    not_selected = next(f"daily_{i}" for i in range(8) if f"daily_{i}" not in {x["item_id"] for x in current})
    with pytest.raises(LookupError):
        competitive.purchase_cosmetic(1, not_selected, "daily-purchase:blocked")


def test_full_32_player_bracket_creates_sixteen_first_round_matches(tmp_path, monkeypatch):
    from web import store
    path = tmp_path / "cup32.sqlite3"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(store.initialize())
    asyncio.run(db.init_league_tables())
    tournament_id = asyncio.run(db.create_tournament("Grand Line 32", 32, 999))
    for player_id in range(1000, 1032):
        assert asyncio.run(db.join_tournament(tournament_id, player_id)) is True
    matches = asyncio.run(store.start_tournament(tournament_id))
    assert len(matches) == 16
    assert len({m["player1_id"] for m in matches} | {m["player2_id"] for m in matches}) == 32


def test_matchmaking_status_recovers_match_for_both_players_and_prevents_duplicate_queue(tmp_path, monkeypatch):
    setup(tmp_path, monkeypatch)
    assert competitive.queue_for_match(9001)["status"] == "waiting"
    assert competitive.matchmaking_status(9001)["status"] == "waiting"
    matched = competitive.queue_for_match(9002)
    first_status = competitive.matchmaking_status(9001)
    assert matched["status"] == "matched"
    assert first_status["status"] == "matched"
    assert first_status["match_id"] == matched["match_id"]
    repeated = competitive.queue_for_match(9001)
    assert repeated["match_id"] == matched["match_id"]
