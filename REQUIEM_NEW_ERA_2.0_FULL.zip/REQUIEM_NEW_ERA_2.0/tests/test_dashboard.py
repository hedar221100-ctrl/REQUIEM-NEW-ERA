import asyncio
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from contextlib import contextmanager

from utils import db as bot_db
from web import store


@contextmanager
def sqlite_conn(path):
    conn = sqlite3.connect(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


class DashboardIntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_store_path = store.DB_PATH
        self.old_bot_path = bot_db.DB_PATH
        test_path = Path(self.temp.name) / "requiem-test.db"
        store.DB_PATH = test_path
        bot_db.DB_PATH = str(test_path)
        await store.initialize()
        with sqlite_conn(test_path) as conn:
            conn.execute(
                "INSERT OR IGNORE INTO users(user_id,username,streak,rank,points,coins,gems) VALUES(900001,'test-pirate',0,'المبتدئ',0,100,5)"
            )
        self.user_id = 900001

    async def asyncTearDown(self):
        store.DB_PATH = self.old_store_path
        bot_db.DB_PATH = self.old_bot_path
        self.temp.cleanup()

    async def test_existing_catalog_is_seeded(self):
        islands = await store.load_catalog()
        self.assertEqual(len(islands), 12)
        self.assertEqual(sum(len(x["missions"]) for x in islands), 36)
        self.assertEqual(len(store.get_characters()), 19)

    async def test_mission_crud_and_progress_are_kept_in_sync(self):
        await store.save_island({
            "id": "qa_island", "name": "QA Island", "emoji": "🏝️",
            "description": "test", "min_points": 0, "image_url": "", "order_index": 99,
        })
        for stage in (1, 2):
            await store.save_mission("qa_island", {
                "stage": stage, "description": f"Mission {stage}", "character_id": None,
                "alternatives": [], "reward_points": stage * 10,
                "reward_coins": stage * 20, "reward_gems": stage, "active": True,
            })
        islands = await store.load_catalog()
        test_island = next(x for x in islands if x["id"] == "qa_island")
        first_mission_id = test_island["missions"][0]["id"]
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute(
                "INSERT INTO grandline_progress(user_id,island_id,stage) VALUES(?,?,2)",
                (self.user_id, "qa_island"),
            )
        await store.delete_mission("qa_island", first_mission_id)
        islands = await store.load_catalog()
        test_island = next(x for x in islands if x["id"] == "qa_island")
        self.assertEqual(len(test_island["missions"]), 1)
        self.assertEqual(test_island["missions"][0]["desc"], "Mission 2")
        with sqlite_conn(store.DB_PATH) as conn:
            progress = conn.execute(
                "SELECT stage FROM grandline_progress WHERE user_id=? AND island_id=?",
                (self.user_id, "qa_island"),
            ).fetchone()[0]
        self.assertEqual(progress, 1)
        await store.delete_island("qa_island")

    async def test_proof_reward_is_atomic_and_cannot_be_claimed_twice(self):
        await store.save_island({
            "id": "reward_island", "name": "Reward Island", "emoji": "🏝️",
            "description": "test", "min_points": 0, "image_url": "", "order_index": 99,
        })
        await store.save_mission("reward_island", {
            "stage": 1, "description": "Win", "character_id": None,
            "alternatives": [], "reward_points": 77, "reward_coins": 88,
            "reward_gems": 2, "active": True,
        })
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute(
                "INSERT INTO grandline_proofs(user_id,island_id,stage,image_url,status) VALUES(?,?,?,?, 'pending')",
                (self.user_id, "reward_island", 1, "https://example.test/proof.png"),
            )
            proof_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            before = conn.execute(
                "SELECT points,coins,gems FROM users WHERE user_id=?", (self.user_id,)
            ).fetchone()
        result = await store.review_proof("grandline", proof_id, "approved", 123456, "test")
        self.assertEqual(
            (result["reward"]["points"], result["reward"]["coins"], result["reward"]["gems"]),
            (77, 88, 2),
        )
        self.assertTrue(result["reward"]["mission_progress"]["completed"])
        with self.assertRaises(LookupError):
            await store.review_proof("grandline", proof_id, "approved", 123456, "duplicate")
        with sqlite_conn(store.DB_PATH) as conn:
            after = conn.execute(
                "SELECT points,coins,gems FROM users WHERE user_id=?", (self.user_id,)
            ).fetchone()
        self.assertEqual(tuple(after[i] - before[i] for i in range(3)), (77, 88, 2))
        ledger = await store.economy_history(self.user_id)
        self.assertEqual({row["currency"] for row in ledger[:3]}, {"points", "coins", "gems"})
        await store.delete_island("reward_island")

    async def test_legacy_dashboard_tables_are_migrated_without_data_loss(self):
        temp = tempfile.TemporaryDirectory()
        old_store_path, old_bot_path = store.DB_PATH, bot_db.DB_PATH
        legacy_path = Path(temp.name) / "legacy.db"
        try:
            store.DB_PATH = legacy_path
            bot_db.DB_PATH = str(legacy_path)
            with sqlite_conn(legacy_path) as conn:
                conn.execute("CREATE TABLE league_submissions(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, image_url TEXT NOT NULL, description TEXT DEFAULT '', status TEXT DEFAULT 'pending', submitted_at TEXT)")
                conn.execute("INSERT INTO league_submissions(user_id,image_url,description,status,submitted_at) VALUES(1,'https://example.test/a.png','legacy','pending','2026-01-01')")
                conn.execute("CREATE TABLE battle_pass_tiers(id INTEGER PRIMARY KEY, tier INTEGER NOT NULL, required_points INTEGER NOT NULL, reward_coins INTEGER NOT NULL, reward_gems INTEGER NOT NULL)")
                conn.execute("INSERT INTO battle_pass_tiers(tier,required_points,reward_coins,reward_gems) VALUES(1,100,10,1)")
                conn.execute("CREATE TABLE tournaments(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,format TEXT NOT NULL DEFAULT 'single_elimination',status TEXT NOT NULL DEFAULT 'registration',created_by INTEGER NOT NULL,created_at TEXT)")
                conn.execute("INSERT INTO tournaments(name,created_by) VALUES('Legacy Cup',42)")
                conn.execute("CREATE TABLE tournament_matches(id INTEGER PRIMARY KEY AUTOINCREMENT,tournament_id INTEGER NOT NULL,round TEXT NOT NULL,player1_id INTEGER NOT NULL,player2_id INTEGER NOT NULL,winner_id INTEGER,score TEXT,proof_id INTEGER,status TEXT NOT NULL DEFAULT 'pending')")
            await store.initialize()
            with sqlite_conn(legacy_path) as conn:
                league_columns = {row[1] for row in conn.execute("PRAGMA table_info(league_submissions)")}
                bp_columns = {row[1] for row in conn.execute("PRAGMA table_info(battle_pass_tiers)")}
                tournament_columns = {row[1] for row in conn.execute("PRAGMA table_info(tournaments)")}
                match_columns = {row[1] for row in conn.execute("PRAGMA table_info(tournament_matches)")}
                legacy_row = conn.execute("SELECT description FROM league_submissions WHERE user_id=1").fetchone()
                bp_row = conn.execute("SELECT label FROM battle_pass_tiers WHERE tier=1").fetchone()
                tournament_row = conn.execute("SELECT size,creator_id FROM tournaments WHERE name='Legacy Cup'").fetchone()
            self.assertTrue({"reviewer_id", "review_note", "reviewed_at", "tournament_match_id", "opponent_id", "direct_challenge_id"} <= league_columns)
            self.assertIn("label", bp_columns)
            self.assertTrue({"size", "creator_id"} <= tournament_columns)
            self.assertTrue({"round_number", "match_number"} <= match_columns)
            self.assertEqual(legacy_row[0], "legacy")
            self.assertEqual(bp_row[0], "Reward")
            self.assertEqual(tuple(tournament_row), (8, 42))
        finally:
            store.DB_PATH, bot_db.DB_PATH = old_store_path, old_bot_path
            temp.cleanup()

    async def test_settings_save_preserves_streak_channel(self):
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute("INSERT OR REPLACE INTO guild_config(guild_id, log_channel_id, streak_channel_id) VALUES(?,?,?)", (777001, 111, 222))
        await store.set_settings(777001, 333, "watching", "REQUIEM | /profile")
        with sqlite_conn(store.DB_PATH) as conn:
            config = conn.execute("SELECT log_channel_id, streak_channel_id FROM guild_config WHERE guild_id=?", (777001,)).fetchone()
            settings = conn.execute("SELECT bot_status, status_text FROM dashboard_settings WHERE guild_id=?", (777001,)).fetchone()
        self.assertEqual(tuple(config), (333, 222))
        self.assertEqual(tuple(settings), ("watching", "REQUIEM | /profile"))

    async def test_battle_pass_claim_writes_currency_ledger_once(self):
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute("UPDATE users SET points=10000 WHERE user_id=?", (self.user_id,))
        tier = (await store.get_bp_tiers())[0]
        result = await store.claim_bp_tier(self.user_id, tier["tier"], tier["required_points"], tier["reward_coins"], tier["reward_gems"])
        self.assertTrue(result["success"])
        with sqlite_conn(store.DB_PATH) as conn:
            before = conn.execute("SELECT COUNT(*) FROM economy_transactions WHERE user_id=?", (self.user_id,)).fetchone()[0]
        duplicate = await store.claim_bp_tier(self.user_id, tier["tier"], tier["required_points"], tier["reward_coins"], tier["reward_gems"])
        self.assertFalse(duplicate["success"])
        with sqlite_conn(store.DB_PATH) as conn:
            after = conn.execute("SELECT COUNT(*) FROM economy_transactions WHERE user_id=?", (self.user_id,)).fetchone()[0]
        self.assertEqual(after, before)

    async def test_battle_pass_tier_crud_validates_duplicates(self):
        await store.save_bp_tier({"tier": 90, "required_points": 900, "reward_coins": 90, "reward_gems": 9, "label": "QA Tier"})
        tiers = await store.get_bp_tiers()
        tier = next(row for row in tiers if row["tier"] == 90)
        with self.assertRaises(ValueError):
            await store.save_bp_tier({"tier": 90, "required_points": 1, "reward_coins": 1, "reward_gems": 1, "label": "Duplicate"})
        await store.save_bp_tier({"tier": 91, "required_points": 910, "reward_coins": 91, "reward_gems": 10, "label": "Updated QA Tier"}, tier["id"])
        updated = next(row for row in await store.get_bp_tiers() if row["id"] == tier["id"])
        self.assertEqual(updated["tier"], 91)
        self.assertEqual(updated["label"], "Updated QA Tier")
        self.assertTrue(await store.delete_bp_tier(tier["id"]))
        self.assertFalse(await store.delete_bp_tier(tier["id"]))

    async def test_shortcuts_can_be_created_updated_and_deleted(self):
        await store.save_shortcut("!rules", "text", "قوانين السيرفر")
        rows = await store.get_shortcuts()
        self.assertTrue(any(row["trigger_text"] == "!rules" and row["action_data"] == "قوانين السيرفر" for row in rows))
        await store.save_shortcut("!guide", "text", "الدليل", original_trigger="!rules")
        rows = await store.get_shortcuts()
        self.assertFalse(any(row["trigger_text"] == "!rules" for row in rows))
        self.assertTrue(any(row["trigger_text"] == "!guide" and row["action_data"] == "الدليل" for row in rows))
        with self.assertRaises(ValueError):
            await store.save_shortcut("!guide", "text", "مكرر")
        self.assertTrue(await store.delete_shortcut("!guide"))
        self.assertFalse(await store.delete_shortcut("!guide"))

    async def test_league_proof_grants_tournament_points_once(self):
        proof_id = await store.submit_league_proof(self.user_id, "https://example.test/league.png", "match proof")
        pending = await store.list_proofs()
        self.assertTrue(any(x["id"] == proof_id and x["type"] == "league" for x in pending))
        result = await store.review_proof("league", proof_id, "approved", 123456, "approved")
        approved = await store.list_proofs("approved")
        self.assertTrue(any(x["id"] == proof_id and x["type"] == "league" and x["review_note"] == "approved" for x in approved))
        self.assertEqual(result["reward"]["tournament_points"], 100)
        self.assertEqual(result["reward"]["coins"], 200)
        with self.assertRaises(LookupError):
            await store.review_proof("league", proof_id, "approved", 123456, "duplicate")
        with sqlite_conn(store.DB_PATH) as conn:
            total = conn.execute(
                "SELECT COALESCE(SUM(points),0) FROM tournament_points WHERE user_id=? AND tournament_id='season_1_requiem'",
                (self.user_id,),
            ).fetchone()[0]
        self.assertEqual(total, 100)



    async def test_grandline_multi_image_submission_counts_each_image(self):
        from utils.db import submit_grandline_proof
        await store.save_island({"id": "image_count_island", "name": "Image Count", "emoji": "🏝️", "description": "", "min_points": 0, "image_url": "", "order_index": 98})
        await store.save_mission("image_count_island", {"stage": 1, "description": "Two screenshots", "character_id": None, "alternatives": [], "reward_points": 55, "reward_coins": 66, "reward_gems": 1, "required_count": 2, "active": True})
        proof_id = await submit_grandline_proof(self.user_id, "image_count_island", 1, "https://example.test/one.png", "two images", 2, 2)
        result = await store.review_proof("grandline", proof_id, "approved", 123, "verified")
        self.assertEqual(result["reward"]["mission_progress"], {"current": 2, "required": 2, "completed": True})
        self.assertEqual(result["reward"]["points"], 55)
        await store.delete_island("image_count_island")

    async def test_grandline_multi_proof_mission_pays_only_after_required_count(self):
        await store.save_island({"id": "multi_island", "name": "Multi", "emoji": "🏝️", "description": "", "min_points": 0, "image_url": "", "order_index": 99})
        await store.save_mission("multi_island", {"stage": 1, "description": "Two proofs", "character_id": None, "alternatives": [], "reward_points": 30, "reward_coins": 40, "reward_gems": 1, "required_count": 2, "active": True})
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute("INSERT INTO grandline_proofs(user_id,island_id,stage,image_url,status) VALUES(?,?,1,?,'pending')", (self.user_id, "multi_island", "https://example.test/a.png"))
            first_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        first = await store.review_proof("grandline", first_id, "approved", 123, "first")
        self.assertFalse(first["reward"]["mission_progress"]["completed"])
        self.assertEqual(first["reward"]["points"], 0)
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute("INSERT INTO grandline_proofs(user_id,island_id,stage,image_url,status) VALUES(?,?,1,?,'pending')", (self.user_id, "multi_island", "https://example.test/b.png"))
            second_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        second = await store.review_proof("grandline", second_id, "approved", 123, "second")
        self.assertTrue(second["reward"]["mission_progress"]["completed"])
        self.assertEqual(second["reward"]["points"], 30)
        await store.delete_island("multi_island")

    async def test_seasonal_battle_pass_mission_progress_and_reward_are_atomic(self):
        season_id = await store.save_bp_season({
            "name": "QA Season", "description": "seasonal test", "active": True,
        })
        second_season_id = await store.save_bp_season({"name": "QA Season 2", "active": True})
        seasons = await store.list_bp_seasons()
        self.assertEqual([season["id"] for season in seasons if season["active"]], [second_season_id])
        # Create the test mission in the active season.
        season_id = second_season_id
        mission_id = await store.save_bp_mission({
            "season_id": season_id, "title": "Two wins", "description": "Submit two proofs",
            "required_count": 2, "reward_points": 40, "reward_coins": 60,
            "reward_gems": 2, "active": True,
        })
        first_id = await store.submit_bp_mission_proof(self.user_id, mission_id, "https://example.test/1.png")
        first = await store.review_proof("battle_pass", first_id, "approved", 123, "first proof")
        with self.assertRaises(ValueError):
            await store.save_bp_mission({
                "season_id": season_id, "title": "Two wins", "description": "Submit two proofs",
                "required_count": 2, "reward_points": 999, "reward_coins": 60,
                "reward_gems": 2, "active": True,
            }, mission_id)
        self.assertEqual(first["reward"]["mission_progress"], {"current": 1, "required": 2, "completed": False})
        self.assertEqual(first["reward"]["points"], 0)
        player_missions = await store.get_user_bp_missions(self.user_id)
        self.assertEqual(next(m for m in player_missions if m["id"] == mission_id)["user_progress"], 1)

        second_id = await store.submit_bp_mission_proof(self.user_id, mission_id, "https://example.test/2.png")
        second = await store.review_proof("battle_pass", second_id, "approved", 123, "second proof")
        self.assertEqual(second["reward"]["mission_progress"], {"current": 2, "required": 2, "completed": True})
        self.assertEqual((second["reward"]["points"], second["reward"]["coins"], second["reward"]["gems"]), (40, 60, 2))
        with self.assertRaises(LookupError):
            await store.submit_bp_mission_proof(self.user_id, mission_id, "https://example.test/3.png")
        with sqlite_conn(store.DB_PATH) as conn:
            balance = conn.execute("SELECT points,coins,gems FROM users WHERE user_id=?", (self.user_id,)).fetchone()
        self.assertEqual(tuple(balance), (40, 160, 7))

    async def test_streak_challenge_proofs_use_shared_review_and_reward_once(self):
        with sqlite_conn(store.DB_PATH) as conn:
            cur = conn.execute(
                "INSERT INTO streak_challenges(name,description,required_wins,reward_points,reward_coins,reward_gems,active) VALUES(?,?,?,?,?,?,1)",
                ("QA streak", "three wins", 3, 25, 50, 1),
            )
            challenge_id = cur.lastrowid
        proof_id = await store.submit_streak_proof(self.user_id, challenge_id, "https://example.test/streak.png")
        listed = await store.list_proofs("pending")
        self.assertTrue(any(p["type"] == "streak" and p["id"] == proof_id for p in listed))
        result = await store.review_proof("streak", proof_id, "approved", 123, "valid")
        self.assertEqual((result["reward"]["points"], result["reward"]["coins"], result["reward"]["gems"]), (25, 50, 1))
        with self.assertRaises(LookupError):
            await store.submit_streak_proof(self.user_id, challenge_id, "https://example.test/duplicate.png")

    async def test_tournament_bracket_advances_after_reviewed_results(self):
        from utils.db import create_tournament, join_tournament

        tournament_id = await create_tournament("QA Cup", 4, self.user_id)
        players = [self.user_id, 900002, 900003, 900004]
        for player_id in players:
            self.assertTrue(await join_tournament(tournament_id, player_id))
        first_round = await store.start_tournament(tournament_id)
        self.assertEqual(len(first_round), 2)

        for match in first_round:
            proof = await store.submit_tournament_match_proof(
                match["player1_id"], "https://example.test/match.png", "round one"
            )
            await store.review_proof("league", proof["proof_id"], "approved", 123, "winner confirmed")

        with sqlite_conn(store.DB_PATH) as conn:
            cursor = conn.execute(
                "SELECT * FROM tournament_matches WHERE tournament_id=? AND round_number=2", (tournament_id,)
            )
            second_round = cursor.fetchall()
            column_names = [column[0] for column in cursor.description]
        self.assertEqual(len(second_round), 1)
        final_match = dict(zip(column_names, second_round[0]))
        proof = await store.submit_tournament_match_proof(
            final_match["player1_id"], "https://example.test/final.png", "final"
        )
        await store.review_proof("league", proof["proof_id"], "approved", 123, "final approved")
        with sqlite_conn(store.DB_PATH) as conn:
            status = conn.execute("SELECT status FROM tournaments WHERE id=?", (tournament_id,)).fetchone()[0]
        self.assertEqual(status, "completed")

    async def test_direct_challenge_requires_a_real_proof_and_finishes_after_review(self):
        challenge_id = await store.create_direct_challenge(1, 2, self.user_id, 900005)
        await store.update_direct_challenge(challenge_id, "pending", challenge_message_id=111)
        await store.update_direct_challenge(challenge_id, "active", thread_id=222, result_message_id=333)
        proof_id = await store.submit_direct_challenge_proof(challenge_id, self.user_id, "https://example.test/challenge.png", "challenge proof")
        with self.assertRaises(LookupError):
            await store.submit_direct_challenge_proof(challenge_id, 900005, "https://example.test/duplicate.png", "duplicate")
        rejected = await store.review_proof("league", proof_id, "rejected", 123, "need clearer result")
        self.assertEqual(rejected["status"], "rejected")
        with sqlite_conn(store.DB_PATH) as conn:
            state = conn.execute("SELECT status FROM direct_challenges WHERE id=?", (challenge_id,)).fetchone()[0]
        self.assertEqual(state, "active")
        second_proof = await store.submit_direct_challenge_proof(challenge_id, 900005, "https://example.test/challenge2.png", "retry")
        approved = await store.review_proof("league", second_proof, "approved", 123, "winner confirmed")
        self.assertEqual(approved["reward"]["tournament_points"], 100)
        with sqlite_conn(store.DB_PATH) as conn:
            state = conn.execute("SELECT status,winner_id FROM direct_challenges WHERE id=?", (challenge_id,)).fetchone()
        self.assertEqual(tuple(state), ("completed", 900005))

    async def test_daily_and_weekly_mission_progress_advances_only_for_current_period(self):
        from datetime import datetime, timezone, timedelta
        from utils.db import submit_hunter_quest
        today = datetime.now(timezone.utc).date().isoformat()
        week_key = datetime.now(timezone.utc).strftime("%G-W%V")
        with sqlite_conn(store.DB_PATH) as conn:
            conn.execute("UPDATE users SET daily_index=0,last_daily_reset=? ,weekly_index=0,last_weekly_reset=? WHERE user_id=?", (today, week_key, self.user_id))
        daily_id = await submit_hunter_quest(self.user_id, "daily", "daily QA", "https://example.test/daily.png", "daily_mission", today)
        with self.assertRaises(ValueError):
            await submit_hunter_quest(self.user_id, "daily", "daily QA", "https://example.test/duplicate.png", "daily_mission", today)
        await store.review_proof("hunter", daily_id, "approved", 123, "daily accepted")
        with self.assertRaises(ValueError):
            await submit_hunter_quest(self.user_id, "daily", "daily QA", "https://example.test/duplicate-after-approval.png", "daily_mission", today)
        weekly_id = await submit_hunter_quest(self.user_id, "weekly", "weekly QA", "https://example.test/weekly.png", "weekly_mission", week_key)
        await store.review_proof("hunter", weekly_id, "approved", 123, "weekly accepted")
        stale_period = (datetime.now(timezone.utc).date() - timedelta(days=1)).isoformat()
        stale_id = await submit_hunter_quest(self.user_id, "daily", "old daily", "https://example.test/old.png", "daily_mission", stale_period)
        await store.review_proof("hunter", stale_id, "approved", 123, "old proof")
        with sqlite_conn(store.DB_PATH) as conn:
            row = conn.execute("SELECT daily_index,weekly_index FROM users WHERE user_id=?", (self.user_id,)).fetchone()
        self.assertEqual(tuple(row), (1, 1))

    async def test_new_player_can_claim_first_daily_streak_immediately(self):
        from utils.db import claim_daily_streak
        result = await claim_daily_streak(910001, "first-day-pirate")
        self.assertTrue(result["success"])
        self.assertEqual(result["streak"], 1)
        duplicate = await claim_daily_streak(910001, "first-day-pirate")
        self.assertFalse(duplicate["success"])
        self.assertEqual(duplicate["reason"], "already_claimed")

if __name__ == "__main__":
    unittest.main()
