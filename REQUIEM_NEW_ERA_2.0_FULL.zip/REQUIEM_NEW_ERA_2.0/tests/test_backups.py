from contextlib import closing
import sqlite3
from utils.backups import backup_database, database_health


def test_backup_is_consistent_and_health_check_passes(tmp_path):
    db_path = tmp_path / "live.sqlite3"
    backup_dir = tmp_path / "backups"
    with closing(sqlite3.connect(db_path)) as conn:
        conn.execute("CREATE TABLE wallet(user_id INTEGER PRIMARY KEY, coins INTEGER NOT NULL)")
        conn.execute("INSERT INTO wallet VALUES(1, 123)")
        conn.commit()
    backup = backup_database(db_path, backup_dir, keep=3, min_interval_seconds=0)
    assert backup and backup.exists()
    with closing(sqlite3.connect(backup)) as conn:
        assert conn.execute("SELECT coins FROM wallet WHERE user_id=1").fetchone()[0] == 123
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert database_health(db_path)["ok"] is True


def test_application_initialization_backs_up_existing_database_before_migrations(tmp_path, monkeypatch):
    import asyncio
    from web import store
    from utils import db
    live = tmp_path / "production.sqlite3"
    with closing(sqlite3.connect(live)) as conn:
        conn.execute("CREATE TABLE users(user_id INTEGER PRIMARY KEY, username TEXT, points INTEGER)")
        conn.execute("INSERT INTO users VALUES(321,'legacy pirate',9876)")
        conn.commit()
    monkeypatch.setattr(store, "DB_PATH", live)
    monkeypatch.setattr(db, "DB_PATH", str(live))
    asyncio.run(store.initialize())
    backups = list((tmp_path / "backups").glob("requiem_*.sqlite3"))
    assert backups
    with closing(sqlite3.connect(backups[0])) as conn:
        assert conn.execute("SELECT points FROM users WHERE user_id=321").fetchone()[0] == 9876
    with closing(sqlite3.connect(live)) as conn:
        assert conn.execute("SELECT points FROM users WHERE user_id=321").fetchone()[0] == 9876
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
