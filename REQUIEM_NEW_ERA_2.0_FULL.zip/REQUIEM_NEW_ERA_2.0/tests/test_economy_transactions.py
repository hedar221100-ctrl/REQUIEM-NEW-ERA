from contextlib import closing
import asyncio
import pytest

from utils import db


def setup_database(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "economy-test.db"))
    asyncio.run(db.async_init_db())
    asyncio.run(db.get_user_data(1001, "sender"))
    asyncio.run(db.get_user_data(1002, "receiver"))
    assert asyncio.run(db.add_coins(1001, 500)) is True
    assert asyncio.run(db.add_gems(1001, 10)) is True


def test_add_remove_currency_rejects_negative_or_zero(tmp_path, monkeypatch):
    setup_database(tmp_path, monkeypatch)
    with pytest.raises(ValueError):
        asyncio.run(db.add_coins(1001, -10))
    with pytest.raises(ValueError):
        asyncio.run(db.remove_coins(1001, -10))
    with pytest.raises(ValueError):
        asyncio.run(db.add_gems(1001, 0))
    assert asyncio.run(db.get_user_data(1001))["coins"] == 500


def test_remove_cannot_overdraw_and_records_history(tmp_path, monkeypatch):
    setup_database(tmp_path, monkeypatch)
    assert asyncio.run(db.remove_coins(1001, 600)) is False
    assert asyncio.run(db.get_user_data(1001))["coins"] == 500
    assert asyncio.run(db.remove_coins(1001, 125)) is True
    data = asyncio.run(db.get_user_data(1001))
    assert data["coins"] == 375
    history = asyncio.run(db.get_economy_history(1001))
    assert history[0]["currency"] == "coins"
    assert history[0]["delta"] == -125
    assert history[0]["balance_after"] == 375


def test_transfer_is_atomic_and_auto_creates_recipient_wallet(tmp_path, monkeypatch):
    setup_database(tmp_path, monkeypatch)
    assert asyncio.run(db.transfer_coins(1001, 9999, 100)) is True
    assert asyncio.run(db.get_user_data(1001))["coins"] == 400
    assert asyncio.run(db.get_user_data(9999))["coins"] == 100
    with pytest.raises(ValueError):
        asyncio.run(db.transfer_coins(1001, 1002, -50))
    with pytest.raises(ValueError):
        asyncio.run(db.transfer_coins(1001, 1001, 50))
    assert asyncio.run(db.transfer_coins(1001, 1002, 150)) is True
    assert asyncio.run(db.get_user_data(1001))["coins"] == 250
    assert asyncio.run(db.get_user_data(1002))["coins"] == 150
    assert len(asyncio.run(db.get_economy_history(1001))) == 4
    assert len(asyncio.run(db.get_economy_history(1002))) == 1


def test_positive_rewards_create_wallet_for_new_players(tmp_path, monkeypatch):
    setup_database(tmp_path, monkeypatch)
    assert asyncio.run(db.add_coins(7777, 25)) is True
    assert asyncio.run(db.add_gems(7777, 2)) is True
    data = asyncio.run(db.get_user_data(7777))
    assert data["coins"] == 25
    assert data["gems"] == 2
    history = asyncio.run(db.get_economy_history(7777))
    assert len(history) == 2


def test_dashboard_adjustment_is_audited_and_rejects_overdraft(tmp_path, monkeypatch):
    from web import store

    path = tmp_path / "dashboard-economy.db"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(store.initialize())
    asyncio.run(db.get_user_data(2001, "dashboard-pirate"))
    asyncio.run(db.add_coins(2001, 250))

    updated = asyncio.run(store.adjust_economy(2001, "coins", -100, 7654))
    assert updated["coins"] == 150
    with pytest.raises(ValueError, match="Insufficient balance"):
        asyncio.run(store.adjust_economy(2001, "coins", -151, 7654))
    history = asyncio.run(store.economy_history(2001))
    assert [row["delta"] for row in history[:2]] == [-100, 250]
    assert history[0]["actor_id"] == 7654


def test_shop_purchase_creates_pending_order_and_debits_once(tmp_path, monkeypatch):
    setup_database(tmp_path, monkeypatch)
    order_id = asyncio.run(db.create_shop_order(1001, "lootbox", "صندوق حظ", "gems", 5))
    assert order_id == 1
    assert asyncio.run(db.get_user_data(1001))["gems"] == 5
    assert asyncio.run(db.get_economy_history(1001))[0]["reason"] == "shop order #1: صندوق حظ"
    with pytest.raises(ValueError):
        asyncio.run(db.create_shop_order(1001, "lootbox", "صندوق حظ", "gems", -5))


def test_shop_order_fulfillment_is_one_time(tmp_path, monkeypatch):
    from web import store

    path = tmp_path / "shop-order.db"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(store.initialize())
    asyncio.run(db.get_user_data(3001, "buyer"))
    asyncio.run(db.add_coins(3001, 500))
    order_id = asyncio.run(db.create_shop_order(3001, "vip_role", "رتبة VIP", "coins", 100))
    pending = asyncio.run(store.list_shop_orders("pending"))
    assert len(pending) == 1 and pending[0]["id"] == order_id
    fulfilled = asyncio.run(store.fulfill_shop_order(order_id, 9001))
    assert fulfilled["status"] == "fulfilled"
    with pytest.raises(LookupError):
        asyncio.run(store.fulfill_shop_order(order_id, 9001))
    assert asyncio.run(store.list_shop_orders("pending")) == []


def test_bounty_is_a_separate_migrated_balance(tmp_path, monkeypatch):
    import sqlite3
    from web import store

    path = tmp_path / "bounty-migration.db"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(db.async_init_db())
    with closing(sqlite3.connect(path)) as conn:
        conn.execute("CREATE TABLE economy_transactions_legacy_tmp(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('points','coins','gems')),delta INTEGER NOT NULL CHECK(delta<>0),balance_after INTEGER NOT NULL,reason TEXT NOT NULL DEFAULT '',actor_id INTEGER,created_at TEXT NOT NULL)")
        conn.execute("INSERT INTO economy_transactions_legacy_tmp(user_id,currency,delta,balance_after,reason,created_at) VALUES(77,'coins',10,10,'old record','2026-01-01')")
        conn.execute("DROP TABLE economy_transactions")
        conn.execute("ALTER TABLE economy_transactions_legacy_tmp RENAME TO economy_transactions")
        conn.commit()
    asyncio.run(db.async_init_db())
    asyncio.run(store.initialize())
    asyncio.run(db.get_user_data(77, "bounty-pirate"))
    updated = asyncio.run(store.adjust_economy(77, "bounty", 900, 7654))
    assert updated["bounty"] == 900
    history = asyncio.run(store.economy_history(77))
    assert history[0]["currency"] == "bounty"
    assert history[1]["reason"] == "old record"


def test_dashboard_has_explicit_add_and_deduct_controls():
    from pathlib import Path
    dashboard = Path(__file__).resolve().parents[1] / "web" / "static" / "dashboard.html"
    html = dashboard.read_text(encoding="utf-8")
    assert 'name="economy-operation" value="add"' in html
    assert 'name="economy-operation" value="subtract"' in html
    assert 'id="economy-operation-preview"' in html


def test_admin_adjustment_creates_wallet_for_new_player_on_positive_reward(tmp_path, monkeypatch):
    from web import store
    path = tmp_path / "new-admin-wallet.db"
    monkeypatch.setattr(db, "DB_PATH", str(path))
    monkeypatch.setattr(store, "DB_PATH", path)
    asyncio.run(store.initialize())
    result = asyncio.run(store.adjust_economy(8888, "bounty", 450, 777))
    assert result["bounty"] == 450
    history = asyncio.run(store.economy_history(8888))
    assert history[0]["currency"] == "bounty"
    assert history[0]["delta"] == 450
    with pytest.raises(LookupError):
        asyncio.run(store.adjust_economy(9999, "bounty", -1, 777))
