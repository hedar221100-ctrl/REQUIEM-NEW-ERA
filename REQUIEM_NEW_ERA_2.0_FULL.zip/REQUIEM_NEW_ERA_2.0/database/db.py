"""قاعدة البيانات: SQLite + نسخ احتياطي. كل العمليات آمنة (transactions)."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import config

SCHEMA = Path(__file__).with_name("schema.sql")


def connect(path=None) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path or config.DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def tx(path=None):
    """عملية آمنة: إذا صار خطأ، كلشي يرجع مثل ما كان."""
    conn = connect(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path=None):
    """ينشئ الجداول إذا مو موجودة. ما يمسح أي بيانات."""
    Path(path or config.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with tx(path) as c:
        c.executescript(SCHEMA.read_text(encoding="utf-8"))


def log_action(conn, actor_id: int, action: str, details: str = ""):
    conn.execute(
        "INSERT INTO audit_logs(actor_id, action, details) VALUES (?,?,?)",
        (actor_id, action, details),
    )


def backup(path=None, backup_dir=None, keep=None) -> Path:
    """نسخة احتياطية آمنة (حتى والبوت شغال) + حذف النسخ القديمة."""
    backup_dir = Path(backup_dir or config.BACKUP_DIR)
    backup_dir.mkdir(parents=True, exist_ok=True)
    dest = backup_dir / f"requiem_{datetime.now():%Y%m%d_%H%M%S_%f}.db"
    src = connect(path)
    dst = sqlite3.connect(str(dest))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    old = sorted(backup_dir.glob("requiem_*.db"))
    for f in old[: -(keep or config.KEEP_BACKUPS)]:
        f.unlink()
    return dest
