PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS factions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    emoji TEXT DEFAULT '🏴‍☠️',
    color INTEGER DEFAULT 0,
    leader_id INTEGER,
    influence INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS islands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT DEFAULT '',
    order_index INTEGER NOT NULL DEFAULT 0,
    required_crew_wins INTEGER NOT NULL DEFAULT 0,
    unlocked INTEGER NOT NULL DEFAULT 0,
    controlling_faction_id INTEGER REFERENCES factions(id)
);

CREATE TABLE IF NOT EXISTS users (
    discord_id INTEGER PRIMARY KEY,
    display_name TEXT DEFAULT '',
    faction_id INTEGER REFERENCES factions(id),
    current_island_id INTEGER REFERENCES islands(id),
    xp INTEGER NOT NULL DEFAULT 0,
    wins INTEGER NOT NULL DEFAULT 0,
    missions_done INTEGER NOT NULL DEFAULT 0,
    bounty INTEGER NOT NULL DEFAULT 0,
    joined_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS missions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    kind TEXT NOT NULL DEFAULT 'daily',
    scope TEXT NOT NULL DEFAULT 'solo',
    role TEXT,
    character TEXT,
    island_id INTEGER REFERENCES islands(id),
    xp_reward INTEGER NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- بصمة الصورة UNIQUE حتى ما تنحسب نفس الصورة مرتين
CREATE TABLE IF NOT EXISTS proofs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    submitter_id INTEGER NOT NULL,
    image_sha256 TEXT NOT NULL UNIQUE,
    image_phash TEXT,
    image_url TEXT,
    submitted_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS mission_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mission_id INTEGER NOT NULL REFERENCES missions(id),
    user_id INTEGER NOT NULL,
    proof_id INTEGER REFERENCES proofs(id),
    status TEXT NOT NULL DEFAULT 'pending',
    reviewed_by INTEGER,
    reviewed_at TEXT,
    note TEXT DEFAULT '',
    submitted_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tournaments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    format TEXT NOT NULL DEFAULT 'knockout',
    status TEXT NOT NULL DEFAULT 'registration',
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tournament_matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tournament_id INTEGER NOT NULL REFERENCES tournaments(id),
    round TEXT DEFAULT '',
    player1_id INTEGER, player2_id INTEGER,
    winner_id INTEGER,
    score TEXT DEFAULT '',
    proof_id INTEGER REFERENCES proofs(id),
    status TEXT NOT NULL DEFAULT 'scheduled'
);

CREATE TABLE IF NOT EXISTS seasons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    theme TEXT DEFAULT '',
    starts_at TEXT, ends_at TEXT,
    active INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS battle_pass_progress (
    season_id INTEGER NOT NULL REFERENCES seasons(id),
    user_id INTEGER NOT NULL,
    xp INTEGER NOT NULL DEFAULT 0,
    tier INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (season_id, user_id)
);

CREATE TABLE IF NOT EXISTS achievements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    season_id INTEGER,
    earned_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rewards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'title',
    tier_required INTEGER,
    description TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    island_id INTEGER REFERENCES islands(id),
    starts_at TEXT, ends_at TEXT,
    active INTEGER NOT NULL DEFAULT 0
);

-- event_key UNIQUE = نفس الإنجاز ما ينحسب مرتين
CREATE TABLE IF NOT EXISTS progress_ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_key TEXT NOT NULL UNIQUE,
    user_id INTEGER NOT NULL,
    source TEXT NOT NULL,
    xp INTEGER NOT NULL DEFAULT 0,
    wins INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    details TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT OR IGNORE INTO settings(key, value) VALUES ('schema_version', '1');

-- جداول نظام الستريك (Streak)
CREATE TABLE IF NOT EXISTS streak_challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    required_wins INTEGER NOT NULL DEFAULT 3,
    character_id TEXT,
    alternatives_json TEXT DEFAULT '[]',
    reward_points INTEGER DEFAULT 0,
    reward_coins INTEGER DEFAULT 0,
    reward_gems INTEGER DEFAULT 0,
    image_url TEXT DEFAULT '',
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS streak_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    challenge_id INTEGER NOT NULL REFERENCES streak_challenges(id),
    image_url TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    submitted_at TEXT NOT NULL DEFAULT (datetime('now')),
    reviewed_by INTEGER,
    reviewed_at TEXT,
    note TEXT DEFAULT ''
);

-- إضافة عمود لتتبع تقدم المهام المتعددة في جدول الإثباتات الحالي


-- Direct challenges are persisted so their Discord buttons can be restored after restarts.
CREATE TABLE IF NOT EXISTS direct_challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    channel_id INTEGER NOT NULL,
    challenger_id INTEGER NOT NULL,
    opponent_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    thread_id INTEGER,
    challenge_message_id INTEGER,
    result_message_id INTEGER,
    winner_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Seasonal Battle Pass missions are independent from tier rewards.
CREATE TABLE IF NOT EXISTS battle_pass_seasons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    starts_at TEXT,
    ends_at TEXT,
    active INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_bp_single_active_season ON battle_pass_seasons(active) WHERE active=1;
CREATE TABLE IF NOT EXISTS battle_pass_missions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    season_id INTEGER NOT NULL REFERENCES battle_pass_seasons(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    required_count INTEGER NOT NULL DEFAULT 1 CHECK(required_count > 0),
    reward_points INTEGER NOT NULL DEFAULT 0 CHECK(reward_points >= 0),
    reward_coins INTEGER NOT NULL DEFAULT 0 CHECK(reward_coins >= 0),
    reward_gems INTEGER NOT NULL DEFAULT 0 CHECK(reward_gems >= 0),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS battle_pass_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    mission_id INTEGER NOT NULL REFERENCES battle_pass_missions(id),
    image_url TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    reviewer_id INTEGER,
    review_note TEXT NOT NULL DEFAULT '',
    submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS battle_pass_mission_progress (
    user_id INTEGER NOT NULL,
    mission_id INTEGER NOT NULL REFERENCES battle_pass_missions(id),
    approved_count INTEGER NOT NULL DEFAULT 0,
    claimed_at TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(user_id, mission_id)
);


-- REQUIEM NEW ERA 2.0 competitive layer (idempotent additions)
CREATE TABLE IF NOT EXISTS discord_command_registry (
    scope_id INTEGER NOT NULL, command_name TEXT NOT NULL, command_id INTEGER NOT NULL,
    synced_at TEXT NOT NULL, PRIMARY KEY(scope_id, command_name)
);
CREATE TABLE IF NOT EXISTS streak_claims (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, claim_date TEXT NOT NULL,
    streak INTEGER NOT NULL, points_awarded INTEGER NOT NULL, coins_awarded INTEGER NOT NULL,
    gems_awarded INTEGER NOT NULL, created_at TEXT NOT NULL, UNIQUE(user_id, claim_date)
);
CREATE TABLE IF NOT EXISTS competitive_ratings (
    user_id INTEGER NOT NULL, mode TEXT NOT NULL CHECK(mode IN ('general','tournament')),
    rating INTEGER NOT NULL DEFAULT 1000 CHECK(rating >= 0), wins INTEGER NOT NULL DEFAULT 0,
    losses INTEGER NOT NULL DEFAULT 0, games INTEGER NOT NULL DEFAULT 0,
    peak_rating INTEGER NOT NULL DEFAULT 1000, updated_at TEXT NOT NULL,
    PRIMARY KEY(user_id, mode)
);
CREATE TABLE IF NOT EXISTS competitive_matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT, mode TEXT NOT NULL CHECK(mode IN ('general','tournament')),
    player1_id INTEGER NOT NULL, player2_id INTEGER NOT NULL, winner_id INTEGER,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','cancelled')),
    idempotency_key TEXT NOT NULL UNIQUE, proof_url TEXT DEFAULT '', proof_submitter_id INTEGER,
    reviewer_id INTEGER, review_note TEXT DEFAULT '', created_at TEXT NOT NULL, reviewed_at TEXT,
    rating_delta_p1 INTEGER, rating_delta_p2 INTEGER, CHECK(player1_id <> player2_id)
);
CREATE TABLE IF NOT EXISTS matchmaking_queue (
    user_id INTEGER PRIMARY KEY, mode TEXT NOT NULL DEFAULT 'general', rating INTEGER NOT NULL DEFAULT 1000,
    queued_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting','matched','cancelled'))
);
CREATE TABLE IF NOT EXISTS competitive_seasons (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, starts_at TEXT NOT NULL,
    ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','archived')),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS season_archive (
    id INTEGER PRIMARY KEY AUTOINCREMENT, season_id INTEGER NOT NULL, mode TEXT NOT NULL,
    user_id INTEGER NOT NULL, final_rating INTEGER NOT NULL, final_rank INTEGER NOT NULL,
    archived_at TEXT NOT NULL, UNIQUE(season_id, mode, user_id)
);
CREATE TABLE IF NOT EXISTS rival_pairs (
    user_low INTEGER NOT NULL, user_high INTEGER NOT NULL, created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL, PRIMARY KEY(user_low, user_high), CHECK(user_low < user_high)
);
CREATE TABLE IF NOT EXISTS cosmetic_catalog (
    item_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
    currency TEXT NOT NULL CHECK(currency IN ('coins','gems','bounty','points')),
    price INTEGER NOT NULL CHECK(price >= 0), rarity TEXT NOT NULL DEFAULT 'common',
    rotation TEXT NOT NULL DEFAULT 'permanent' CHECK(rotation IN ('daily','weekly','seasonal','permanent')),
    active INTEGER NOT NULL DEFAULT 1, metadata_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS player_inventory (
    user_id INTEGER NOT NULL, item_id TEXT NOT NULL REFERENCES cosmetic_catalog(item_id),
    acquired_at TEXT NOT NULL, source TEXT NOT NULL, equipped INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(user_id, item_id)
);
CREATE TABLE IF NOT EXISTS anti_abuse_flags (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, category TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'review', details TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','reviewed','dismissed')),
    created_at TEXT NOT NULL, reviewed_by INTEGER, reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS competitive_idempotency (
    idempotency_key TEXT PRIMARY KEY, operation TEXT NOT NULL, result_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS achievement_catalog (
  achievement_id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL CHECK(category IN ('daily','weekly','seasonal','permanent')),
  trigger_key TEXT NOT NULL, target INTEGER NOT NULL CHECK(target > 0),
  reward_points INTEGER NOT NULL DEFAULT 0 CHECK(reward_points >= 0),
  reward_coins INTEGER NOT NULL DEFAULT 0 CHECK(reward_coins >= 0),
  reward_gems INTEGER NOT NULL DEFAULT 0 CHECK(reward_gems >= 0),
  reward_bounty INTEGER NOT NULL DEFAULT 0 CHECK(reward_bounty >= 0),
  title_reward TEXT DEFAULT '', badge_reward TEXT DEFAULT '', hidden INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1, season_id INTEGER, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_achievements (
  user_id INTEGER NOT NULL, achievement_id TEXT NOT NULL REFERENCES achievement_catalog(achievement_id),
  period_key TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
  unlocked_at TEXT, claimed_at TEXT, PRIMARY KEY(user_id, achievement_id, period_key)
);
CREATE INDEX IF NOT EXISTS idx_achievement_trigger ON achievement_catalog(trigger_key,active,category);
