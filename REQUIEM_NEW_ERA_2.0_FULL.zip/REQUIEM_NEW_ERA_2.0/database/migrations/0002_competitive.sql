-- REQUIEM NEW ERA 2.0 competitive migration.
-- Safe to apply repeatedly. The Python initializer additionally adds the
-- proof_submitter_id column to pre-existing competitive_matches tables.
CREATE TABLE IF NOT EXISTS discord_command_registry (
  scope_id INTEGER NOT NULL, command_name TEXT NOT NULL, command_id INTEGER NOT NULL,
  synced_at TEXT NOT NULL, PRIMARY KEY(scope_id, command_name)
);
CREATE TABLE IF NOT EXISTS streak_claims (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, claim_date TEXT NOT NULL,
  streak INTEGER NOT NULL, points_awarded INTEGER NOT NULL, coins_awarded INTEGER NOT NULL,
  gems_awarded INTEGER NOT NULL, created_at TEXT NOT NULL, UNIQUE(user_id, claim_date)
);
CREATE TABLE IF NOT EXISTS competitive_ratings (
  user_id INTEGER NOT NULL, mode TEXT NOT NULL CHECK(mode IN ('general','tournament')),
  rating INTEGER NOT NULL DEFAULT 1000 CHECK(rating >= 0), wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0, games INTEGER NOT NULL DEFAULT 0,
  peak_rating INTEGER NOT NULL DEFAULT 1000, updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id, mode)
);
CREATE TABLE IF NOT EXISTS competitive_matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mode TEXT NOT NULL CHECK(mode IN ('general','tournament')),
  player1_id INTEGER NOT NULL, player2_id INTEGER NOT NULL, winner_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','cancelled')),
  idempotency_key TEXT NOT NULL UNIQUE, proof_url TEXT DEFAULT '', proof_submitter_id INTEGER,
  reviewer_id INTEGER, review_note TEXT DEFAULT '', created_at TEXT NOT NULL, reviewed_at TEXT,
  rating_delta_p1 INTEGER, rating_delta_p2 INTEGER, CHECK(player1_id <> player2_id)
);
CREATE TABLE IF NOT EXISTS matchmaking_queue (
  user_id INTEGER PRIMARY KEY, mode TEXT NOT NULL DEFAULT 'general', rating INTEGER NOT NULL DEFAULT 1000,
  queued_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting','matched','cancelled'))
);
CREATE TABLE IF NOT EXISTS competitive_seasons (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','active','archived')),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS season_archive (
  id INTEGER PRIMARY KEY AUTOINCREMENT, season_id INTEGER NOT NULL, mode TEXT NOT NULL,
  user_id INTEGER NOT NULL, final_rating INTEGER NOT NULL, final_rank INTEGER NOT NULL,
  archived_at TEXT NOT NULL, UNIQUE(season_id, mode, user_id)
);
CREATE TABLE IF NOT EXISTS rival_pairs (
  user_low INTEGER NOT NULL, user_high INTEGER NOT NULL, created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL, PRIMARY KEY(user_low, user_high), CHECK(user_low < user_high)
);
CREATE TABLE IF NOT EXISTS cosmetic_catalog (
  item_id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
  currency TEXT NOT NULL CHECK(currency IN ('coins','gems','bounty','points')),
  price INTEGER NOT NULL CHECK(price >= 0), rarity TEXT NOT NULL DEFAULT 'common',
  rotation TEXT NOT NULL DEFAULT 'permanent' CHECK(rotation IN ('daily','weekly','seasonal','permanent')),
  active INTEGER NOT NULL DEFAULT 1, metadata_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS player_inventory (
  user_id INTEGER NOT NULL, item_id TEXT NOT NULL REFERENCES cosmetic_catalog(item_id),
  acquired_at TEXT NOT NULL, source TEXT NOT NULL, equipped INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, item_id)
);
CREATE TABLE IF NOT EXISTS anti_abuse_flags (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, category TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'review', details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','reviewed','dismissed')),
  created_at TEXT NOT NULL, reviewed_by INTEGER, reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS competitive_idempotency (
  idempotency_key TEXT PRIMARY KEY, operation TEXT NOT NULL, result_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS achievement_catalog (
  achievement_id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL CHECK(category IN ('daily','weekly','seasonal','permanent')),
  trigger_key TEXT NOT NULL, target INTEGER NOT NULL CHECK(target > 0),
  reward_points INTEGER NOT NULL DEFAULT 0 CHECK(reward_points >= 0),
  reward_coins INTEGER NOT NULL DEFAULT 0 CHECK(reward_coins >= 0),
  reward_gems INTEGER NOT NULL DEFAULT 0 CHECK(reward_gems >= 0),
  reward_bounty INTEGER NOT NULL DEFAULT 0 CHECK(reward_bounty >= 0),
  title_reward TEXT DEFAULT '', badge_reward TEXT DEFAULT '', hidden INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1, season_id INTEGER, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS player_achievements (
  user_id INTEGER NOT NULL, achievement_id TEXT NOT NULL REFERENCES achievement_catalog(achievement_id),
  period_key TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
  unlocked_at TEXT, claimed_at TEXT, PRIMARY KEY(user_id, achievement_id, period_key)
);
CREATE INDEX IF NOT EXISTS idx_achievement_trigger ON achievement_catalog(trigger_key,active,category);
