from __future__ import annotations
import ast, asyncio, json, os, sqlite3, sys
from contextlib import closing
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.getenv("DB_PATH", str(ROOT / "database" / "requiem.db"))).resolve()
GENERAL_FILE = ROOT / "cogs" / "general.py"
_INITIALIZE_LOCK = asyncio.Lock()


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(DB_PATH), timeout=30, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA busy_timeout=30000")
    return c


def extract_literal(name: str, default):
    try:
        tree = ast.parse(GENERAL_FILE.read_text(encoding="utf-8"))
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
                return ast.literal_eval(node.value)
    except Exception:
        pass
    return default


def _catalog_from_db(conn):
    islands = conn.execute("SELECT * FROM dashboard_islands ORDER BY order_index,id").fetchall()
    result = []
    for island in islands:
        missions = conn.execute("SELECT * FROM dashboard_missions WHERE island_id=? AND active=1 ORDER BY stage,id", (island['id'],)).fetchall()
        result.append({
            "id": island["id"], "name": island["name"], "emoji": island["emoji"],
            "min_points": island["min_points"], "desc": island["description"],
            "image": island["image_url"],
            "missions": [{"id": m["id"], "desc": m["description"], "character": m["character_id"],
                          "alternatives": json.loads(m["alternatives_json"] or "[]"),
                          "reward_points": m["reward_points"], "reward_coins": m["reward_coins"],
                          "reward_gems": m["reward_gems"], "required_count": m["required_count"]} for m in missions]
        })
    return result


def refresh_live_catalog(catalog=None):
    catalog = catalog if catalog is not None else load_catalog_sync()
    mod = sys.modules.get("cogs.general")
    if mod is not None:
        mod.ISLANDS = catalog


def initialize_sync():
    original = extract_literal("ISLANDS", [])
    with closing(connect()) as c:
        # 1. إنشاء جداول لوحة التحكم، الباس، البطولات، الاختصارات، والستريك
        c.executescript("""
        CREATE TABLE IF NOT EXISTS dashboard_islands(
            id TEXT PRIMARY KEY, name TEXT NOT NULL, emoji TEXT NOT NULL DEFAULT '🏝️',
            description TEXT NOT NULL DEFAULT '', min_points INTEGER NOT NULL DEFAULT 0,
            image_url TEXT NOT NULL DEFAULT '', order_index INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS dashboard_missions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, island_id TEXT NOT NULL,
            stage INTEGER NOT NULL, description TEXT NOT NULL,
            character_id TEXT, alternatives_json TEXT NOT NULL DEFAULT '[]',
            reward_points INTEGER NOT NULL DEFAULT 100, reward_coins INTEGER NOT NULL DEFAULT 500,
            reward_gems INTEGER NOT NULL DEFAULT 1, active INTEGER NOT NULL DEFAULT 1,
            required_count INTEGER NOT NULL DEFAULT 1,
            UNIQUE(island_id,stage), FOREIGN KEY(island_id) REFERENCES dashboard_islands(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS dashboard_settings(
            guild_id INTEGER PRIMARY KEY, bot_status TEXT NOT NULL DEFAULT 'watching',
            status_text TEXT NOT NULL DEFAULT 'REQUIEM: NEW ERA | /profile'
        );
        CREATE TABLE IF NOT EXISTS league_submissions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            image_url TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'pending', reviewer_id INTEGER,
            review_note TEXT NOT NULL DEFAULT '', submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_at TEXT, tournament_match_id INTEGER, opponent_id INTEGER, direct_challenge_id INTEGER
        );
        CREATE TABLE IF NOT EXISTS streak_challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
            required_wins INTEGER NOT NULL DEFAULT 3, character_id TEXT, alternatives_json TEXT DEFAULT '[]',
            reward_points INTEGER DEFAULT 0, reward_coins INTEGER DEFAULT 0, reward_gems INTEGER DEFAULT 0,
            image_url TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS streak_submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, challenge_id INTEGER NOT NULL REFERENCES streak_challenges(id),
            image_url TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', submitted_at TEXT NOT NULL DEFAULT (datetime('now')),
            reviewed_by INTEGER, reviewed_at TEXT, note TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS battle_pass_tiers (
            id INTEGER PRIMARY KEY AUTOINCREMENT, tier INTEGER NOT NULL, required_points INTEGER NOT NULL,
            reward_coins INTEGER NOT NULL, reward_gems INTEGER NOT NULL, label TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS battle_pass_claims (
            user_id INTEGER NOT NULL, tier INTEGER NOT NULL, claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id, tier)
        );
        CREATE TABLE IF NOT EXISTS battle_pass_seasons (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            starts_at TEXT, ends_at TEXT, active INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS battle_pass_missions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, season_id INTEGER NOT NULL REFERENCES battle_pass_seasons(id) ON DELETE CASCADE,
            title TEXT NOT NULL, description TEXT NOT NULL, required_count INTEGER NOT NULL DEFAULT 1 CHECK(required_count > 0),
            reward_points INTEGER NOT NULL DEFAULT 0 CHECK(reward_points >= 0),
            reward_coins INTEGER NOT NULL DEFAULT 0 CHECK(reward_coins >= 0),
            reward_gems INTEGER NOT NULL DEFAULT 0 CHECK(reward_gems >= 0),
            active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS battle_pass_submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, mission_id INTEGER NOT NULL REFERENCES battle_pass_missions(id),
            image_url TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending',
            reviewer_id INTEGER, review_note TEXT NOT NULL DEFAULT '', submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_at TEXT
        );
        CREATE TABLE IF NOT EXISTS battle_pass_mission_progress (
            user_id INTEGER NOT NULL, mission_id INTEGER NOT NULL REFERENCES battle_pass_missions(id),
            approved_count INTEGER NOT NULL DEFAULT 0, claimed_at TEXT, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(user_id, mission_id)
        );
        CREATE TABLE IF NOT EXISTS tournaments (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, size INTEGER NOT NULL, creator_id INTEGER NOT NULL, status TEXT DEFAULT 'registration', created_at TEXT
        );
        CREATE TABLE IF NOT EXISTS tournament_players (
            tournament_id INTEGER NOT NULL, user_id INTEGER NOT NULL, PRIMARY KEY (tournament_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS tournament_matches (
            id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, round_number INTEGER NOT NULL,
            match_number INTEGER NOT NULL, player1_id INTEGER NOT NULL, player2_id INTEGER NOT NULL,
            winner_id INTEGER, proof_id INTEGER, status TEXT NOT NULL DEFAULT 'scheduled',
            UNIQUE(tournament_id,round_number,match_number)
        );
        CREATE TABLE IF NOT EXISTS direct_challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL,
            challenger_id INTEGER NOT NULL, opponent_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
            thread_id INTEGER, challenge_message_id INTEGER, result_message_id INTEGER, winner_id INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS shortcuts (
            trigger_text TEXT PRIMARY KEY, action_type TEXT NOT NULL, action_data TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_gl_proofs_status ON grandline_proofs(status,submitted_at);
        CREATE INDEX IF NOT EXISTS idx_hunter_submissions_status ON hunter_submissions(status,submitted_at);
        """)

        # Keep tournament tables compatible with the older schema.sql layout.
        for column, definition in (("size", "INTEGER NOT NULL DEFAULT 8"), ("creator_id", "INTEGER NOT NULL DEFAULT 0")):
            try:
                c.execute(f"SELECT {column} FROM tournaments LIMIT 1")
            except sqlite3.OperationalError:
                c.execute(f"ALTER TABLE tournaments ADD COLUMN {column} {definition}")
        try:
            c.execute("SELECT created_by FROM tournaments LIMIT 1")
            c.execute("UPDATE tournaments SET creator_id=created_by WHERE creator_id=0 AND created_by IS NOT NULL")
        except sqlite3.OperationalError:
            pass

        # Keep tournament bracket columns compatible with the older schema.sql layout.
        for column, definition in (("round_number", "INTEGER NOT NULL DEFAULT 1"), ("match_number", "INTEGER NOT NULL DEFAULT 1")):
            try:
                c.execute(f"SELECT {column} FROM tournament_matches LIMIT 1")
            except sqlite3.OperationalError:
                c.execute(f"ALTER TABLE tournament_matches ADD COLUMN {column} {definition}")

        # 2. ترقية الجداول القديمة (إضافة أعمدة إذا لم تكن موجودة)
        try:
            c.execute("SELECT progress_count FROM grandline_proofs LIMIT 1")
        except sqlite3.OperationalError:
            c.execute("ALTER TABLE grandline_proofs ADD COLUMN progress_count INTEGER DEFAULT 1")
            c.execute("ALTER TABLE grandline_proofs ADD COLUMN required_count INTEGER DEFAULT 1")

        try:
            c.execute("SELECT progress_count FROM hunter_submissions LIMIT 1")
        except sqlite3.OperationalError:
            c.execute("ALTER TABLE hunter_submissions ADD COLUMN progress_count INTEGER DEFAULT 1")
            c.execute("ALTER TABLE hunter_submissions ADD COLUMN required_count INTEGER DEFAULT 1")

        try:
            c.execute("SELECT required_count FROM dashboard_missions LIMIT 1")
        except sqlite3.OperationalError:
            c.execute("ALTER TABLE dashboard_missions ADD COLUMN required_count INTEGER DEFAULT 1")

        try:
            c.execute("SELECT streak_channel_id FROM guild_config LIMIT 1")
        except sqlite3.OperationalError:
            c.execute("ALTER TABLE guild_config ADD COLUMN streak_channel_id INTEGER")

        # 2-b. Upgrade older league proof tables without dropping existing records.
        for column, definition in (
            ("reviewer_id", "INTEGER"),
            ("review_note", "TEXT NOT NULL DEFAULT ''"),
            ("reviewed_at", "TEXT"),
            ("tournament_match_id", "INTEGER"),
            ("opponent_id", "INTEGER"),
            ("direct_challenge_id", "INTEGER"),
        ):
            try:
                c.execute(f"SELECT {column} FROM league_submissions LIMIT 1")
            except sqlite3.OperationalError:
                c.execute(f"ALTER TABLE league_submissions ADD COLUMN {column} {definition}")

        try:
            c.execute("SELECT period_key FROM hunter_submissions LIMIT 1")
        except sqlite3.OperationalError:
            c.execute("ALTER TABLE hunter_submissions ADD COLUMN period_key TEXT")

        # Keep the battle-pass table compatible with older installations.
        try:
            c.execute("SELECT label FROM battle_pass_tiers LIMIT 1")
        except sqlite3.OperationalError:
            c.execute("ALTER TABLE battle_pass_tiers ADD COLUMN label TEXT NOT NULL DEFAULT 'Reward'")

        # Indexes for proof queues and seasonal submissions.
        c.execute("CREATE INDEX IF NOT EXISTS idx_streak_submissions_status ON streak_submissions(status, submitted_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_bp_submissions_status ON battle_pass_submissions(status, submitted_at)")
        c.execute("UPDATE battle_pass_seasons SET active=0 WHERE active=1 AND id<>(SELECT MAX(id) FROM battle_pass_seasons WHERE active=1)")
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_bp_single_active_season ON battle_pass_seasons(active) WHERE active=1")

        # 3. زرع البيانات الافتراضية للباس
        bp_count = c.execute("SELECT COUNT(*) FROM battle_pass_tiers").fetchone()[0]
        if bp_count == 0:
            default_tiers = [
                (1, 300, 100, 1, "🪙 حقيبة عملات"), (2, 600, 150, 2, "💎 كيس جواهر"),
                (3, 1000, 250, 3, "🏅 لقب Supernova"), (4, 1500, 400, 5, "🔥 لقب Warlord"),
                (5, 2500, 600, 8, "👑 لقب Emperor"), (6, 4000, 900, 12, "⚓ لقب Pirate King"),
                (7, 6000, 1500, 20, "🌋 لقب Legend")
            ]
            c.executemany("INSERT INTO battle_pass_tiers (tier, required_points, reward_coins, reward_gems, label) VALUES (?, ?, ?, ?, ?)", default_tiers)

        # 4. زرع بيانات الجزر إذا كان الجدول فارغاً
        count = c.execute("SELECT COUNT(*) FROM dashboard_islands").fetchone()[0]
        if count == 0 and original:
            for idx, island in enumerate(original):
                c.execute("INSERT OR IGNORE INTO dashboard_islands(id,name,emoji,description,min_points,order_index) VALUES(?,?,?,?,?,?)",
                          (island['id'], island['name'], island.get('emoji','🏝️'), island.get('desc',''), int(island.get('min_points',0)), idx))
                for stage, mission in enumerate(island.get('missions', []), 1):
                    c.execute("INSERT OR IGNORE INTO dashboard_missions(island_id,stage,description,character_id,alternatives_json,reward_points,reward_coins,reward_gems) VALUES(?,?,?,?,?,?,?,?)",
                              (island['id'], stage, mission.get('desc',''), mission.get('character'), json.dumps(mission.get('alternatives',[]),ensure_ascii=False), 100*stage, 500*stage, 1 if stage < 3 else 2))
        
        c.execute("CREATE TABLE IF NOT EXISTS economy_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('points','coins','gems','bounty')),delta INTEGER NOT NULL CHECK(delta<>0),balance_after INTEGER NOT NULL,reason TEXT NOT NULL DEFAULT '',actor_id INTEGER,created_at TEXT NOT NULL)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_economy_transactions_user ON economy_transactions(user_id,id DESC)")
        c.execute("CREATE TABLE IF NOT EXISTS shop_orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,item_id TEXT NOT NULL,item_name TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('coins','gems')),cost INTEGER NOT NULL CHECK(cost>0),status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','fulfilled')),created_at TEXT NOT NULL,fulfilled_by INTEGER,fulfilled_at TEXT)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_shop_orders_status ON shop_orders(status,id DESC)")
        c.commit()
    refresh_live_catalog()

async def initialize():
    # The bot startup and ASGI lifespan may initialize the same SQLite file
    # concurrently. Serialize schema upgrades to avoid duplicate ALTER TABLEs.
    async with _INITIALIZE_LOCK:
        # Take a SQLite-consistent snapshot before any schema migration.
        from utils.backups import backup_database
        backup_dir = Path(DB_PATH).expanduser().resolve().parent / "backups"
        await asyncio.to_thread(backup_database, DB_PATH, backup_dir, 14)
        from utils.db import async_init_db
        await async_init_db()
        await asyncio.to_thread(initialize_sync)
        from utils.competitive import init_competitive_schema
        await asyncio.to_thread(init_competitive_schema)

def load_catalog_sync():
    with closing(connect()) as c:
        return _catalog_from_db(c)

async def load_catalog():
    return await asyncio.to_thread(load_catalog_sync)


def get_characters():
    return extract_literal("CHARACTERS", {})


def dashboard_summary_sync(guild_id: int):
    with closing(connect()) as c:
        users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        islands = c.execute("SELECT COUNT(*) FROM dashboard_islands").fetchone()[0]
        missions = c.execute("SELECT COUNT(*) FROM dashboard_missions WHERE active=1").fetchone()[0]
        gl = c.execute("SELECT COUNT(*) FROM grandline_proofs WHERE status='pending'").fetchone()[0]
        hunters = c.execute("SELECT COUNT(*) FROM hunter_submissions WHERE status='pending'").fetchone()[0]
        league = c.execute("SELECT COUNT(*) FROM league_submissions WHERE status='pending'").fetchone()[0]
        streak = c.execute("SELECT COUNT(*) FROM streak_submissions WHERE status='pending'").fetchone()[0]
        bp = c.execute("SELECT COUNT(*) FROM battle_pass_submissions WHERE status='pending'").fetchone()[0]
        competitive = c.execute("SELECT COUNT(*) FROM competitive_matches WHERE status='pending' AND proof_url<>''").fetchone()[0] if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='competitive_matches'").fetchone() else 0
        cfg = c.execute("SELECT log_channel_id FROM guild_config WHERE guild_id=?", (guild_id,)).fetchone()
        st = c.execute("SELECT bot_status,status_text FROM dashboard_settings WHERE guild_id=?", (guild_id,)).fetchone()
        return {"users":users,"islands":islands,"missions":missions,"pending":gl+hunters+league+streak+bp+competitive,
                "pending_grandline":gl,"pending_hunters":hunters,"pending_league":league,"pending_streak":streak,"pending_battle_pass":bp,"pending_competitive":competitive,
                "log_channel_id":cfg[0] if cfg else None,
                "bot_status":st[0] if st else "watching", "status_text":st[1] if st else "REQUIEM: NEW ERA | /profile"}

async def dashboard_summary(guild_id): return await asyncio.to_thread(dashboard_summary_sync,guild_id)


def list_users_sync(q: str):
    with closing(connect()) as c:
        if q.isdigit():
            rows=c.execute("SELECT user_id,username,points,coins,gems,bounty,rank,streak FROM users WHERE user_id=? OR username LIKE ? ORDER BY points DESC LIMIT 30",(int(q),f"%{q}%")).fetchall()
        else:
            rows=c.execute("SELECT user_id,username,points,coins,gems,bounty,rank,streak FROM users WHERE username LIKE ? ORDER BY points DESC LIMIT 30",(f"%{q}%",)).fetchall()
        return [dict(r) for r in rows]
async def list_users(q): return await asyncio.to_thread(list_users_sync,q)


def list_shop_orders_sync(status: str = "pending", limit: int = 100):
    if status not in {"pending", "fulfilled", "all"}:
        status = "pending"
    limit = max(1, min(int(limit), 200))
    with closing(connect()) as c:
        if status == "all":
            rows = c.execute("SELECT o.*,u.username FROM shop_orders o LEFT JOIN users u ON u.user_id=o.user_id ORDER BY o.id DESC LIMIT ?",(limit,)).fetchall()
        else:
            rows = c.execute("SELECT o.*,u.username FROM shop_orders o LEFT JOIN users u ON u.user_id=o.user_id WHERE o.status=? ORDER BY o.id DESC LIMIT ?",(status,limit)).fetchall()
        return [dict(row) for row in rows]

async def list_shop_orders(status: str = "pending", limit: int = 100):
    return await asyncio.to_thread(list_shop_orders_sync,status,limit)


def fulfill_shop_order_sync(order_id: int, actor_id: int):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            now=datetime.now(timezone.utc).isoformat()
            cur=c.execute("UPDATE shop_orders SET status='fulfilled',fulfilled_by=?,fulfilled_at=? WHERE id=? AND status='pending'",(actor_id,now,order_id))
            if cur.rowcount != 1:
                raise LookupError("Order not found or already fulfilled")
            row=c.execute("SELECT * FROM shop_orders WHERE id=?",(order_id,)).fetchone()
            c.execute("INSERT INTO audit_logs(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",(actor_id,"shop_order_fulfilled",row['user_id'],f"order_id={order_id}; item={row['item_id']}",now))
            c.commit()
            return dict(row)
        except Exception:
            c.rollback()
            raise

async def fulfill_shop_order(order_id: int, actor_id: int):
    return await asyncio.to_thread(fulfill_shop_order_sync,order_id,actor_id)


def economy_history_sync(user_id: int, limit: int = 30):
    limit = max(1, min(int(limit), 100))
    with closing(connect()) as c:
        rows = c.execute("SELECT id,user_id,currency,delta,balance_after,reason,actor_id,created_at FROM economy_transactions WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id,limit)).fetchall()
        return [dict(row) for row in rows]

async def economy_history(user_id: int, limit: int = 30):
    return await asyncio.to_thread(economy_history_sync,user_id,limit)


def adjust_economy_sync(user_id, field, amount, actor_id):
    if field not in {"points","coins","gems","bounty"}: raise ValueError("Invalid currency")
    if isinstance(amount,bool) or not isinstance(amount,int) or amount == 0 or abs(amount)>10_000_000: raise ValueError("Invalid amount")
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            row=c.execute("SELECT user_id FROM users WHERE user_id=?",(user_id,)).fetchone()
            if not row:
                if amount < 0: raise LookupError("Player wallet does not exist")
                now_seed=datetime.now(timezone.utc).isoformat()
                c.execute("INSERT INTO users(user_id,username,streak,rank,points,coins,gems,bounty,created_at,updated_at) VALUES(?,?,0,'المبتدئ',0,0,0,0,?,?)",(user_id,"",now_seed,now_seed))
            if amount < 0:
                cur=c.execute(f"UPDATE users SET {field}={field}+?, updated_at=? WHERE user_id=? AND {field}>=?",(amount,datetime.now(timezone.utc).isoformat(),user_id,-amount))
                if cur.rowcount != 1: raise ValueError("Insufficient balance")
            else:
                c.execute(f"UPDATE users SET {field}={field}+?, updated_at=? WHERE user_id=?",(amount,datetime.now(timezone.utc).isoformat(),user_id))
            if field == "points":
                from utils.db import calculate_rank
                pts=c.execute("SELECT points FROM users WHERE user_id=?",(user_id,)).fetchone()[0]
                c.execute("UPDATE users SET rank=? WHERE user_id=?",(calculate_rank(pts),user_id))
            balance = c.execute(f"SELECT {field} FROM users WHERE user_id=?", (user_id,)).fetchone()[0]
            now = datetime.now(timezone.utc).isoformat()
            c.execute("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)", (user_id,field,amount,balance,"dashboard admin adjustment",actor_id,now))
            c.execute("INSERT INTO audit_logs(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",(actor_id,"dashboard_economy_adjust",user_id,f"{field}:{amount}",now))
            c.commit()
            return dict(c.execute("SELECT user_id,username,points,coins,gems,bounty,rank,streak FROM users WHERE user_id=?",(user_id,)).fetchone())
        except Exception: c.rollback(); raise
async def adjust_economy(*args): return await asyncio.to_thread(adjust_economy_sync,*args)


def save_island_sync(data, island_id=None):
    with closing(connect()) as c:
        if island_id:
            c.execute("UPDATE dashboard_islands SET name=?,emoji=?,description=?,min_points=?,image_url=?,order_index=? WHERE id=?",
                      (data['name'],data['emoji'],data['description'],data['min_points'],data.get('image_url',''),data['order_index'],island_id))
            if c.total_changes == 0: raise LookupError("Island not found")
            result_id=island_id
        else:
            result_id=data['id']
            c.execute("INSERT INTO dashboard_islands(id,name,emoji,description,min_points,image_url,order_index) VALUES(?,?,?,?,?,?,?)",
                      (result_id,data['name'],data['emoji'],data['description'],data['min_points'],data.get('image_url',''),data['order_index']))
        c.commit()
    refresh_live_catalog(); return result_id
async def save_island(*args): return await asyncio.to_thread(save_island_sync,*args)


def delete_island_sync(island_id):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            if not c.execute("SELECT 1 FROM dashboard_islands WHERE id=?",(island_id,)).fetchone(): raise LookupError("Island not found")
            pending=c.execute("SELECT COUNT(*) FROM grandline_proofs WHERE island_id=? AND status='pending'",(island_id,)).fetchone()[0]
            if pending: raise ValueError("لا يمكن حذف الجزيرة قبل مراجعة إثباتاتها المعلقة")
            c.execute("DELETE FROM dashboard_missions WHERE island_id=?",(island_id,))
            c.execute("DELETE FROM dashboard_islands WHERE id=?",(island_id,))
            c.commit()
        except Exception: c.rollback(); raise
    refresh_live_catalog()
async def delete_island(i): return await asyncio.to_thread(delete_island_sync,i)


def save_mission_sync(island_id, data, mission_id=None):
    with closing(connect()) as c:
        if not c.execute("SELECT 1 FROM dashboard_islands WHERE id=?",(island_id,)).fetchone(): raise LookupError("Island not found")
        if mission_id:
            row=c.execute("SELECT stage FROM dashboard_missions WHERE id=? AND island_id=?",(mission_id,island_id)).fetchone()
            if not row: raise LookupError("Mission not found")
            c.execute("UPDATE dashboard_missions SET stage=?,description=?,character_id=?,alternatives_json=?,reward_points=?,reward_coins=?,reward_gems=?,active=?,required_count=? WHERE id=?",
                      (data['stage'],data['description'],data.get('character_id'),json.dumps(data.get('alternatives',[]),ensure_ascii=False),data['reward_points'],data['reward_coins'],data['reward_gems'],int(data.get('active',True)),int(data.get('required_count',1)),mission_id))
        else:
            c.execute("INSERT INTO dashboard_missions(island_id,stage,description,character_id,alternatives_json,reward_points,reward_coins,reward_gems,active,required_count) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (island_id,data['stage'],data['description'],data.get('character_id'),json.dumps(data.get('alternatives',[]),ensure_ascii=False),data['reward_points'],data['reward_coins'],data['reward_gems'],int(data.get('active',True)),int(data.get('required_count',1))))
        c.commit()
    refresh_live_catalog()
async def save_mission(*args): return await asyncio.to_thread(save_mission_sync,*args)


def delete_mission_sync(island_id, mission_id):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            target=c.execute("SELECT stage FROM dashboard_missions WHERE id=? AND island_id=?",(mission_id,island_id)).fetchone()
            if not target: raise LookupError("Mission not found")
            removed_stage=int(target["stage"])
            pending=c.execute("SELECT COUNT(*) FROM grandline_proofs WHERE island_id=? AND stage=? AND status='pending'",(island_id,removed_stage)).fetchone()[0]
            if pending:
                raise ValueError("توجد إثباتات معلقة لهذه المرحلة؛ راجعها قبل حذف المهمة")
            c.execute("UPDATE grandline_progress SET stage=MAX(0,stage-1),updated_at=? WHERE island_id=? AND stage>=?",(datetime.now(timezone.utc).isoformat(),island_id,removed_stage))
            c.execute("UPDATE grandline_proofs SET stage=stage-1 WHERE island_id=? AND stage>? AND status='pending'",(island_id,removed_stage))
            c.execute("DELETE FROM dashboard_missions WHERE id=? AND island_id=?",(mission_id,island_id))
            rows=c.execute("SELECT id FROM dashboard_missions WHERE island_id=? ORDER BY stage,id",(island_id,)).fetchall()
            for idx,row in enumerate(rows,1): c.execute("UPDATE dashboard_missions SET stage=? WHERE id=?",(idx,row['id']))
            c.commit()
        except Exception:
            c.rollback(); raise
    refresh_live_catalog()
async def delete_mission(*args): return await asyncio.to_thread(delete_mission_sync,*args)

def submit_league_proof_sync(user_id: int, image_url: str, description: str = ""):
    with closing(connect()) as c:
        cur=c.execute("INSERT INTO league_submissions(user_id,image_url,description,status,submitted_at) VALUES(?,?,?,'pending',?)",
                      (user_id,image_url,description[:500],datetime.now(timezone.utc).isoformat()))
        c.commit()
        return cur.lastrowid

async def submit_league_proof(user_id: int, image_url: str, description: str = ""):
    return await asyncio.to_thread(submit_league_proof_sync,user_id,image_url,description)


def list_proofs_sync(status="pending"):
    if status not in {"pending", "approved", "rejected", "all"}:
        raise ValueError("Invalid proof status")
    where = "" if status == "all" else "WHERE status=?"
    params = () if status == "all" else (status,)
    with closing(connect()) as c:
        gl=c.execute(f"SELECT id,'grandline' AS type,user_id,island_id AS context,stage AS detail,image_url,description,status,review_note,reviewed_at,submitted_at FROM grandline_proofs {where}", params).fetchall()
        hu=c.execute(f"SELECT id,'hunter' AS type,user_id,quest_id AS context,quest_name AS detail,image_url,description,status,review_note,reviewed_at,submitted_at FROM hunter_submissions {where}", params).fetchall()
        lg=c.execute(f"SELECT id,'league' AS type,user_id,'champions_league' AS context,'League Match' AS detail,image_url,description,status,review_note,reviewed_at,submitted_at FROM league_submissions {where}", params).fetchall()
        st=c.execute(f"SELECT ss.id,'streak' AS type,ss.user_id,CAST(ss.challenge_id AS TEXT) AS context,sc.name AS detail,ss.image_url,'' AS description,ss.status,ss.note AS review_note,ss.reviewed_at,ss.submitted_at FROM streak_submissions ss JOIN streak_challenges sc ON sc.id=ss.challenge_id {('WHERE ss.status=?' if status != 'all' else '')}", params).fetchall()
        bp=c.execute(f"SELECT bs.id,'battle_pass' AS type,bs.user_id,CAST(bs.mission_id AS TEXT) AS context,bm.title AS detail,bs.image_url,bs.description,bs.status,bs.review_note,bs.reviewed_at,bs.submitted_at FROM battle_pass_submissions bs JOIN battle_pass_missions bm ON bm.id=bs.mission_id {('WHERE bs.status=?' if status != 'all' else '')}", params).fetchall()
        cm=c.execute(f"SELECT id,'competitive' AS type,proof_submitter_id AS user_id,mode AS context,('Match #' || id) AS detail,proof_url AS image_url,review_note AS description,status,review_note,reviewed_at,created_at AS submitted_at FROM competitive_matches WHERE proof_url<>'' {('AND status=?' if status != 'all' else '')}", params).fetchall()
        rows=[dict(x) for x in [*gl,*hu,*lg,*st,*bp,*cm]]
        return sorted(rows,key=lambda x:x.get('submitted_at') or '', reverse=True)

async def list_proofs(status="pending"): return await asyncio.to_thread(list_proofs_sync,status)


def review_proof_sync(kind, proof_id, decision, reviewer_id, note=''):
    if kind not in {'grandline','hunter','league','streak','battle_pass','competitive'} or decision not in {'approved','rejected'}: raise ValueError('Invalid review')
    now=datetime.now(timezone.utc).isoformat()
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            if kind=='grandline':
                row=c.execute("SELECT * FROM grandline_proofs WHERE id=? AND status='pending'",(proof_id,)).fetchone()
                table='grandline_proofs'
            elif kind=='hunter':
                row=c.execute("SELECT * FROM hunter_submissions WHERE id=? AND status='pending'",(proof_id,)).fetchone()
                table='hunter_submissions'
            elif kind=='league':
                row=c.execute("SELECT * FROM league_submissions WHERE id=? AND status='pending'",(proof_id,)).fetchone()
                table='league_submissions'
            elif kind=='streak':
                row=c.execute("SELECT * FROM streak_submissions WHERE id=? AND status='pending'",(proof_id,)).fetchone()
                table='streak_submissions'
            elif kind == 'battle_pass':
                row=c.execute("SELECT * FROM battle_pass_submissions WHERE id=? AND status='pending'",(proof_id,)).fetchone()
                table='battle_pass_submissions'
            else:
                row=c.execute("SELECT * FROM competitive_matches WHERE id=? AND status='pending' AND proof_url<>''",(proof_id,)).fetchone()
                table='competitive_matches'
            if not row: raise LookupError('Already reviewed or not found')
            if kind == 'competitive':
                from utils.competitive import review_competitive_match_in_connection
                result=review_competitive_match_in_connection(c, proof_id, decision, reviewer_id, note)
                reward=result['reward']
            elif kind == 'streak':
                c.execute("UPDATE streak_submissions SET status=?,reviewed_by=?,note=?,reviewed_at=? WHERE id=? AND status='pending'",(decision,reviewer_id,note[:500],now,proof_id))
            else:
                c.execute(f"UPDATE {table} SET status=?,reviewer_id=?,review_note=?,reviewed_at=? WHERE id=? AND status='pending'",(decision,reviewer_id,note[:500],now,proof_id))
            if kind == 'league' and decision == 'rejected' and row['direct_challenge_id']:
                c.execute("UPDATE direct_challenges SET status='active',updated_at=? WHERE id=? AND status='result_pending'",(now,row['direct_challenge_id']))
            if kind != 'competitive':
                reward={"points":0,"coins":0,"gems":0,"tournament_points":0,"mission_progress":None}
            if decision=='approved' and kind != 'competitive':
                c.execute("INSERT OR IGNORE INTO users(user_id,username,streak,rank,points,coins,gems,created_at,updated_at) VALUES(?, '', 0, 'المبتدئ', 0, 0, 0, ?, ?)", (row['user_id'], now, now))
                if kind=='grandline':
                    mission=c.execute("SELECT reward_points,reward_coins,reward_gems,required_count FROM dashboard_missions WHERE island_id=? AND stage=?",(row['island_id'],row['stage'])).fetchone()
                    required=int(mission['required_count']) if mission else 1
                    approved_count=c.execute("SELECT COALESCE(SUM(COALESCE(progress_count,1)),0) FROM grandline_proofs WHERE user_id=? AND island_id=? AND stage=? AND status='approved'",(row['user_id'],row['island_id'],row['stage'])).fetchone()[0]
                    existing=c.execute("SELECT stage FROM grandline_progress WHERE user_id=? AND island_id=?",(row['user_id'],row['island_id'])).fetchone()
                    already_completed=bool(existing and int(existing['stage'] or 0)>=int(row['stage']))
                    completed=approved_count>=required and not already_completed
                    reward={"points":(mission['reward_points'] if mission else 100*int(row['stage'])) if completed else 0,
                            "coins":(mission['reward_coins'] if mission else 500*int(row['stage'])) if completed else 0,
                            "gems":(mission['reward_gems'] if mission else (1 if int(row['stage'])<3 else 2)) if completed else 0,
                            "tournament_points":0,
                            "mission_progress":{"current":approved_count,"required":required,"completed":completed}}
                    if completed:
                        c.execute("INSERT INTO grandline_progress(user_id,island_id,stage,cleared_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id,island_id) DO UPDATE SET stage=MAX(stage,excluded.stage),cleared_at=excluded.cleared_at,updated_at=excluded.updated_at",
                                  (row['user_id'],row['island_id'],row['stage'],now,now))
                elif kind=='hunter':
                    required=int(row['required_count'] or 1)
                    approved_count=c.execute("SELECT COALESCE(SUM(COALESCE(progress_count,1)),0) FROM hunter_submissions WHERE user_id=? AND quest_id=? AND quest_name=? AND COALESCE(period_key,'')=COALESCE(?,'') AND status='approved'",(row['user_id'],row['quest_id'],row['quest_name'],row['period_key'])).fetchone()[0]
                    completed=approved_count>=required
                    reward={"points":150 if completed else 0,"coins":500 if completed else 0,"gems":1 if completed else 0,"tournament_points":0,"mission_progress":{"current":approved_count,"required":required,"completed":completed}}
                    if completed and row['quest_id'] == 'daily' and row['period_key'] == now[:10]:
                        c.execute("UPDATE users SET daily_index=CASE WHEN last_daily_reset=? THEN MIN(daily_index+1,3) ELSE 1 END, last_daily_reset=? WHERE user_id=?", (now[:10],now[:10],row['user_id']))
                    elif completed and row['quest_id'] == 'weekly':
                        week_key=datetime.now(timezone.utc).strftime("%G-W%V")
                        if row['period_key'] == week_key:
                            c.execute("UPDATE users SET weekly_index=CASE WHEN last_weekly_reset=? THEN MIN(weekly_index+1,3) ELSE 1 END, last_weekly_reset=? WHERE user_id=?", (week_key,week_key,row['user_id']))
                elif kind=='streak':
                    challenge=c.execute("SELECT reward_points,reward_coins,reward_gems FROM streak_challenges WHERE id=? AND active=1",(row['challenge_id'],)).fetchone()
                    if not challenge: raise LookupError('Streak challenge is no longer active')
                    already=c.execute("SELECT 1 FROM streak_submissions WHERE user_id=? AND challenge_id=? AND status='approved' AND id<>? LIMIT 1",(row['user_id'],row['challenge_id'],proof_id)).fetchone()
                    if already: raise LookupError('This player has already received this streak challenge reward')
                    reward={"points":challenge['reward_points'] or 0,"coins":challenge['reward_coins'] or 0,"gems":challenge['reward_gems'] or 0,"tournament_points":0,"mission_progress":None}
                elif kind=='battle_pass':
                    mission=c.execute("SELECT bm.*,bs.active AS season_active,bs.starts_at,bs.ends_at FROM battle_pass_missions bm JOIN battle_pass_seasons bs ON bs.id=bm.season_id WHERE bm.id=? AND bm.active=1",(row['mission_id'],)).fetchone()
                    if not mission or not mission['season_active']:
                        raise LookupError('Battle Pass season or mission is inactive')
                    progress=c.execute("SELECT approved_count,claimed_at FROM battle_pass_mission_progress WHERE user_id=? AND mission_id=?",(row['user_id'],row['mission_id'])).fetchone()
                    approved_count=(progress['approved_count'] if progress else 0)+1
                    if progress and progress['claimed_at']:
                        raise LookupError('Mission reward has already been claimed')
                    c.execute("INSERT INTO battle_pass_mission_progress(user_id,mission_id,approved_count,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id,mission_id) DO UPDATE SET approved_count=excluded.approved_count,updated_at=excluded.updated_at",(row['user_id'],row['mission_id'],approved_count,now))
                    completed=approved_count >= mission['required_count']
                    reward={"points":mission['reward_points'] if completed else 0,"coins":mission['reward_coins'] if completed else 0,"gems":mission['reward_gems'] if completed else 0,"tournament_points":0,"mission_progress":{"current":approved_count,"required":mission['required_count'],"completed":completed}}
                    if completed:
                        c.execute("UPDATE battle_pass_mission_progress SET claimed_at=? WHERE user_id=? AND mission_id=? AND claimed_at IS NULL",(now,row['user_id'],row['mission_id']))
                else:
                    reward={"points":0,"coins":200,"gems":0,"tournament_points":100,"mission_progress":None}
                    if row['direct_challenge_id']:
                        challenge=c.execute("SELECT * FROM direct_challenges WHERE id=? AND status='result_pending'",(row['direct_challenge_id'],)).fetchone()
                        if not challenge or row['user_id'] not in (challenge['challenger_id'],challenge['opponent_id']):
                            raise LookupError('Direct challenge is no longer active')
                        c.execute("UPDATE direct_challenges SET status='completed',winner_id=?,updated_at=? WHERE id=?",(row['user_id'],now,row['direct_challenge_id']))
                        from utils.competitive import record_approved_match_in_connection, evaluate_player_risk
                        record_approved_match_in_connection(c, "general", int(challenge['challenger_id']), int(challenge['opponent_id']), int(row['user_id']), f"direct_challenge:{row['direct_challenge_id']}", row['image_url'], reviewer_id, note)
                        c.execute("INSERT INTO tournament_points(user_id,tournament_id,points,reason,created_at) VALUES(?,?,?,?,?)",(row['user_id'],"season_1_requiem",100,"Approved direct challenge win",now))
                    elif row['tournament_match_id']:
                        match=c.execute("SELECT * FROM tournament_matches WHERE id=? AND status='scheduled'",(row['tournament_match_id'],)).fetchone()
                        if not match or row['user_id'] not in (match['player1_id'],match['player2_id']):
                            raise LookupError('Tournament match is no longer active or player is not in this match')
                        c.execute("UPDATE tournament_matches SET winner_id=?,proof_id=?,status='completed' WHERE id=? AND status='scheduled'",(row['user_id'],proof_id,row['tournament_match_id']))
                        from utils.competitive import record_approved_match_in_connection
                        record_approved_match_in_connection(c, "tournament", int(match['player1_id']), int(match['player2_id']), int(row['user_id']), f"tournament_match:{row['tournament_match_id']}", row['image_url'], reviewer_id, note)
                        tournament_id=match['tournament_id']
                        c.execute("INSERT INTO tournament_points(user_id,tournament_id,points,reason,created_at) VALUES(?,?,?,?,?)",
                                  (row['user_id'],"season_1_requiem",100,"Tournament match win",now))
                        round_number=match['round_number']
                        pending=c.execute("SELECT COUNT(*) FROM tournament_matches WHERE tournament_id=? AND round_number=? AND status!='completed'",(tournament_id,round_number)).fetchone()[0]
                        total=c.execute("SELECT COUNT(*) FROM tournament_matches WHERE tournament_id=? AND round_number=?",(tournament_id,round_number)).fetchone()[0]
                        if pending==0 and total==1:
                            c.execute("UPDATE tournaments SET status='completed' WHERE id=?",(tournament_id,))
                        elif pending==0:
                            winners=[int(r['winner_id']) for r in c.execute("SELECT winner_id FROM tournament_matches WHERE tournament_id=? AND round_number=? ORDER BY match_number",(tournament_id,round_number)).fetchall()]
                            next_round=round_number+1
                            for index in range(0,len(winners),2):
                                c.execute("INSERT INTO tournament_matches(tournament_id,round_number,match_number,player1_id,player2_id,status) VALUES(?,?,?,?,?,'scheduled')",(tournament_id,next_round,index//2+1,winners[index],winners[index+1]))
                    else:
                        c.execute("INSERT INTO tournament_points(user_id,tournament_id,points,reason,created_at) VALUES(?,?,?,?,?)",
                                  (row['user_id'],"season_1_requiem",100,"Approved league match proof",now))
                c.execute("UPDATE users SET points=points+?,coins=coins+?,gems=gems+?,updated_at=? WHERE user_id=?",
                          (reward['points'],reward['coins'],reward['gems'],now,row['user_id']))
                balances=c.execute("SELECT coins,gems FROM users WHERE user_id=?",(row['user_id'],)).fetchone()
                ledger_rows=[]
                points_balance=c.execute("SELECT points FROM users WHERE user_id=?",(row['user_id'],)).fetchone()[0]
                if reward['points']:
                    ledger_rows.append((row['user_id'],'points',reward['points'],points_balance,f'{kind} proof reward',reviewer_id,now))
                if reward['coins']:
                    ledger_rows.append((row['user_id'],'coins',reward['coins'],balances['coins'],f'{kind} proof reward',reviewer_id,now))
                if reward['gems']:
                    ledger_rows.append((row['user_id'],'gems',reward['gems'],balances['gems'],f'{kind} proof reward',reviewer_id,now))
                if ledger_rows:
                    c.executemany("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)",ledger_rows)
                if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='achievement_catalog'").fetchone():
                    from utils.competitive import _record_achievement_progress_in_connection
                    _record_achievement_progress_in_connection(c, int(row['user_id']), "proof_approved", 1)
                    if kind == 'grandline' and reward.get('mission_progress', {}).get('completed'):
                        _record_achievement_progress_in_connection(c, int(row['user_id']), "grandline_clear", 1)
                    if kind == 'battle_pass' and reward.get('mission_progress', {}).get('completed'):
                        _record_achievement_progress_in_connection(c, int(row['user_id']), "battlepass_mission", 1)
                pts=c.execute("SELECT points FROM users WHERE user_id=?",(row['user_id'],)).fetchone()
                if pts:
                    from utils.db import calculate_rank
                    c.execute("UPDATE users SET rank=? WHERE user_id=?",(calculate_rank(pts[0]),row['user_id']))
            target_user = row['proof_submitter_id'] if kind == 'competitive' else row['user_id']
            c.execute("INSERT INTO audit_logs(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",
                      (reviewer_id,f"dashboard_{kind}_{decision}",target_user,f"proof_id={proof_id}; note={note[:300]}",now))
            c.commit()
            return {"success":True,"user_id":target_user,"reward":reward,"status":decision}
        except Exception: c.rollback(); raise
async def review_proof(*args): return await asyncio.to_thread(review_proof_sync,*args)


def get_mission_progress_sync(user_id, island_id, stage):
    with closing(connect()) as c:
        mission = c.execute("SELECT required_count FROM dashboard_missions WHERE island_id=? AND stage=?", (island_id, stage)).fetchone()
        required = mission['required_count'] if mission else 1
        approved = c.execute("SELECT COUNT(*) FROM grandline_proofs WHERE user_id=? AND island_id=? AND stage=? AND status='approved'", (user_id, island_id, stage)).fetchone()[0]
        pending = c.execute("SELECT COUNT(*) FROM grandline_proofs WHERE user_id=? AND island_id=? AND stage=? AND status='pending'", (user_id, island_id, stage)).fetchone()[0] > 0
        return {"required": required, "approved": approved, "pending": pending}

async def get_mission_progress(user_id, island_id, stage):
    return await asyncio.to_thread(get_mission_progress_sync, user_id, island_id, stage)


def progress_grandline_proof_sync(proof_id, reviewer_id):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            row = c.execute("SELECT * FROM grandline_proofs WHERE id=? AND status='pending'", (proof_id,)).fetchone()
            if not row: raise LookupError("Proof not found or already reviewed")
            
            c.execute("UPDATE grandline_proofs SET status='approved', reviewer_id=?, reviewed_at=? WHERE id=?", 
                      (reviewer_id, datetime.now(timezone.utc).isoformat(), proof_id))
            
            mission = c.execute("SELECT required_count FROM dashboard_missions WHERE island_id=? AND stage=?", (row['island_id'], row['stage'])).fetchone()
            required = mission['required_count'] if mission else 1
            
            approved_count = c.execute("SELECT COALESCE(SUM(COALESCE(progress_count,1)),0) FROM grandline_proofs WHERE user_id=? AND island_id=? AND stage=? AND status='approved'", (row['user_id'], row['island_id'], row['stage'])).fetchone()[0]
            
            c.commit()
            return {"user_id": row['user_id'], "current": approved_count, "required": required}
        except Exception:
            c.rollback()
            raise

async def progress_grandline_proof(proof_id, reviewer_id):
    return await asyncio.to_thread(progress_grandline_proof_sync, proof_id, reviewer_id)


def get_streak_challenges_sync():
    with closing(connect()) as c:
        return [dict(r) for r in c.execute("SELECT * FROM streak_challenges WHERE active=1").fetchall()]
async def get_streak_challenges():
    return await asyncio.to_thread(get_streak_challenges_sync)

def submit_streak_proof_sync(user_id: int, challenge_id: int, image_url: str):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        challenge = c.execute("SELECT id FROM streak_challenges WHERE id=? AND active=1", (challenge_id,)).fetchone()
        if not challenge: raise LookupError("Streak challenge not found or inactive")
        existing = c.execute("SELECT id FROM streak_submissions WHERE user_id=? AND challenge_id=? AND status IN ('pending','approved') LIMIT 1", (user_id, challenge_id)).fetchone()
        if existing: raise LookupError("You already submitted this challenge or completed it")
        cur = c.execute("INSERT INTO streak_submissions(user_id, challenge_id, image_url, status) VALUES(?,?,?,'pending')", (user_id, challenge_id, image_url))
        c.commit()
        return cur.lastrowid
async def submit_streak_proof(user_id: int, challenge_id: int, image_url: str):
    return await asyncio.to_thread(submit_streak_proof_sync, user_id, challenge_id, image_url)

def edit_mission_description_sync(island_id: str, stage: int, description: str):
    with closing(connect()) as c:
        cur = c.execute("UPDATE dashboard_missions SET description=? WHERE island_id=? AND stage=?", (description, island_id, stage))
        if cur.rowcount != 1: raise LookupError("Mission not found")
        c.commit()
    refresh_live_catalog()

async def edit_mission_description(island_id: str, stage: int, description: str):
    return await asyncio.to_thread(edit_mission_description_sync, island_id, stage, description)

def progress_hunter_quest_sync(proof_id, reviewer_id):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            row = c.execute("SELECT * FROM hunter_submissions WHERE id=? AND status='pending'", (proof_id,)).fetchone()
            if not row: raise LookupError("Proof not found or already reviewed")
            
            c.execute("UPDATE hunter_submissions SET status='approved', reviewer_id=?, reviewed_at=? WHERE id=?", 
                      (reviewer_id, datetime.now(timezone.utc).isoformat(), proof_id))
            
            quest_id = row['quest_id']
            if quest_id == "daily":
                c.execute("UPDATE users SET daily_index = daily_index + 1 WHERE user_id=?", (row['user_id'],))
            elif quest_id == "weekly":
                c.execute("UPDATE users SET weekly_index = weekly_index + 1 WHERE user_id=?", (row['user_id'],))
            
            c.commit()
            return {"user_id": row['user_id'], "current": 1, "required": 1}
        except Exception:
            c.rollback()
            raise

async def progress_hunter_quest(proof_id, reviewer_id):
    return await asyncio.to_thread(progress_hunter_quest_sync, proof_id, reviewer_id)

# ================== Battle Pass ==================
def init_bp_tables_sync():
    with closing(connect()) as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS battle_pass_tiers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tier INTEGER NOT NULL,
            required_points INTEGER NOT NULL,
            reward_coins INTEGER NOT NULL,
            reward_gems INTEGER NOT NULL,
            label TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS battle_pass_claims (
            user_id INTEGER NOT NULL,
            tier INTEGER NOT NULL,
            claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, tier)
        );
        """)
        # إضافة مستويات افتراضية إذا كان الجدول فارغاً
        count = c.execute("SELECT COUNT(*) FROM battle_pass_tiers").fetchone()[0]
        if count == 0:
            default_tiers = [
                (1, 300, 100, 1, "🪙 حقيبة عملات"),
                (2, 600, 150, 2, "💎 كيس جواهر"),
                (3, 1000, 250, 3, "🏅 لقب Supernova"),
                (4, 1500, 400, 5, "🔥 لقب Warlord"),
                (5, 2500, 600, 8, "👑 لقب Emperor"),
                (6, 4000, 900, 12, "⚓ لقب Pirate King"),
                (7, 6000, 1500, 20, "🌋 لقب Legend")
            ]
            c.executemany("INSERT INTO battle_pass_tiers (tier, required_points, reward_coins, reward_gems, label) VALUES (?, ?, ?, ?, ?)", default_tiers)
        c.commit()

async def init_bp_tables():
    await asyncio.to_thread(init_bp_tables_sync)

def get_bp_tiers_sync():
    with closing(connect()) as c:
        return [dict(r) for r in c.execute("SELECT * FROM battle_pass_tiers ORDER BY tier").fetchall()]

async def get_bp_tiers():
    return await asyncio.to_thread(get_bp_tiers_sync)

def has_claimed_bp_tier_sync(user_id, tier):
    with closing(connect()) as c:
        return c.execute("SELECT 1 FROM battle_pass_claims WHERE user_id=? AND tier=?", (user_id, tier)).fetchone() is not None

async def has_claimed_bp_tier(user_id, tier):
    return await asyncio.to_thread(has_claimed_bp_tier_sync, user_id, tier)

def claim_bp_tier_sync(user_id, tier, required_points, reward_coins, reward_gems):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            # التحقق من النقاط
            row = c.execute("SELECT points FROM users WHERE user_id=?", (user_id,)).fetchone()
            if not row or row['points'] < required_points:
                return {"success": False, "reason": "insufficient_points"}
            
            # التحقق من عدم الاستلام المسبق
            if c.execute("SELECT 1 FROM battle_pass_claims WHERE user_id=? AND tier=?", (user_id, tier)).fetchone():
                return {"success": False, "reason": "already_claimed"}
            
            # خصم/إضافة المكافآت
            c.execute("UPDATE users SET coins = coins + ?, gems = gems + ?, updated_at=? WHERE user_id=?", (reward_coins, reward_gems, datetime.now(timezone.utc).isoformat(), user_id))
            c.execute("INSERT INTO battle_pass_claims (user_id, tier) VALUES (?, ?)", (user_id, tier))
            now=datetime.now(timezone.utc).isoformat()
            balances=c.execute("SELECT coins,gems FROM users WHERE user_id=?",(user_id,)).fetchone()
            ledger_rows=[]
            if reward_coins:
                ledger_rows.append((user_id,'coins',reward_coins,balances['coins'],'battle pass tier reward',None,now))
            if reward_gems:
                ledger_rows.append((user_id,'gems',reward_gems,balances['gems'],'battle pass tier reward',None,now))
            if ledger_rows:
                c.executemany("INSERT INTO economy_transactions(user_id,currency,delta,balance_after,reason,actor_id,created_at) VALUES(?,?,?,?,?,?,?)",ledger_rows)
            c.commit()
            return {"success": True, "coins": reward_coins, "gems": reward_gems}
        except Exception:
            c.rollback()
            raise

async def claim_bp_tier(user_id, tier, required_points, reward_coins, reward_gems):
    return await asyncio.to_thread(claim_bp_tier_sync, user_id, tier, required_points, reward_coins, reward_gems)

def save_bp_tier_sync(data, tier_id=None):
    tier_number = int(data["tier"])
    if tier_number < 1 or int(data["required_points"]) < 0 or int(data["reward_coins"]) < 0 or int(data["reward_gems"]) < 0:
        raise ValueError("بيانات المستوى والمكافآت يجب أن تكون أرقاماً غير سالبة")
    label = str(data.get("label") or "").strip()
    if not label:
        raise ValueError("اسم المكافأة مطلوب")
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            duplicate = c.execute(
                "SELECT id FROM battle_pass_tiers WHERE tier=? AND (? IS NULL OR id<>?) LIMIT 1",
                (tier_number, tier_id, tier_id),
            ).fetchone()
            if duplicate:
                raise ValueError("رقم المستوى مستخدم بالفعل")
            if tier_id is not None:
                cur = c.execute(
                    "UPDATE battle_pass_tiers SET tier=?, required_points=?, reward_coins=?, reward_gems=?, label=? WHERE id=?",
                    (tier_number, int(data["required_points"]), int(data["reward_coins"]), int(data["reward_gems"]), label, tier_id),
                )
                if cur.rowcount == 0:
                    raise LookupError("Tier not found")
            else:
                c.execute(
                    "INSERT INTO battle_pass_tiers (tier, required_points, reward_coins, reward_gems, label) VALUES (?, ?, ?, ?, ?)",
                    (tier_number, int(data["required_points"]), int(data["reward_coins"]), int(data["reward_gems"]), label),
                )
            c.commit()
            return True
        except Exception:
            c.rollback()
            raise

async def save_bp_tier(*args):
    return await asyncio.to_thread(save_bp_tier_sync, *args)

def delete_bp_tier_sync(tier_id):
    with closing(connect()) as c:
        cur = c.execute("DELETE FROM battle_pass_tiers WHERE id=?", (tier_id,))
        c.commit()
        return cur.rowcount > 0

async def delete_bp_tier(tier_id):
    return await asyncio.to_thread(delete_bp_tier_sync, tier_id)

# ================== Direct player challenges ==================
def create_direct_challenge_sync(guild_id, channel_id, challenger_id, opponent_id):
    if challenger_id == opponent_id: raise ValueError('You cannot challenge yourself')
    if any(isinstance(value,bool) or int(value)<=0 for value in (guild_id,channel_id,challenger_id,opponent_id)):
        raise ValueError('Invalid challenge participant or channel')
    with closing(connect()) as c:
        existing=c.execute("SELECT id FROM direct_challenges WHERE guild_id=? AND ((challenger_id=? AND opponent_id=?) OR (challenger_id=? AND opponent_id=?)) AND status IN ('pending','active','result_pending') LIMIT 1",(guild_id,challenger_id,opponent_id,opponent_id,challenger_id)).fetchone()
        if existing: raise ValueError('يوجد تحدٍ مفتوح بينكما بالفعل')
        cur=c.execute("INSERT INTO direct_challenges(guild_id,channel_id,challenger_id,opponent_id,status,created_at,updated_at) VALUES(?,?,?,?,'pending',?,?)",(guild_id,channel_id,challenger_id,opponent_id,datetime.now(timezone.utc).isoformat(),datetime.now(timezone.utc).isoformat()))
        return cur.lastrowid
async def create_direct_challenge(*args): return await asyncio.to_thread(create_direct_challenge_sync,*args)

def update_direct_challenge_sync(challenge_id, status, **fields):
    allowed={'thread_id','challenge_message_id','result_message_id','winner_id'}
    updates={k:v for k,v in fields.items() if k in allowed}
    if status not in {'pending','active','result_pending','completed','rejected','cancelled'}: raise ValueError('Invalid challenge status')
    with closing(connect()) as c:
        assignments=['status=?','updated_at=?']+[f'{key}=?' for key in updates]
        values=[status,datetime.now(timezone.utc).isoformat(),*updates.values(),challenge_id]
        expected_status = "pending" if status in {"pending", "active", "rejected"} else None
        where = "id=? AND status=?" if expected_status else "id=?"
        if expected_status:
            values.append(expected_status)
        cur=c.execute(f"UPDATE direct_challenges SET {', '.join(assignments)} WHERE {where}",values)
        if cur.rowcount!=1: raise LookupError('Challenge is no longer pending or was not found')
        return True
async def update_direct_challenge(*args,**kwargs): return await asyncio.to_thread(update_direct_challenge_sync,*args,**kwargs)

def get_recoverable_challenges_sync():
    with closing(connect()) as c:
        return [dict(r) for r in c.execute("SELECT * FROM direct_challenges WHERE (status='pending' AND challenge_message_id IS NOT NULL) OR (status IN ('active','result_pending') AND result_message_id IS NOT NULL)").fetchall()]
async def get_recoverable_challenges(): return await asyncio.to_thread(get_recoverable_challenges_sync)

def submit_direct_challenge_proof_sync(challenge_id,user_id,image_url,description=''):
    with closing(connect()) as c:
        c.execute('BEGIN IMMEDIATE')
        challenge=c.execute("SELECT * FROM direct_challenges WHERE id=? AND status='active'",(challenge_id,)).fetchone()
        if not challenge or user_id not in (challenge['challenger_id'],challenge['opponent_id']): raise LookupError('Challenge is not active or you are not a participant')
        existing=c.execute("SELECT 1 FROM league_submissions WHERE direct_challenge_id=? AND status='pending' LIMIT 1",(challenge_id,)).fetchone()
        if existing: raise LookupError('A result proof is already waiting for review')
        opponent=challenge['opponent_id'] if user_id==challenge['challenger_id'] else challenge['challenger_id']
        cur=c.execute("INSERT INTO league_submissions(user_id,image_url,description,status,submitted_at,opponent_id,direct_challenge_id) VALUES(?,?,?,'pending',?,?,?)",(user_id,image_url,description[:500],datetime.now(timezone.utc).isoformat(),opponent,challenge_id))
        c.execute("UPDATE direct_challenges SET status='result_pending',updated_at=? WHERE id=?",(datetime.now(timezone.utc).isoformat(),challenge_id))
        c.commit(); return cur.lastrowid
async def submit_direct_challenge_proof(*args): return await asyncio.to_thread(submit_direct_challenge_proof_sync,*args)

# ================== Tournament bracket engine ==================
def start_tournament_sync(tournament_id: int):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        tournament=c.execute("SELECT * FROM tournaments WHERE id=?",(tournament_id,)).fetchone()
        if not tournament or tournament['status']!='registration': raise LookupError('Tournament is not open for registration')
        size=int(tournament['size'])
        if size not in {4,8,16,32}: raise ValueError('Tournament size must be 4, 8, 16, or 32')
        players=[int(r['user_id']) for r in c.execute("SELECT user_id FROM tournament_players WHERE tournament_id=? ORDER BY rowid",(tournament_id,)).fetchall()]
        if len(players)!=size: raise ValueError(f'Tournament needs exactly {size} players; currently {len(players)}')
        c.execute("UPDATE tournaments SET status='active' WHERE id=?",(tournament_id,))
        for index in range(0,size,2):
            c.execute("INSERT INTO tournament_matches(tournament_id,round_number,match_number,player1_id,player2_id,status) VALUES(?,1,?,?,?,'scheduled')",(tournament_id,index//2+1,players[index],players[index+1]))
        matches=[dict(r) for r in c.execute("SELECT * FROM tournament_matches WHERE tournament_id=? AND round_number=1 ORDER BY match_number",(tournament_id,)).fetchall()]
        c.commit(); return matches
async def start_tournament(tournament_id: int): return await asyncio.to_thread(start_tournament_sync,tournament_id)

def get_user_tournament_match_sync(user_id: int):
    with closing(connect()) as c:
        row=c.execute("SELECT tm.*,t.name AS tournament_name FROM tournament_matches tm JOIN tournaments t ON t.id=tm.tournament_id WHERE t.status='active' AND tm.status='scheduled' AND (tm.player1_id=? OR tm.player2_id=?) ORDER BY tm.id LIMIT 1",(user_id,user_id)).fetchone()
        return dict(row) if row else None
async def get_user_tournament_match(user_id: int): return await asyncio.to_thread(get_user_tournament_match_sync,user_id)

def submit_tournament_match_proof_sync(user_id: int, image_url: str, description: str = ""):
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        match=c.execute("SELECT * FROM tournament_matches WHERE status='scheduled' AND (player1_id=? OR player2_id=?) ORDER BY id LIMIT 1",(user_id,user_id)).fetchone()
        if not match: raise LookupError('You do not have an active tournament match')
        pending=c.execute("SELECT 1 FROM league_submissions WHERE tournament_match_id=? AND status='pending' LIMIT 1",(match['id'],)).fetchone()
        if pending: raise LookupError('A result proof for this match is already waiting for review')
        opponent=match['player2_id'] if match['player1_id']==user_id else match['player1_id']
        cur=c.execute("INSERT INTO league_submissions(user_id,image_url,description,status,submitted_at,tournament_match_id,opponent_id) VALUES(?,?,?,'pending',?,?,?)",(user_id,image_url,description[:500],datetime.now(timezone.utc).isoformat(),match['id'],opponent))
        c.commit(); return {"proof_id":cur.lastrowid,"match":dict(match),"opponent_id":opponent}
async def submit_tournament_match_proof(*args): return await asyncio.to_thread(submit_tournament_match_proof_sync,*args)

# ================== Seasonal Battle Pass missions ==================
def list_bp_seasons_sync():
    with closing(connect()) as c:
        return [dict(r) for r in c.execute("SELECT * FROM battle_pass_seasons ORDER BY id DESC").fetchall()]
async def list_bp_seasons(): return await asyncio.to_thread(list_bp_seasons_sync)

def save_bp_season_sync(data, season_id=None):
    name=str(data.get('name','')).strip(); description=str(data.get('description','')).strip()
    if not name or len(name)>100: raise ValueError('Season name must be 1-100 characters')
    starts_at=data.get('starts_at'); ends_at=data.get('ends_at')
    try:
        starts_value=datetime.fromisoformat(starts_at) if starts_at else None
        ends_value=datetime.fromisoformat(ends_at) if ends_at else None
    except (TypeError,ValueError) as exc:
        raise ValueError('Invalid season date format') from exc
    if starts_value and ends_value and starts_value >= ends_value:
        raise ValueError('Season start must be earlier than its end')
    active=1 if data.get('active') else 0
    with closing(connect()) as c:
        c.execute('BEGIN IMMEDIATE')
        if active: c.execute('UPDATE battle_pass_seasons SET active=0')
        if season_id:
            cur=c.execute('UPDATE battle_pass_seasons SET name=?,description=?,starts_at=?,ends_at=?,active=? WHERE id=?',(name,description,starts_at,ends_at,active,season_id))
            if cur.rowcount != 1: raise LookupError('Season not found')
            result=season_id
        else:
            cur=c.execute('INSERT INTO battle_pass_seasons(name,description,starts_at,ends_at,active) VALUES(?,?,?,?,?)',(name,description,starts_at,ends_at,active)); result=cur.lastrowid
        c.commit(); return result
async def save_bp_season(*args): return await asyncio.to_thread(save_bp_season_sync,*args)

def list_bp_missions_sync(season_id=None, active_only=False):
    query='SELECT m.*,s.name AS season_name,s.active AS season_active FROM battle_pass_missions m JOIN battle_pass_seasons s ON s.id=m.season_id'
    clauses=[]; params=[]
    if season_id is not None: clauses.append('m.season_id=?'); params.append(season_id)
    if active_only: clauses.extend(['m.active=1','s.active=1'])
    if clauses: query+=' WHERE '+' AND '.join(clauses)
    query+=' ORDER BY m.id'
    with closing(connect()) as c: return [dict(r) for r in c.execute(query,params).fetchall()]
async def list_bp_missions(season_id=None, active_only=False): return await asyncio.to_thread(list_bp_missions_sync,season_id,active_only)

def get_user_bp_missions_sync(user_id):
    with closing(connect()) as c:
        rows=c.execute("SELECT m.*,s.name AS season_name,s.active AS season_active,COALESCE(p.approved_count,0) AS user_progress,p.claimed_at FROM battle_pass_missions m JOIN battle_pass_seasons s ON s.id=m.season_id LEFT JOIN battle_pass_mission_progress p ON p.mission_id=m.id AND p.user_id=? WHERE m.active=1 AND s.active=1 ORDER BY m.id",(user_id,)).fetchall()
        return [dict(r) for r in rows]
async def get_user_bp_missions(user_id): return await asyncio.to_thread(get_user_bp_missions_sync,user_id)

def save_bp_mission_sync(data, mission_id=None):
    title=str(data.get('title','')).strip(); description=str(data.get('description','')).strip()
    if not title or not description: raise ValueError('Mission title and description are required')
    required=int(data.get('required_count',1)); points=int(data.get('reward_points',0)); coins=int(data.get('reward_coins',0)); gems=int(data.get('reward_gems',0)); season_id=int(data.get('season_id',0))
    if required<1 or required>100 or min(points,coins,gems)<0: raise ValueError('Invalid mission requirements or rewards')
    with closing(connect()) as c:
        if not c.execute('SELECT 1 FROM battle_pass_seasons WHERE id=?',(season_id,)).fetchone(): raise LookupError('Season not found')
        active=1 if data.get('active',True) else 0
        if mission_id:
            current=c.execute('SELECT * FROM battle_pass_missions WHERE id=?',(mission_id,)).fetchone()
            if not current: raise LookupError('Mission not found')
            has_history=c.execute('SELECT 1 FROM battle_pass_submissions WHERE mission_id=? LIMIT 1',(mission_id,)).fetchone() or c.execute('SELECT 1 FROM battle_pass_mission_progress WHERE mission_id=? LIMIT 1',(mission_id,)).fetchone()
            protected_fields=('season_id','required_count','reward_points','reward_coins','reward_gems')
            proposed={'season_id':season_id,'required_count':required,'reward_points':points,'reward_coins':coins,'reward_gems':gems}
            if has_history and any(int(current[field])!=int(proposed[field]) for field in protected_fields):
                raise ValueError('لا يمكن تغيير متطلبات المهمة أو مكافآتها بعد بدء استقبال الإثباتات')
            cur=c.execute('UPDATE battle_pass_missions SET season_id=?,title=?,description=?,required_count=?,reward_points=?,reward_coins=?,reward_gems=?,active=? WHERE id=?',(season_id,title,description,required,points,coins,gems,active,mission_id))
            result=mission_id
        else:
            cur=c.execute('INSERT INTO battle_pass_missions(season_id,title,description,required_count,reward_points,reward_coins,reward_gems,active) VALUES(?,?,?,?,?,?,?,?)',(season_id,title,description,required,points,coins,gems,active)); result=cur.lastrowid
        return result
async def save_bp_mission(*args): return await asyncio.to_thread(save_bp_mission_sync,*args)

def delete_bp_mission_sync(mission_id):
    with closing(connect()) as c:
        pending=c.execute("SELECT 1 FROM battle_pass_submissions WHERE mission_id=? AND status='pending' LIMIT 1",(mission_id,)).fetchone()
        if pending: raise ValueError('لا يمكن إيقاف المهمة ولديها إثباتات قيد المراجعة')
        cur=c.execute("UPDATE battle_pass_missions SET active=0 WHERE id=?",(mission_id,))
        return cur.rowcount==1
async def delete_bp_mission(mission_id): return await asyncio.to_thread(delete_bp_mission_sync,mission_id)

def submit_bp_mission_proof_sync(user_id, mission_id, image_url, description=''):
    with closing(connect()) as c:
        c.execute('BEGIN IMMEDIATE')
        mission=c.execute("SELECT m.id FROM battle_pass_missions m JOIN battle_pass_seasons s ON s.id=m.season_id WHERE m.id=? AND m.active=1 AND s.active=1",(mission_id,)).fetchone()
        if not mission: raise LookupError('Active Battle Pass mission not found')
        progress=c.execute('SELECT claimed_at FROM battle_pass_mission_progress WHERE user_id=? AND mission_id=?',(user_id,mission_id)).fetchone()
        if progress and progress['claimed_at']: raise LookupError('Mission already completed')
        pending=c.execute("SELECT 1 FROM battle_pass_submissions WHERE user_id=? AND mission_id=? AND status='pending' LIMIT 1",(user_id,mission_id)).fetchone()
        if pending: raise LookupError('You already have a pending proof for this mission')
        cur=c.execute("INSERT INTO battle_pass_submissions(user_id,mission_id,image_url,description,status) VALUES(?,?,?,?,'pending')",(user_id,mission_id,image_url,description[:500]))
        c.commit(); return cur.lastrowid
async def submit_bp_mission_proof(*args): return await asyncio.to_thread(submit_bp_mission_proof_sync,*args)

# ================== Dashboard custom shortcuts ==================
def get_shortcuts_sync():
    with closing(connect()) as c:
        rows = c.execute(
            "SELECT trigger_text, action_type, action_data FROM shortcuts ORDER BY LOWER(trigger_text)"
        ).fetchall()
        return [dict(row) for row in rows]

async def get_shortcuts():
    return await asyncio.to_thread(get_shortcuts_sync)

def save_shortcut_sync(trigger: str, action_type: str, action_data: str, original_trigger: str | None = None):
    trigger = str(trigger or "").strip().lower()
    action_type = str(action_type or "").strip().lower()
    action_data = str(action_data or "").strip()
    if not trigger or len(trigger) > 40:
        raise ValueError("اسم الاختصار مطلوب ويجب ألا يتجاوز 40 حرفاً")
    if action_type not in {"text", "command"}:
        raise ValueError("نوع الاختصار غير مدعوم")
    if not action_data or len(action_data) > 1800:
        raise ValueError("محتوى الاختصار مطلوب ويجب ألا يتجاوز 1800 حرف")
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            if original_trigger:
                original = str(original_trigger).strip().lower()
                exists = c.execute("SELECT 1 FROM shortcuts WHERE trigger_text=?", (original,)).fetchone()
                if not exists:
                    raise LookupError("الاختصار المراد تعديله غير موجود")
                collision = c.execute("SELECT 1 FROM shortcuts WHERE trigger_text=? AND trigger_text<>?", (trigger, original)).fetchone()
                if collision:
                    raise ValueError("هذا الاختصار مستخدم بالفعل")
                c.execute("UPDATE shortcuts SET trigger_text=?, action_type=?, action_data=? WHERE trigger_text=?",
                          (trigger, action_type, action_data, original))
            else:
                exists = c.execute("SELECT 1 FROM shortcuts WHERE trigger_text=?", (trigger,)).fetchone()
                if exists:
                    raise ValueError("هذا الاختصار موجود بالفعل؛ استخدم التعديل بدلاً من إنشاء نسخة أخرى")
                c.execute("INSERT INTO shortcuts(trigger_text, action_type, action_data) VALUES(?,?,?)",
                          (trigger, action_type, action_data))
            c.commit()
            return True
        except Exception:
            c.rollback()
            raise

async def save_shortcut(trigger: str, action_type: str, action_data: str, original_trigger: str | None = None):
    return await asyncio.to_thread(save_shortcut_sync, trigger, action_type, action_data, original_trigger)

def delete_shortcut_sync(trigger: str):
    with closing(connect()) as c:
        cur = c.execute("DELETE FROM shortcuts WHERE trigger_text=?", (str(trigger or "").strip().lower(),))
        c.commit()
        return cur.rowcount > 0

async def delete_shortcut(trigger: str):
    return await asyncio.to_thread(delete_shortcut_sync, trigger)

# ================== Per-guild dashboard settings ==================
def set_settings_sync(guild_id: int, log_channel_id, bot_status: str, status_text: str):
    allowed_statuses = {"playing", "watching", "listening", "competing"}
    if bot_status not in allowed_statuses:
        raise ValueError("نوع حالة البوت غير مدعوم")
    status_text = str(status_text or "").strip()
    if not status_text or len(status_text) > 128:
        raise ValueError("نص حالة البوت مطلوب ويجب ألا يتجاوز 128 حرفاً")
    with closing(connect()) as c:
        c.execute("BEGIN IMMEDIATE")
        try:
            # Update only log_channel_id; REPLACE would erase streak_channel_id.
            c.execute(
                "INSERT INTO guild_config(guild_id, log_channel_id) VALUES(?, ?) "
                "ON CONFLICT(guild_id) DO UPDATE SET log_channel_id=excluded.log_channel_id",
                (int(guild_id), int(log_channel_id) if log_channel_id is not None else None),
            )
            c.execute(
                "INSERT INTO dashboard_settings(guild_id, bot_status, status_text) VALUES(?, ?, ?) "
                "ON CONFLICT(guild_id) DO UPDATE SET bot_status=excluded.bot_status, status_text=excluded.status_text",
                (int(guild_id), bot_status, status_text),
            )
            c.commit()
            return True
        except Exception:
            c.rollback()
            raise

async def set_settings(guild_id: int, log_channel_id, bot_status: str, status_text: str):
    return await asyncio.to_thread(set_settings_sync, guild_id, log_channel_id, bot_status, status_text)
