from __future__ import annotations
import os, secrets, re, uuid, asyncio
from contextlib import asynccontextmanager
from urllib.parse import urlencode, urlsplit
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Literal

import httpx
from fastapi import FastAPI, Request, UploadFile, File, HTTPException, Depends
from fastapi.responses import FileResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from pydantic import BaseModel, Field, field_validator
from PIL import Image, UnidentifiedImageError

from web import store
from core import runtime

ROOT = Path(__file__).resolve().parents[1]
WEB_DIR = Path(__file__).resolve().parent
STATIC_DIR = WEB_DIR / "static"
UPLOAD_DIR = STATIC_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

CLIENT_ID = os.getenv("DISCORD_CLIENT_ID", "")
CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET", "")
REDIRECT_URI = os.getenv("DISCORD_REDIRECT_URI", "")
BOT_TOKEN = os.getenv("DISCORD_TOKEN", "")
SESSION_SECRET = os.getenv("WEB_SESSION_SECRET", "")
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "true").lower() == "true"
MAX_UPLOAD = 5 * 1024 * 1024
DISCORD_API = "https://discord.com/api/v10"

@asynccontextmanager
async def lifespan(app: FastAPI):
    await store.initialize()
    yield

app = FastAPI(title="REQUIEM: NEW ERA Dashboard", docs_url=None, redoc_url=None, lifespan=lifespan)
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET or "UNSAFE-LOCAL-ONLY-CHANGE-ME", session_cookie="requiem_session", max_age=3600, same_site="lax", https_only=COOKIE_SECURE)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/health")
async def health():
    return {"status":"ok","service":"requiem-dashboard"}


@app.get("/")
async def home(request: Request):
    if not request.session.get("user"):
        return RedirectResponse("/login")
    guild_id = str(request.session.get("guild_id", ""))
    guild = next((g for g in request.session.get("guilds", []) if str(g.get("id")) == guild_id), {})
    page = "dashboard.html" if (_staff_allowed(request.session.get("user", {}), guild, "moderator") or _staff_allowed(request.session.get("user", {}), guild, "proof_reviewer")) else "player.html"
    return FileResponse(STATIC_DIR / page, headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0", "Pragma": "no-cache", "Expires": "0"})


@app.get("/login")
async def login_page(request: Request):
    if request.session.get("user"):
        return RedirectResponse("/")
    return FileResponse(STATIC_DIR / "login.html", headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0", "Pragma": "no-cache", "Expires": "0"})


@app.get("/auth/discord")
async def oauth_start(request: Request):
    if not all([CLIENT_ID, CLIENT_SECRET, REDIRECT_URI, SESSION_SECRET]) or len(SESSION_SECRET) < 32:
        raise HTTPException(503, "Discord OAuth is not configured. Set CLIENT_ID, CLIENT_SECRET, REDIRECT_URI and WEB_SESSION_SECRET.")
    state = secrets.token_urlsafe(32)
    request.session["oauth_state"] = state
    url = "https://discord.com/oauth2/authorize?" + urlencode({"client_id":CLIENT_ID,"redirect_uri":REDIRECT_URI,"response_type":"code","scope":"identify guilds guilds.members.read","state":state})
    return RedirectResponse(url)


@app.get("/auth/callback")
async def oauth_callback(request: Request, code: str = "", state: str = "", error: str = ""):
    if error:
        return RedirectResponse("/login?error=denied")
    expected = request.session.pop("oauth_state", None)
    if not code or not expected or not secrets.compare_digest(str(expected), str(state)):
        request.session.clear()
        return RedirectResponse("/login?error=state")
    async with httpx.AsyncClient(timeout=15) as client:
        token_response = await client.post("https://discord.com/api/oauth2/token", data={
            "client_id": CLIENT_ID, "client_secret": CLIENT_SECRET, "grant_type": "authorization_code",
            "code": code, "redirect_uri": REDIRECT_URI
        }, headers={"Content-Type":"application/x-www-form-urlencoded"})
        if token_response.status_code != 200:
            return RedirectResponse("/login?error=oauth")
        access_token = token_response.json().get("access_token")
        headers = {"Authorization": f"Bearer {access_token}"}
        user_resp = await client.get(f"{DISCORD_API}/users/@me", headers=headers)
        guild_resp = await client.get(f"{DISCORD_API}/users/@me/guilds", headers=headers)
        if user_resp.status_code != 200 or guild_resp.status_code != 200:
            return RedirectResponse("/login?error=profile")
        user = user_resp.json()
        manageable = []
        for guild in guild_resp.json():
            # Player accounts may enter the community portal; administrative
            # endpoints are separately protected by Discord role checks below.
            bot_present = False
            if BOT_TOKEN:
                check = await client.get(f"{DISCORD_API}/guilds/{guild['id']}", headers={"Authorization":f"Bot {BOT_TOKEN}"})
                bot_present = check.status_code == 200
            else:
                live_bot = runtime.bot
                bot_present = bool(live_bot and live_bot.get_guild(int(guild['id'])))
            if bot_present:
                member_roles = []
                try:
                    member_resp = await client.get(f"{DISCORD_API}/users/@me/guilds/{guild['id']}/member", headers=headers)
                    if member_resp.status_code == 200:
                        member_roles = [str(role_id) for role_id in member_resp.json().get("roles", [])]
                except httpx.HTTPError:
                    member_roles = []
                manageable.append({"id":guild["id"],"name":guild["name"],"icon":guild.get("icon"),"owner":guild.get("owner",False),"roles":member_roles})
    if not manageable:
        request.session.clear()
        return RedirectResponse("/login?error=no_guild")
    request.session.clear()
    request.session["user"] = {"id":str(user["id"]),"username":user.get("username","Pirate"),"global_name":user.get("global_name") or user.get("username","Pirate"),"avatar":user.get("avatar")}
    request.session["guilds"] = manageable
    request.session["guild_id"] = manageable[0]["id"]
    request.session["csrf"] = secrets.token_urlsafe(32)
    return RedirectResponse("/")


def require_auth(request: Request):
    if not request.session.get("user"):
        raise HTTPException(401, "Authentication required")
    return request.session["user"]


def require_csrf(request: Request):
    token = request.headers.get("x-csrf-token", "")
    expected = request.session.get("csrf", "")
    if not token or not expected or not secrets.compare_digest(token, expected):
        raise HTTPException(403, "Invalid CSRF token")


def selected_guild(request: Request, user=Depends(require_auth)) -> int:
    gid = str(request.session.get("guild_id", ""))
    if not any(str(g.get("id")) == gid for g in request.session.get("guilds", [])):
        raise HTTPException(403, "No authorized server selected")
    return int(gid)

def _configured_ids(name: str) -> set[str]:
    return {part.strip() for part in os.getenv(name, "").split(",") if part.strip()}


def _staff_allowed(user: dict, guild: dict, role: str) -> bool:
    uid = str(user.get("id", ""))
    member_roles = {str(r) for r in guild.get("roles", [])}
    owner_ids = _configured_ids("REQUIEM_OWNER_IDS")
    admin_ids = _configured_ids("REQUIEM_ADMIN_IDS")
    moderator_ids = _configured_ids("REQUIEM_MODERATOR_IDS")
    reviewer_ids = _configured_ids("REQUIEM_PROOF_REVIEWER_IDS")
    owner_roles = _configured_ids("REQUIEM_OWNER_ROLE_IDS")
    admin_roles = _configured_ids("REQUIEM_ADMIN_ROLE_IDS")
    moderator_roles = _configured_ids("REQUIEM_MODERATOR_ROLE_IDS")
    reviewer_roles = _configured_ids("REQUIEM_PROOF_REVIEWER_ROLE_IDS")
    is_owner = bool(guild.get("owner")) or uid in owner_ids or bool(member_roles & owner_roles)
    is_admin = is_owner or uid in admin_ids or bool(member_roles & admin_roles)
    is_moderator = is_admin or uid in moderator_ids or bool(member_roles & moderator_roles)
    is_reviewer = is_moderator or uid in reviewer_ids or bool(member_roles & reviewer_roles)
    return {"owner": is_owner, "admin": is_admin, "moderator": is_moderator, "proof_reviewer": is_reviewer}.get(role, False)


def require_staff(role: str):
    """Role hierarchy backed by Discord guild roles and optional user allowlists."""
    if role not in {"owner", "admin", "moderator", "proof_reviewer"}:
        raise ValueError("Unknown staff role")
    async def dependency(request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
        guild = next((g for g in request.session.get("guilds", []) if str(g.get("id")) == str(guild_id)), {})
        if not _staff_allowed(user, guild, role):
            raise HTTPException(403, "لا تملك صلاحية تنفيذ هذه العملية")
        return user
    return dependency


class SelectGuild(BaseModel): guild_id: str
class IslandInput(BaseModel):
    id: str = Field(min_length=2,max_length=48,pattern=r"^[a-z0-9_-]+$")
    name: str = Field(min_length=2,max_length=80)
    emoji: str = Field(default="🏝️",max_length=12)
    description: str = Field(default="",max_length=500)
    min_points: int = Field(default=0,ge=0,le=10_000_000)
    image_url: str = Field(default="",max_length=500)
    order_index: int = Field(default=0,ge=0,le=10000)
    @field_validator("image_url")
    @classmethod
    def valid_image_url(cls, value):
        if not value:
            return value
        parsed=urlsplit(value)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Image URL must use HTTP or HTTPS")
        return value
class MissionInput(BaseModel):
    stage: int = Field(ge=1,le=100)
    description: str = Field(min_length=3,max_length=1000)
    character_id: Optional[str] = Field(default=None,max_length=80)
    alternatives: list[str] = Field(default_factory=list,max_length=10)
    reward_points: int = Field(default=0,ge=0,le=1_000_000)
    reward_coins: int = Field(default=0,ge=0,le=1_000_000)
    reward_gems: int = Field(default=0,ge=0,le=100_000)
    active: bool = True
    @field_validator("alternatives")
    @classmethod
    def clean_alternatives(cls,v):
        return list(dict.fromkeys(x.strip() for x in v if x and x.strip()))
class EconomyInput(BaseModel):
    user_id: int = Field(gt=0)
    currency: Literal["points", "coins", "gems", "bounty"]
    amount: int = Field(ge=-10_000_000,le=10_000_000)

    @field_validator("amount", mode="before")
    @classmethod
    def reject_boolean_amount(cls, value):
        if isinstance(value, bool):
            raise ValueError("Amount must be an integer, not a boolean")
        return value

    @field_validator("amount")
    @classmethod
    def reject_zero_amount(cls, value):
        if value == 0:
            raise ValueError("Amount must not be zero")
        return value

class ReviewInput(BaseModel):
    kind: str
    proof_id: int = Field(gt=0)
    decision: str
    note: str = Field(default="",max_length=500)
class BPSeasonInput(BaseModel):
    name: str = Field(min_length=1,max_length=100)
    description: str = Field(default="",max_length=1000)
    starts_at: Optional[str] = Field(default=None,max_length=40)
    ends_at: Optional[str] = Field(default=None,max_length=40)
    active: bool = False
class BPMissionInput(BaseModel):
    season_id: int = Field(gt=0)
    title: str = Field(min_length=1,max_length=100)
    description: str = Field(min_length=3,max_length=1000)
    required_count: int = Field(default=1,ge=1,le=100)
    reward_points: int = Field(default=0,ge=0,le=1_000_000)
    reward_coins: int = Field(default=0,ge=0,le=1_000_000)
    reward_gems: int = Field(default=0,ge=0,le=100_000)
    active: bool = True
class BPProofInput(BaseModel):
    mission_id: int = Field(gt=0)
    image_url: str = Field(min_length=8,max_length=2000)
    description: str = Field(default="",max_length=500)
    @field_validator("image_url")
    @classmethod
    def valid_bp_image_url(cls,value):
        parsed=urlsplit(value)
        if parsed.scheme not in {"http","https"} or not parsed.netloc:
            raise ValueError("Image URL must use HTTP or HTTPS")
        return value
class SettingsInput(BaseModel):
    log_channel_id: Optional[int] = Field(default=None,ge=1)
    bot_status: Literal["playing", "watching", "listening", "competing"] = "watching"
    status_text: str = Field(default="REQUIEM: NEW ERA | /profile",min_length=1,max_length=128)


@app.get("/api/me")
async def api_me(request: Request, user=Depends(require_auth)):
    return {"user":user,"guilds":request.session.get("guilds",[]),"guild_id":request.session.get("guild_id"),"csrf":request.session.get("csrf")}

@app.post("/api/select-guild")
async def api_select_guild(data: SelectGuild, request: Request, user=Depends(require_auth)):
    require_csrf(request)
    if not any(str(g["id"]) == data.guild_id for g in request.session.get("guilds", [])):
        raise HTTPException(403,"You do not have Manage Server permission for this guild")
    request.session["guild_id"] = data.guild_id
    return {"ok":True}

@app.post("/api/logout")
async def api_logout(request: Request, user=Depends(require_auth)):
    require_csrf(request); request.session.clear(); return {"ok":True}

@app.get("/api/overview")
async def api_overview(guild_id=Depends(selected_guild), user=Depends(require_staff("proof_reviewer"))):
    return await store.dashboard_summary(guild_id)

@app.get("/api/islands")
async def api_islands(user=Depends(require_staff("proof_reviewer")), guild_id=Depends(selected_guild)):
    return await store.load_catalog()

@app.get("/api/characters")
async def api_characters(user=Depends(require_staff("proof_reviewer")), guild_id=Depends(selected_guild)):
    return store.get_characters()

@app.get("/api/activity")
async def api_activity(user=Depends(require_staff("proof_reviewer")), guild_id=Depends(selected_guild)):
    from utils.db import get_recent_logs
    return await get_recent_logs(8)

@app.post("/api/islands")
async def api_create_island(data: IslandInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try: island_id=await store.save_island(data.model_dump())
    except Exception as e: raise HTTPException(400,str(e))
    return {"ok":True,"id":island_id}

@app.put("/api/islands/{island_id}")
async def api_update_island(island_id: str, data: IslandInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if data.id != island_id: raise HTTPException(400,"Island ID cannot be changed")
    try: await store.save_island(data.model_dump(),island_id)
    except LookupError: raise HTTPException(404,"Island not found")
    except Exception as e: raise HTTPException(400,str(e))
    return {"ok":True}

@app.delete("/api/islands/{island_id}")
async def api_delete_island(island_id: str, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try: await store.delete_island(island_id)
    except LookupError: raise HTTPException(404,"Island not found")
    except ValueError as e: raise HTTPException(409,str(e))
    return {"ok":True}

@app.post("/api/islands/{island_id}/missions")
async def api_create_mission(island_id: str, data: MissionInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    valid_characters=store.get_characters()
    if data.character_id and data.character_id not in valid_characters: raise HTTPException(400,"Unknown required character")
    if any(x not in valid_characters for x in data.alternatives): raise HTTPException(400,"Unknown alternative character")
    try: await store.save_mission(island_id,data.model_dump())
    except LookupError: raise HTTPException(404,"Island not found")
    except Exception as e: raise HTTPException(400,str(e))
    return {"ok":True}

@app.put("/api/islands/{island_id}/missions/{mission_id}")
async def api_update_mission(island_id: str, mission_id: int, data: MissionInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    valid_characters=store.get_characters()
    if data.character_id and data.character_id not in valid_characters: raise HTTPException(400,"Unknown required character")
    if any(x not in valid_characters for x in data.alternatives): raise HTTPException(400,"Unknown alternative character")
    try: await store.save_mission(island_id,data.model_dump(),mission_id)
    except LookupError: raise HTTPException(404,"Mission not found")
    except Exception as e: raise HTTPException(400,str(e))
    return {"ok":True}

@app.delete("/api/islands/{island_id}/missions/{mission_id}")
async def api_delete_mission(island_id: str, mission_id: int, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try: await store.delete_mission(island_id,mission_id)
    except LookupError: raise HTTPException(404,"Mission not found")
    except ValueError as e: raise HTTPException(409,str(e))
    return {"ok":True}

@app.post("/api/characters/{character_id}/image")
async def api_character_image(character_id: str, request: Request, data: dict, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if character_id not in store.get_characters():
        raise HTTPException(404, "Character not found")
    image_url = data.get("image_url", "")
    public_base = os.getenv("PUBLIC_BASE_URL", str(request.base_url).rstrip("/"))
    if not isinstance(image_url, str) or not image_url.startswith(public_base.rstrip("/") + "/static/uploads/"):
        raise HTTPException(400, "Upload an image through this dashboard first")
    from utils.db import set_image
    await set_image(character_id, image_url)
    return {"ok": True, "image_url": image_url}

@app.get("/api/users")
async def api_users(q: str = "", user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    query=q.strip()
    if len(query)>80: raise HTTPException(400,"Search query too long")
    rows=await store.list_users(query)
    by_id={int(r["user_id"]):r for r in rows}
    bot=runtime.bot
    guild=bot.get_guild(guild_id) if bot else None
    members=[]
    if guild and query:
        if query.isdigit():
            member=guild.get_member(int(query))
            if member is None:
                try: member=await guild.fetch_member(int(query))
                except Exception: member=None
            if member: members=[member]
        else:
            members=[m for m in getattr(guild,"members",[]) if query.casefold() in m.name.casefold() or query.casefold() in m.display_name.casefold()][:25]
            if not members and hasattr(guild,"query_members"):
                try: members=await guild.query_members(query=query,limit=25,cache=True)
                except Exception: members=[]
    from utils.db import get_user_data
    for member in members:
        wallet=await get_user_data(member.id,member.name)
        row={k:wallet.get(k) for k in ("user_id","username","points","coins","gems","bounty","rank","streak")}
        row["display_name"]=member.display_name
        by_id[int(member.id)]=row
    return sorted(by_id.values(),key=lambda r:(-int(r.get("points") or 0),int(r["user_id"])))[:30]

@app.get("/api/economy/health")
async def api_economy_health(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_health():
        with _conn() as conn:
            supply=conn.execute("SELECT COALESCE(SUM(points),0) points,COALESCE(SUM(coins),0) coins,COALESCE(SUM(gems),0) gems,COALESCE(SUM(bounty),0) bounty,COUNT(*) players FROM users").fetchone()
            movement=conn.execute("SELECT currency,COALESCE(SUM(delta),0) net_delta,COUNT(*) transactions FROM economy_transactions WHERE datetime(created_at)>=datetime('now','-7 days') GROUP BY currency").fetchall()
            return {"supply":dict(supply),"last_7_days":{r["currency"]:{"net_delta":r["net_delta"],"transactions":r["transactions"]} for r in movement}}
    return await asyncio.to_thread(read_health)

@app.get("/api/economy/orders")
async def api_shop_orders(status: str = "pending", user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    if status not in {"pending", "fulfilled", "all"}:
        raise HTTPException(400, "Invalid order status")
    return await store.list_shop_orders(status)

@app.post("/api/economy/orders/{order_id}/fulfill")
async def api_fulfill_shop_order(order_id: int, request: Request, user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if order_id <= 0:
        raise HTTPException(400, "Invalid order id")
    try:
        return await store.fulfill_shop_order(order_id, int(user["id"]))
    except LookupError as exc:
        raise HTTPException(409, str(exc))


@app.get("/api/economy/history/{user_id}")
async def api_economy_history(user_id: int, limit: int = 30, user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    if user_id <= 0:
        raise HTTPException(400, "Invalid user id")
    return await store.economy_history(user_id, max(1, min(limit, 100)))


@app.post("/api/economy/adjust")
async def api_economy(data: EconomyInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if data.currency not in {"points","coins","gems","bounty"}: raise HTTPException(400,"Invalid currency")
    if data.amount > 0:
        from utils.db import _conn, get_user_data
        with _conn() as conn:
            exists=conn.execute("SELECT 1 FROM users WHERE user_id=?",(data.user_id,)).fetchone()
        if not exists:
            bot=runtime.bot
            guild=bot.get_guild(guild_id) if bot else None
            member=guild.get_member(data.user_id) if guild else None
            if member is None and guild:
                try: member=await guild.fetch_member(data.user_id)
                except Exception: member=None
            if member is None:
                raise HTTPException(404,"اللاعب غير موجود في السيرفر المحدد")
            await get_user_data(member.id,member.name)
    try: result=await store.adjust_economy(data.user_id,data.currency,data.amount,int(user["id"]))
    except LookupError as e: raise HTTPException(404,str(e))
    except ValueError as e: raise HTTPException(400,str(e))
    return result

@app.get("/api/proofs")
async def api_proofs(status: Literal["pending", "approved", "rejected", "all"] = "pending", user=Depends(require_staff("proof_reviewer")), guild_id=Depends(selected_guild)):
    return await store.list_proofs(status)

@app.post("/api/proofs/review")
async def api_review(data: ReviewInput, request: Request, user=Depends(require_staff("proof_reviewer")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if data.kind not in {"grandline","hunter","league","streak","battle_pass","competitive"} or data.decision not in {"approved","rejected"}:
        raise HTTPException(400,"Invalid review action")
    try: result=await store.review_proof(data.kind,data.proof_id,data.decision,int(user["id"]),data.note)
    except LookupError as e: raise HTTPException(409,str(e))
    return result

@app.get("/api/battlepass/seasons")
async def api_bp_seasons(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    return await store.list_bp_seasons()

@app.post("/api/battlepass/seasons")
async def api_bp_save_season(data: BPSeasonInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        season_id=await store.save_bp_season(data.model_dump())
        return {"id":season_id}
    except ValueError as exc: raise HTTPException(400,str(exc))

@app.get("/api/battlepass/missions")
async def api_bp_missions(season_id: Optional[int] = None, active_only: bool = False, user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    return await store.list_bp_missions(season_id,active_only)

@app.post("/api/battlepass/missions")
async def api_bp_save_mission(data: BPMissionInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        mission_id=await store.save_bp_mission(data.model_dump())
        return {"id":mission_id}
    except LookupError as exc: raise HTTPException(404,str(exc))
    except ValueError as exc: raise HTTPException(400,str(exc))

@app.put("/api/battlepass/missions/{mission_id}")
async def api_bp_update_mission(mission_id: int, data: BPMissionInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if mission_id <= 0: raise HTTPException(400,"Invalid mission id")
    try: return {"id":await store.save_bp_mission(data.model_dump(),mission_id)}
    except LookupError as exc: raise HTTPException(404,str(exc))
    except ValueError as exc: raise HTTPException(400,str(exc))

@app.delete("/api/battlepass/missions/{mission_id}")
async def api_bp_delete_mission(mission_id: int, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if mission_id <= 0: raise HTTPException(400,"Invalid mission id")
    try: return {"ok":await store.delete_bp_mission(mission_id)}
    except ValueError as exc: raise HTTPException(409,str(exc))

@app.post("/api/battlepass/proofs")
async def api_bp_submit_proof(data: BPProofInput, request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        proof_id=await store.submit_bp_mission_proof(int(user["id"]),data.mission_id,data.image_url,data.description)
        return {"id":proof_id,"status":"pending"}
    except LookupError as exc: raise HTTPException(409,str(exc))

@app.post("/api/upload")
async def api_upload(request: Request, file: UploadFile = File(...), user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    content=await file.read(MAX_UPLOAD+1)
    if len(content)>MAX_UPLOAD: raise HTTPException(413,"Maximum image size is 5 MB")
    try:
        import io
        img=Image.open(io.BytesIO(content))
        if img.width > 8192 or img.height > 8192:
            raise HTTPException(400, "Image dimensions must not exceed 8192 × 8192")
        fmt=img.format
        img.verify()
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(400,"Only valid PNG, JPG or WEBP images are allowed")
    ext={"PNG":".png","JPEG":".jpg","WEBP":".webp"}.get(fmt)
    if not ext: raise HTTPException(400,"Unsupported image format")
    name=f"{uuid.uuid4().hex}{ext}"
    path=UPLOAD_DIR/name
    path.write_bytes(content)
    public_base = os.getenv("PUBLIC_BASE_URL", str(request.base_url).rstrip("/"))
    return {"url":f"{public_base.rstrip('/')}/static/uploads/{name}"}

@app.get("/api/settings")
async def api_get_settings(guild_id=Depends(selected_guild), user=Depends(require_staff("admin"))):
    summary=await store.dashboard_summary(guild_id)
    return {"log_channel_id":summary["log_channel_id"],"bot_status":summary["bot_status"],"status_text":summary["status_text"]}

@app.put("/api/settings")
async def api_save_settings(data: SettingsInput, request: Request, guild_id=Depends(selected_guild), user=Depends(require_staff("admin"))):
    require_csrf(request)
    if data.log_channel_id is not None:
        bot=runtime.bot
        if bot and bot.get_guild(guild_id) and not bot.get_guild(guild_id).get_channel(data.log_channel_id):
            raise HTTPException(400,"Log channel does not belong to the selected server")
    await store.set_settings(guild_id,data.log_channel_id,data.bot_status,data.status_text)
    bot=runtime.bot
    if bot and bot.is_ready():
        activity_types={"playing":0,"streaming":1,"listening":2,"watching":3,"competing":5}
        activity_type=activity_types[data.bot_status]
        activity=discord_activity(data.status_text,activity_type)
        await bot.change_presence(activity=activity)
    return {"ok":True}


def discord_activity(text: str, kind: int):
    import discord
    mapping={0:discord.ActivityType.playing,1:discord.ActivityType.streaming,2:discord.ActivityType.listening,3:discord.ActivityType.watching,5:discord.ActivityType.competing}
    return discord.Activity(type=mapping.get(kind,discord.ActivityType.watching),name=text)

@app.get("/logout")
async def logout(request: Request):
    request.session.clear(); return RedirectResponse("/login")

from pydantic import BaseModel
from fastapi import HTTPException

class BPTierInput(BaseModel):
    tier: int = Field(ge=1, le=1000)
    required_points: int = Field(ge=0, le=100000000)
    reward_coins: int = Field(ge=0, le=100000000)
    reward_gems: int = Field(ge=0, le=100000000)
    label: str = Field(min_length=1, max_length=100)

    @field_validator("label")
    @classmethod
    def clean_label(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("اسم المكافأة مطلوب")
        return value

@app.get("/api/bp")
async def api_get_bp(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    return await store.get_bp_tiers()

@app.post("/api/bp")
async def api_create_bp(data: BPTierInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        await store.save_bp_tier(data.model_dump())
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    return {"ok": True}

@app.put("/api/bp/{tier_id}")
async def api_update_bp(tier_id: int, data: BPTierInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        await store.save_bp_tier(data.model_dump(), tier_id)
    except LookupError:
        raise HTTPException(404, "Tier not found")
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    return {"ok": True}

@app.delete("/api/bp/{tier_id}")
async def api_delete_bp(tier_id: int, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    deleted = await store.delete_bp_tier(tier_id)
    if not deleted:
        raise HTTPException(404, "Tier not found")
    return {"ok": True}

from pydantic import BaseModel, Field, field_validator
from typing import Literal

class ShortcutInput(BaseModel):
    trigger_text: str = Field(min_length=1, max_length=40)
    action_type: Literal["text", "command"]
    action_data: str = Field(min_length=1, max_length=1800)
    original_trigger: Optional[str] = None

    @field_validator("trigger_text")
    @classmethod
    def validate_trigger(cls, value: str) -> str:
        value = value.strip().lower()
        if not value or any(ch.isspace() for ch in value):
            raise ValueError("اسم الاختصار يجب أن يكون كلمة واحدة دون مسافات")
        if len(value) > 40:
            raise ValueError("اسم الاختصار طويل جداً")
        return value

    @field_validator("action_data")
    @classmethod
    def validate_action_data(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("محتوى الاختصار مطلوب")
        return value

@app.get("/api/shortcuts")
async def api_get_shortcuts(user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    return await store.get_shortcuts()

@app.get("/api/shortcuts/commands")
async def api_get_shortcut_commands(user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    bot = runtime.bot
    if not bot:
        return []
    result = []
    from utils.db import get_synced_command_id
    async def collect(items):
        for command in items:
            children = getattr(command, "commands", None)
            if children:
                await collect(children)
            else:
                name = getattr(command, "qualified_name", command.name)
                command_id = await get_synced_command_id(name, guild_id)
                result.append({"name": name, "description": (getattr(command, "description", "") or "")[:100],
                               "command_id": command_id, "synced": bool(command_id)})
    await collect(bot.tree.get_commands())
    return sorted(result, key=lambda item: item["name"])

@app.post("/api/shortcuts/sync")
async def api_sync_shortcut_commands(request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    bot = runtime.bot
    if not bot or not bot.is_ready():
        raise HTTPException(503, "Discord bot is not ready")
    try:
        test_guild_id = os.getenv("TEST_GUILD_ID")
        if test_guild_id:
            target = discord_object(int(test_guild_id))
            bot.tree.copy_global_to(guild=target)
            synced = await bot.tree.sync(guild=target)
            scope_id = int(test_guild_id)
        else:
            synced = await bot.tree.sync()
            scope_id = 0
        from utils.db import save_synced_commands
        registry = [{"name": getattr(cmd, "qualified_name", cmd.name), "id": int(cmd.id)} for cmd in synced if getattr(cmd, "id", None)]
        saved = await save_synced_commands(scope_id, registry)
        return {"synced": len(synced), "saved_ids": saved, "scope_id": scope_id}
    except Exception as exc:
        raise HTTPException(502, f"تعذرت مزامنة أوامر Discord: {type(exc).__name__}")


def discord_object(guild_id: int):
    import discord
    return discord.Object(id=guild_id)


@app.post("/api/shortcuts")
async def api_create_shortcut(data: ShortcutInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if data.action_type == "command":
        bot = runtime.bot
        command = bot.tree.get_command(data.action_data) if bot else None
        if command is None:
            raise HTTPException(422, "الأمر المحدد غير موجود ضمن أوامر البوت الحالية")
    try:
        await store.save_shortcut(data.trigger_text, data.action_type, data.action_data)
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    return {"ok": True}

@app.put("/api/shortcuts/{trigger}")
async def api_update_shortcut(trigger: str, data: ShortcutInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    if data.action_type == "command":
        bot = runtime.bot
        command = bot.tree.get_command(data.action_data) if bot else None
        if command is None:
            raise HTTPException(422, "الأمر المحدد غير موجود ضمن أوامر البوت الحالية")
    try:
        await store.save_shortcut(data.trigger_text, data.action_type, data.action_data, original_trigger=trigger)
    except LookupError as exc:
        raise HTTPException(404, str(exc))
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    return {"ok": True}

@app.delete("/api/shortcuts/{trigger}")
async def api_delete_shortcut(trigger: str, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    deleted = await store.delete_shortcut(trigger)
    if not deleted:
        raise HTTPException(404, "الاختصار غير موجود")
    return {"ok": True}


# ── Competitive ecosystem API ──────────────────────────────────────────────
from pydantic import BaseModel, Field

class MatchQueueInput(BaseModel):
    mode: Literal["general", "tournament"] = "general"
    max_rating_gap: int = Field(default=250, ge=0, le=2000)

class RivalInput(BaseModel):
    rival_id: int = Field(gt=0)

class MatchReviewInput(BaseModel):
    decision: Literal["approved", "rejected"]
    winner_id: Optional[int] = None
    note: str = Field(default="", max_length=500)

@app.get("/api/competitive/profile/{player_id}")
async def competitive_profile(player_id: int, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    if player_id <= 0:
        raise HTTPException(400, "Invalid player ID")
    # Profile output is intentionally restricted to public competitive statistics.
    from utils.competitive import get_player_ratings, player_analytics, list_rivals, player_match_history, list_player_achievements
    from utils.db import _conn
    def read_player():
        with _conn() as conn:
            row = conn.execute("SELECT user_id,username,rank,points,coins,gems,bounty,streak FROM users WHERE user_id=?", (player_id,)).fetchone()
            return dict(row) if row else {"user_id": player_id, "username": "", "rank": "المبتدئ", "points": 0, "coins": 0, "gems": 0, "bounty": 0, "streak": 0}
    player = await asyncio.to_thread(read_player)
    return {"player": {k: player.get(k) for k in ("user_id", "username", "rank", "points", "coins", "gems", "bounty", "streak")},
            "ratings": await asyncio.to_thread(get_player_ratings, player_id),
            "analytics": await asyncio.to_thread(player_analytics, player_id),
            "rivals": await asyncio.to_thread(list_rivals, player_id),
            "matches": await asyncio.to_thread(player_match_history, player_id),
            "achievements": await asyncio.to_thread(list_player_achievements, player_id)}

@app.get("/api/competitive/leaderboard")
async def competitive_leaderboard(mode: Literal["general", "tournament"] = "general", limit: int = 10,
                                  user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import leaderboard
    return await asyncio.to_thread(leaderboard, mode, limit)

@app.get("/api/competitive/wanted")
async def competitive_wanted(user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import wanted_board
    return await asyncio.to_thread(wanted_board)

@app.get("/api/competitive/queue")
async def competitive_queue_status(user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import matchmaking_status
    return await asyncio.to_thread(matchmaking_status, int(user["id"]))

@app.post("/api/competitive/queue")
async def competitive_queue(data: MatchQueueInput, request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import queue_for_match
    try:
        return await asyncio.to_thread(queue_for_match, int(user["id"]), data.mode, data.max_rating_gap)
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.delete("/api/competitive/queue")
async def competitive_leave_queue(request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import leave_matchmaking
    return {"left": await asyncio.to_thread(leave_matchmaking, int(user["id"]))}

@app.post("/api/competitive/rivals")
async def competitive_add_rival(data: RivalInput, request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import set_rival
    try:
        await asyncio.to_thread(set_rival, int(user["id"]), data.rival_id)
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.post("/api/competitive/matches/{match_id}/review")
async def competitive_review_match(match_id: int, data: MatchReviewInput, request: Request,
                                   user=Depends(require_staff("proof_reviewer")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        # Ranked results are reviewed through the same persistent proof queue;
        # the reviewer cannot award a win without a submitted screenshot.
        return await store.review_proof("competitive", match_id, data.decision, int(user["id"]), data.note)
    except LookupError as exc:
        raise HTTPException(404, str(exc))
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.get("/api/system/database-health")
async def system_database_health(user=Depends(require_staff("owner")), guild_id=Depends(selected_guild)):
    from utils.backups import database_health
    from utils.db import DB_PATH as runtime_db_path
    return await asyncio.to_thread(database_health, runtime_db_path)

class CosmeticInput(BaseModel):
    item_id: str = Field(min_length=2, max_length=80)
    name: str = Field(min_length=1, max_length=100)
    category: str = Field(min_length=1, max_length=40)
    currency: Literal["coins", "gems", "bounty", "points"]
    price: int = Field(ge=0, le=10_000_000)
    rarity: str = Field(default="common", max_length=30)
    rotation: Literal["daily", "weekly", "seasonal", "permanent"] = "permanent"

class CosmeticPurchaseInput(BaseModel):
    item_id: str = Field(min_length=2, max_length=80)
    idempotency_key: str = Field(min_length=8, max_length=160)

class EquipInput(BaseModel):
    item_id: str = Field(min_length=2, max_length=80)

class CompetitiveSeasonInput(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    starts_at: str = Field(min_length=10, max_length=40)
    ends_at: str = Field(min_length=10, max_length=40)

class AbuseReviewInput(BaseModel):
    decision: Literal["reviewed", "dismissed"]

@app.get("/api/competitive/catalog")
async def competitive_catalog(user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import list_cosmetics
    return await asyncio.to_thread(list_cosmetics)

@app.post("/api/competitive/catalog")
async def competitive_catalog_save(data: CosmeticInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import upsert_cosmetic
    try:
        await asyncio.to_thread(upsert_cosmetic, data.item_id, data.name, data.category, data.currency, data.price, data.rarity, data.rotation)
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "cosmetic_catalog_upsert", None, f"item={data.item_id}; rotation={data.rotation}; price={data.price} {data.currency}")
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.get("/api/competitive/shop")
async def competitive_shop(rotation: Literal["daily", "weekly", "seasonal", "permanent"] = "daily", user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import rotating_shop
    return await asyncio.to_thread(rotating_shop, rotation)

@app.get("/api/competitive/inventory/{player_id}")
async def competitive_inventory(player_id: int, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    if player_id != int(user["id"]):
        raise HTTPException(403, "يمكنك عرض مقتنيات حسابك فقط")
    from utils.competitive import player_inventory
    return await asyncio.to_thread(player_inventory, player_id)

@app.post("/api/competitive/purchase")
async def competitive_purchase(data: CosmeticPurchaseInput, request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import purchase_cosmetic
    try:
        return await asyncio.to_thread(purchase_cosmetic, int(user["id"]), data.item_id, data.idempotency_key)
    except LookupError as exc:
        raise HTTPException(404, str(exc))
    except ValueError as exc:
        raise HTTPException(409, str(exc))

@app.post("/api/competitive/equip")
async def competitive_equip(data: EquipInput, request: Request, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import equip_inventory_item
    try:
        return {"equipped": await asyncio.to_thread(equip_inventory_item, int(user["id"]), data.item_id)}
    except LookupError as exc:
        raise HTTPException(404, str(exc))

@app.get("/api/competitive/seasons")
async def competitive_seasons(user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import list_competitive_seasons
    return await asyncio.to_thread(list_competitive_seasons)

@app.post("/api/competitive/seasons")
async def competitive_season_create(data: CompetitiveSeasonInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import create_competitive_season
    try:
        season_id = await asyncio.to_thread(create_competitive_season, data.name, data.starts_at, data.ends_at)
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "competitive_season_create", season_id, data.name)
        return {"id": season_id}
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.post("/api/competitive/seasons/{season_id}/activate")
async def competitive_season_activate(season_id: int, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import activate_competitive_season
    try:
        await asyncio.to_thread(activate_competitive_season, season_id)
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "competitive_season_activate", season_id, "activated")
        return {"ok": True}
    except LookupError as exc:
        raise HTTPException(404, str(exc))

@app.post("/api/competitive/seasons/{season_id}/archive")
async def competitive_season_archive(season_id: int, request: Request, user=Depends(require_staff("owner")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import archive_competitive_season
    try:
        archived = await asyncio.to_thread(archive_competitive_season, season_id)
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "competitive_season_archive", season_id, f"entries={archived}")
        return {"archived_entries": archived}
    except LookupError as exc:
        raise HTTPException(404, str(exc))

@app.get("/api/competitive/flags")
async def competitive_flags(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_flags():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM anti_abuse_flags ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 ELSE 3 END,created_at DESC LIMIT 200").fetchall()]
    return await asyncio.to_thread(read_flags)

@app.post("/api/competitive/flags/{flag_id}/review")
async def competitive_flag_review(flag_id: int, data: AbuseReviewInput, request: Request, user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import review_abuse_flag
    changed = await asyncio.to_thread(review_abuse_flag, flag_id, int(user["id"]), data.decision)
    if not changed:
        raise HTTPException(404, "Flag not found or already reviewed")
    return {"ok": True}

class AchievementInput(BaseModel):
    achievement_id: str = Field(min_length=2, max_length=80)
    title: str = Field(min_length=1, max_length=100)
    description: str = Field(default="", max_length=500)
    category: Literal["daily", "weekly", "seasonal", "permanent"]
    trigger_key: str = Field(min_length=2, max_length=80)
    target: int = Field(ge=1, le=1_000_000)
    reward_points: int = Field(default=0, ge=0, le=10_000_000)
    reward_coins: int = Field(default=0, ge=0, le=10_000_000)
    reward_gems: int = Field(default=0, ge=0, le=10_000_000)
    reward_bounty: int = Field(default=0, ge=0, le=10_000_000)
    title_reward: str = Field(default="", max_length=80)
    badge_reward: str = Field(default="", max_length=80)
    hidden: bool = False
    active: bool = True
    season_id: Optional[int] = None

class AchievementClaimInput(BaseModel):
    period_key: str = Field(min_length=1, max_length=80)

@app.get("/api/achievements")
async def achievements_for_current_player(user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.competitive import list_player_achievements
    return await asyncio.to_thread(list_player_achievements, int(user["id"]))

@app.post("/api/achievements")
async def achievement_create(data: AchievementInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import create_achievement
    try:
        achievement_id = await asyncio.to_thread(create_achievement, data.model_dump())
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "achievement_upsert", None, achievement_id)
        return {"achievement_id": achievement_id}
    except ValueError as exc:
        raise HTTPException(400, str(exc))

@app.post("/api/achievements/{achievement_id}/claim")
async def achievement_claim(achievement_id: str, data: AchievementClaimInput, request: Request,
                            user=Depends(require_auth), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.competitive import claim_achievement
    try:
        return await asyncio.to_thread(claim_achievement, int(user["id"]), achievement_id, data.period_key)
    except LookupError as exc:
        raise HTTPException(409, str(exc))

@app.get("/api/competitive/seasons/{season_id}/hall-of-fame")
async def competitive_hall_of_fame(season_id: int, mode: Literal["general", "tournament"] = "general",
                                   user=Depends(require_auth), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_hall():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT a.final_rank,a.final_rating,a.user_id,u.username,a.archived_at FROM season_archive a JOIN users u ON u.user_id=a.user_id WHERE a.season_id=? AND a.mode=? ORDER BY a.final_rank LIMIT 100",(season_id,mode)).fetchall()]
    return await asyncio.to_thread(read_hall)


class TournamentCreateInput(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    size: int = Field(ge=4, le=32)

class AnnouncementInput(BaseModel):
    channel_id: int = Field(gt=0)
    message: str = Field(min_length=1, max_length=1900)

@app.get("/api/tournaments")
async def api_tournaments(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_tournaments():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT t.*,COUNT(p.user_id) AS player_count FROM tournaments t LEFT JOIN tournament_players p ON p.tournament_id=t.id GROUP BY t.id ORDER BY t.id DESC LIMIT 100").fetchall()]
    return await asyncio.to_thread(read_tournaments)

@app.post("/api/tournaments")
async def api_tournament_create(data: TournamentCreateInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    from utils.db import create_tournament
    try:
        tournament_id=await create_tournament(data.name,data.size,int(user["id"]))
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "tournament_create", tournament_id, f"{data.name}; size={data.size}")
        return {"id":tournament_id}
    except ValueError as exc:
        raise HTTPException(400,str(exc))

@app.post("/api/tournaments/{tournament_id}/start")
async def api_tournament_start(tournament_id: int, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    try:
        matches=await store.start_tournament(tournament_id)
        from utils.competitive import record_staff_audit
        await asyncio.to_thread(record_staff_audit, int(user["id"]), "tournament_start", tournament_id, f"round1_matches={len(matches)}")
        return {"matches":matches}
    except LookupError as exc:
        raise HTTPException(404,str(exc))
    except ValueError as exc:
        raise HTTPException(409,str(exc))

@app.get("/api/tournaments/{tournament_id}/matches")
async def api_tournament_matches(tournament_id: int, user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_matches():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM tournament_matches WHERE tournament_id=? ORDER BY round_number,match_number",(tournament_id,)).fetchall()]
    return await asyncio.to_thread(read_matches)

@app.get("/api/challenges")
async def api_challenges(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_challenges():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM direct_challenges ORDER BY id DESC LIMIT 200").fetchall()]
    return await asyncio.to_thread(read_challenges)

@app.get("/api/streaks/history/{player_id}")
async def api_player_streak_history(player_id: int, user=Depends(require_auth), guild_id=Depends(selected_guild)):
    if player_id != int(user["id"]):
        raise HTTPException(403,"يمكنك عرض سجل الستريك الخاص بحسابك فقط")
    from utils.db import get_streak_history
    return await get_streak_history(player_id,30)

@app.get("/api/streaks")
async def api_streaks(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_streaks():
        with _conn() as conn:
            leaderboard=[dict(r) for r in conn.execute("SELECT user_id,username,streak,last_streak_date FROM users ORDER BY streak DESC,user_id LIMIT 50").fetchall()]
            claims=[dict(r) for r in conn.execute("SELECT * FROM streak_claims ORDER BY claim_date DESC,id DESC LIMIT 100").fetchall()]
            return {"leaderboard":leaderboard,"claims":claims}
    return await asyncio.to_thread(read_streaks)

@app.get("/api/audit-logs")
async def api_audit_logs(limit: int = 100, user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    limit=max(1,min(limit,200))
    def read_logs():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]
    return await asyncio.to_thread(read_logs)

@app.get("/api/announcements")
async def api_announcements(user=Depends(require_staff("moderator")), guild_id=Depends(selected_guild)):
    from utils.db import _conn
    def read_announcements():
        with _conn() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM announcements WHERE guild_id=? ORDER BY id DESC LIMIT 100",(guild_id,)).fetchall()]
    return await asyncio.to_thread(read_announcements)

@app.post("/api/announcements")
async def api_announcement_send(data: AnnouncementInput, request: Request, user=Depends(require_staff("admin")), guild_id=Depends(selected_guild)):
    require_csrf(request)
    bot=runtime.bot
    guild=bot.get_guild(guild_id) if bot else None
    channel=guild.get_channel(data.channel_id) if guild else None
    if channel is None:
        raise HTTPException(404,"القناة غير موجودة في السيرفر المحدد أو البوت غير متصل")
    try:
        import discord
        message=await channel.send(data.message,allowed_mentions=discord.AllowedMentions.none())
    except Exception as exc:
        raise HTTPException(502,f"فشل إرسال الإعلان عبر Discord: {type(exc).__name__}")
    from utils.db import _conn
    def save_announcement():
        with _conn() as conn:
            cur=conn.execute("INSERT INTO announcements(guild_id,channel_id,actor_id,message,discord_message_id,created_at) VALUES(?,?,?,?,?,?)",(guild_id,data.channel_id,int(user["id"]),data.message,int(message.id),datetime.now(timezone.utc).isoformat()))
            conn.execute("INSERT INTO audit_logs(actor_id,action,target_id,details,created_at) VALUES(?,?,?,?,?)",(int(user["id"]),"announcement_sent",data.channel_id,f"announcement_id={cur.lastrowid}; message_id={message.id}",datetime.now(timezone.utc).isoformat()))
            conn.commit(); return int(cur.lastrowid)
    announcement_id=await asyncio.to_thread(save_announcement)
    return {"id":announcement_id,"discord_message_id":message.id,"sent":True}
