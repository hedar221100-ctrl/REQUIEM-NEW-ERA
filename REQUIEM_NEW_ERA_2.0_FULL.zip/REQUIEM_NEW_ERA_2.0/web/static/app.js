const state={csrf:'',guilds:[],guildId:'',islands:[],characters:{},selectedIsland:null,players:[],selectedPlayer:null,proofs:[],proofFilter:'all',proofStatus:'pending',editingShortcut:null,shortcutCommands:[]};
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const safeUrl=v=>{try{const u=new URL(String(v||''),location.origin);return ['http:','https:'].includes(u.protocol)?u.href:'#'}catch{return '#'}};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message,type='ok'){const n=document.createElement('div');n.className=`toast ${type}`;n.textContent=message;$('#toast-container').append(n);setTimeout(()=>n.remove(),3600)}
async function api(url,opts={}){const headers={...(opts.headers||{})};if(opts.method&&opts.method!=='GET')headers['X-CSRF-Token']=state.csrf;if(opts.body&&!(opts.body instanceof FormData))headers['Content-Type']='application/json';const r=await fetch(url,{...opts,headers,credentials:'same-origin'});if(r.status===401){location.href='/login';throw new Error('انتهت جلسة الدخول')}const data=await r.json().catch(()=>({detail:'حدث خطأ غير متوقع'}));if(!r.ok)throw new Error(data.detail||'تعذر تنفيذ العملية');return data}

function showPage(name){
    $$('.page').forEach(x=>x.classList.toggle('active',x.id===`page-${name}`));
    $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.page===name));
    const labels={overview:'نظرة عامة',islands:'الجزر والمهام',proofs:'مراجعة الإثباتات',economy:'اقتصاد اللاعبين',battlepass:'Battle Pass',settings:'إعدادات البوت',shortcuts:'الاختصارات',competitive:'التصنيف التنافسي',wanted:'Wanted Board',market:'السوق والمقتنيات',achievements:'الإنجازات',tournaments:'البطولات',challenges:'التحديات',streaks:'الستريك',announcements:'الإعلانات',audit:'سجل التدقيق'};
    $('#page-breadcrumb').textContent=labels[name]||name;
    $('#sidebar').classList.remove('open');$('#sidebar-overlay')?.classList.remove('visible');
    if(name==='islands')renderIslands();
    if(name==='proofs')loadProofs();
    if(name==='economy'){loadShopOrders();loadEconomyHealth();}
    if(name==='settings')loadSettings();
    if(name==='battlepass')loadBP();
    if(name==='shortcuts')loadShortcuts();
    if(name==='competitive')loadCompetitive();
    if(name==='wanted')loadWanted();
    if(name==='market')loadMarket();
    if(name==='achievements')loadAchievements();
    if(name==='tournaments')loadTournaments();
    if(name==='challenges')loadChallenges();
    if(name==='streaks')loadStreaks();
    if(name==='announcements')loadAnnouncements();
    if(name==='audit')loadAuditLogs();
}

function avatarUrl(user){return user?.avatar?`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`:'/static/images/requiem-logo.png'}

async function init(){
    try{
        const me=await api('/api/me');state.csrf=me.csrf;state.guilds=me.guilds;state.guildId=me.guild_id;state.userId=me.user.id;
        $('#user-name').textContent=me.user.global_name||me.user.username;
        $('#user-avatar').src=avatarUrl(me.user);
        $('#guild-select').innerHTML=state.guilds.map(g=>`<option value="${esc(g.id)}" ${g.id===state.guildId?'selected':''}>${esc(g.name)}</option>`).join('');
        $('#today-label').textContent=new Intl.DateTimeFormat('ar-IQ',{dateStyle:'full'}).format(new Date());
        state.characters=await api('/api/characters');
        $('#character-image-select').innerHTML='<option value="">اختر شخصية...</option>'+Object.entries(state.characters).map(([id,c])=>`<option value="${esc(id)}">${esc(c.name)}</option>`).join('');
        await loadIslands();
        await loadOverview();
        await loadActivity();
    }catch(e){toast(e.message,'error')}
}

async function loadOverview(){
    const d=await api('/api/overview');
    $('#stat-users').textContent=Number(d.users).toLocaleString('en-US');
    $('#stat-islands').textContent=Number(d.islands).toLocaleString('en-US');
    $('#stat-missions').textContent=Number(d.missions).toLocaleString('en-US');
    $('#stat-pending').textContent=Number(d.pending).toLocaleString('en-US');
    $('#proof-nav-count').textContent=d.pending;
    $('#island-nav-count').textContent=d.islands;
    $('#island-strip').innerHTML=state.islands.slice(0,6).map((i,n)=>`<div class="island-chip"><span class="island-chip-no">${String(n+1).padStart(2,'0')}</span><b>${esc(i.emoji)} ${esc(i.name)}</b><small>${i.missions.length} مراحل</small></div>`).join('')||'<div class="empty-inline">لا توجد جزر بعد.</div>';
}

async function loadActivity(){
    try{
        const rows=await api('/api/activity');
        const labels={dashboard_economy_adjust:'تعديل رصيد لاعب',dashboard_grandline_approved:'قبول إثبات Grand Line',dashboard_grandline_rejected:'رفض إثبات Grand Line',dashboard_hunter_approved:'قبول إثبات Hunters',dashboard_hunter_rejected:'رفض إثبات Hunters',dashboard_league_approved:'قبول إثبات League',dashboard_league_rejected:'رفض إثبات League',battle_pass_claim:'استلام مكافأة Battle Pass'};
        $('#activity-list').innerHTML=rows.map(row=>`<article class="activity-row"><span class="activity-icon"><i class="fa-solid fa-clock-rotate-left"></i></span><div class="activity-copy"><b>${esc(labels[row.action]||row.action||'عملية إدارية')}</b><small>المنفّذ: #${esc(row.actor_id)}${row.target_id?` · الهدف: #${esc(row.target_id)}`:''}</small>${row.details?`<span>${esc(row.details)}</span>`:''}</div><time>${esc(row.created_at||'')}</time></article>`).join('')||'<div class="empty-inline">لا توجد عمليات مسجلة حتى الآن.</div>';
    }catch(e){$('#activity-list').innerHTML='<div class="empty-inline">تعذر تحميل سجل النشاط.</div>';}
}

async function loadIslands(){
    state.islands=await api('/api/islands');
    $('#island-nav-count').textContent=state.islands.length;
    $('#island-count-pill').textContent=state.islands.length;
    if($('#page-islands').classList.contains('active'))renderIslands();
    if($('#island-strip'))$('#island-strip').innerHTML=state.islands.slice(0,6).map((i,n)=>`<div class="island-chip"><span class="island-chip-no">${String(n+1).padStart(2,'0')}</span><b>${esc(i.emoji)} ${esc(i.name)}</b><small>${i.missions.length} مراحل</small></div>`).join('')||'<div class="empty-inline">لا توجد جزر بعد.</div>';
}

function renderIslands(){
    const list=$('#island-list');
    list.innerHTML=state.islands.map((i,n)=>`<button class="island-row ${state.selectedIsland===i.id?'selected':''}" data-island="${esc(i.id)}"><span class="island-row-emoji">${esc(i.emoji)}</span><span class="island-row-copy"><b>${esc(i.name)}</b><small>${i.missions.length} مهام · ${Number(i.min_points).toLocaleString()} نقطة للفتح</small></span><span class="island-row-num">${String(n+1).padStart(2,'0')}</span></button>`).join('')||'<div class="empty-inline">لا توجد جزر. أضف جزيرتك الأولى.</div>';
    $$('[data-island]').forEach(b=>b.onclick=()=>selectIsland(b.dataset.island));
    if(state.selectedIsland&&state.islands.some(i=>i.id===state.selectedIsland))renderIslandEditor();
    else $('#island-editor').innerHTML='<div class="empty-state"><div>♧</div><h3>اختر جزيرة من القائمة</h3><p>ستظهر تفاصيل الجزيرة ومهامها هنا.</p></div>';
}

function selectIsland(id){state.selectedIsland=id;renderIslands();}

function renderIslandEditor(){
    const i=state.islands.find(x=>x.id===state.selectedIsland);if(!i)return;
    $('#island-editor').innerHTML=`<div class="editor-cover">${i.image?`<img class="editor-cover-img" src="${esc(safeUrl(i.image))}" alt="">`:''}<div class="editor-cover-copy"><span class="eyebrow">ISLAND DOSSIER / ${esc(i.id.toUpperCase())}</span><h2>${esc(i.emoji)} ${esc(i.name)}</h2><p>${esc(i.desc||'لا يوجد وصف لهذه الجزيرة بعد.')}</p></div><span class="cover-index">GRAND LINE</span></div><div class="editor-meta"><div><small>نقاط الفتح</small><b>${Number(i.min_points).toLocaleString('en-US')} <em>PTS</em></b></div><div><small>عدد المراحل</small><b>${i.missions.length.toLocaleString('en-US')} <em>MISSIONS</em></b></div><div><small>المعرّف</small><b class="id-value">${esc(i.id)}</b></div><button class="outline-btn" id="edit-island-btn">✎ تعديل الجزيرة</button><button class="outline-btn danger-outline" id="delete-island-btn">حذف</button></div><div class="mission-section-head"><div><span class="eyebrow">MISSION SEQUENCE</span><h3>مراحل الجزيرة</h3></div><button class="small-primary" id="add-mission-btn">＋ إضافة مهمة</button></div><div class="mission-list">${i.missions.map((m,n)=>`<article class="mission-row"><div class="mission-index">${String(n+1).padStart(2,'0')}</div><div class="mission-content"><b>${esc(m.desc)}</b><div class="mission-tags">${m.character?`<span>♟ ${esc(state.characters[m.character]?.name||m.character)}</span>`:'<span>⚑ تحدي عام</span>'}<span>⭐ ${m.reward_points??100*(n+1)} نقطة</span><span>🪙 ${m.reward_coins??500*(n+1)}</span><span>💎 ${m.reward_gems??(n<2?1:2)}</span></div></div><div class="mission-actions"><button title="تعديل" data-edit-mission="${n}">✎</button><button title="حذف" class="danger-icon" data-delete-mission="${n}">×</button></div></article>`).join('')||'<div class="empty-inline">لا توجد مهام في هذه الجزيرة.</div>'}</div>`;
    $('#edit-island-btn').onclick=()=>openIslandModal(i);
    $('#delete-island-btn').onclick=()=>deleteIsland(i);
    $('#add-mission-btn').onclick=()=>openMissionModal(null);
    $$('[data-edit-mission]').forEach(b=>b.onclick=()=>openMissionModal(i.missions[Number(b.dataset.editMission)],Number(b.dataset.editMission)));
    $$('[data-delete-mission]').forEach(b=>b.onclick=()=>deleteMission(i,Number(b.dataset.deleteMission)));
}

function openModal(html){$('#modal-root').innerHTML=`<div class="modal-backdrop"><div class="modal-card">${html}</div></div>`;$('.modal-backdrop').addEventListener('click',e=>{if(e.target.classList.contains('modal-backdrop'))closeModal()});$('#modal-close')?.addEventListener('click',closeModal)}
function closeModal(){$('#modal-root').innerHTML=''}

function openIslandModal(island=null){
    const editing=!!island;
    openModal(`<div class="modal-head"><div><span class="eyebrow">${editing?'EDIT ISLAND':'NEW DESTINATION'}</span><h2>${editing?'تعديل الجزيرة':'إضافة جزيرة جديدة'}</h2></div><button id="modal-close" class="modal-x">×</button></div><form id="island-form" class="modal-form"><div class="form-grid"><div><label>معرّف الجزيرة</label><input name="id" required pattern="[a-z0-9_-]+" ${editing?'readonly':''} value="${esc(island?.id||'')}" placeholder="egghead_island"></div><div><label>اسم الجزيرة</label><input name="name" required maxlength="80" value="${esc(island?.name||'')}" placeholder="Egghead"></div><div><label>الإيموجي</label><input name="emoji" maxlength="12" value="${esc(island?.emoji||'🏝️')}"></div><div><label>نقاط فتح الجزيرة</label><input name="min_points" type="number" min="0" value="${island?.min_points??0}"></div></div><label>وصف الجزيرة</label><textarea name="description" rows="3" maxlength="500">${esc(island?.desc||'')}</textarea><label>صورة الجزيرة <small>PNG / JPG / WEBP · حتى 5MB</small></label><input name="image" type="file" accept="image/png,image/jpeg,image/webp"><div class="modal-actions"><button type="button" class="ghost-btn" id="cancel-modal">إلغاء</button><button class="primary-btn" type="submit">${editing?'حفظ التعديلات':'إنشاء الجزيرة'} ←</button></div></form>`);
    $('#cancel-modal').onclick=closeModal;
    $('#island-form').onsubmit=async e=>{
        e.preventDefault();
        const f=new FormData(e.target);
        let image_url=island?.image||'';
        const file=f.get('image');
        try{
            if(file&&file.size){const fd=new FormData();fd.append('file',file);const up=await api('/api/upload',{method:'POST',body:fd});image_url=up.url}
            const data={id:f.get('id').trim(),name:f.get('name').trim(),emoji:f.get('emoji')||'🏝️',description:f.get('description'),min_points:Number(f.get('min_points')||0),image_url,order_index:editing?state.islands.findIndex(x=>x.id===island.id):state.islands.length};
            await api(editing?`/api/islands/${encodeURIComponent(island.id)}`:'/api/islands',{method:editing?'PUT':'POST',body:JSON.stringify(data)});
            closeModal();await loadIslands();state.selectedIsland=data.id;renderIslands();await loadOverview();toast(editing?'تم تحديث الجزيرة':'تم إنشاء الجزيرة بنجاح');
        }catch(err){toast(err.message,'error')}
    };
}

function openMissionModal(mission=null,index=null){
    const i=state.islands.find(x=>x.id===state.selectedIsland);
    const editing=!!mission;
    const characterOptions=Object.entries(state.characters).map(([id,c])=>`<option value="${esc(id)}" ${mission?.character===id?'selected':''}>${esc(c.name)}</option>`).join('');
    const selectedAlternatives=mission?.alternatives||[];
    openModal(`<div class="modal-head"><div><span class="eyebrow">MISSION DESIGN / ${esc(i.name.toUpperCase())}</span><h2>${editing?'تعديل المهمة':'إضافة مهمة'}</h2></div><button id="modal-close" class="modal-x">×</button></div><form id="mission-form" class="modal-form"><label>وصف المهمة</label><textarea name="description" rows="3" required maxlength="1000" placeholder="اكتب شرط إكمال المهمة...">${esc(mission?.desc||'')}</textarea><div class="form-grid"><div><label>الشخصية المطلوبة</label><select name="character_id"><option value="">بدون شخصية محددة</option>${characterOptions}</select></div><div><label>الشخصيات البديلة</label><select name="alternatives" multiple size="4">${Object.entries(state.characters).map(([id,c])=>`<option value="${esc(id)}" ${selectedAlternatives.includes(id)?'selected':''}>${esc(c.name)}</option>`).join('')}</select><small class="field-hint">يمكن تحديد أكثر من بديل باستخدام Ctrl أو الضغط المطوّل.</small></div></div><div class="reward-title">✦ مكافآت المهمة</div><div class="form-grid three"><div><label>النقاط ⭐</label><input name="reward_points" type="number" min="0" value="${mission?.reward_points??100*(index===null?i.missions.length+1:index+1)}"></div><div><label>العملات 🪙</label><input name="reward_coins" type="number" min="0" value="${mission?.reward_coins??500*(index===null?i.missions.length+1:index+1)}"></div><div><label>الجواهر 💎</label><input name="reward_gems" type="number" min="0" value="${mission?.reward_gems??(i.missions.length<2?1:2)}"></div></div><div class="modal-actions"><button type="button" class="ghost-btn" id="cancel-modal">إلغاء</button><button class="primary-btn" type="submit">${editing?'حفظ المهمة':'إضافة المهمة'} ←</button></div></form>`);
    $('#cancel-modal').onclick=closeModal;
    $('#mission-form').onsubmit=async e=>{
        e.preventDefault();
        const f=new FormData(e.target);
        const data={stage:editing?index+1:i.missions.length+1,description:f.get('description').trim(),character_id:f.get('character_id')||null,alternatives:[...e.target.elements.alternatives.selectedOptions].map(x=>x.value),reward_points:Number(f.get('reward_points')),reward_coins:Number(f.get('reward_coins')),reward_gems:Number(f.get('reward_gems')),active:true};
        try{
            await api(editing?`/api/islands/${i.id}/missions/${mission._id||mission.id}`:`/api/islands/${i.id}/missions`,{method:editing?'PUT':'POST',body:JSON.stringify(data)});
            closeModal();await loadIslands();state.selectedIsland=i.id;renderIslands();await loadOverview();toast(editing?'تم تحديث المهمة':'تمت إضافة المهمة');
        }catch(err){toast(err.message,'error')}
    };
}

async function deleteMission(i,index){if(!confirm('هل تريد حذف هذه المهمة؟'))return;const mission=i.missions[index];try{await api(`/api/islands/${i.id}/missions/${mission._id||mission.id}`,{method:'DELETE'});await loadIslands();state.selectedIsland=i.id;renderIslands();await loadOverview();toast('تم حذف المهمة');}catch(e){toast(e.message,'error')}}
async function deleteIsland(i){if(!confirm(`حذف جزيرة ${i.name} وجميع مهامها؟ لا يمكن التراجع عن ذلك.`))return;try{await api(`/api/islands/${i.id}`,{method:'DELETE'});state.selectedIsland=null;await loadIslands();renderIslands();await loadOverview();toast('تم حذف الجزيرة');}catch(e){toast(e.message,'error')}}

async function loadProofs(){try{state.proofs=await api(`/api/proofs?status=${encodeURIComponent(state.proofStatus)}`);$('#proof-nav-count').textContent=state.proofStatus==='pending'?state.proofs.length:$('#proof-nav-count').textContent;$('#proof-all-count').textContent=state.proofs.length;renderProofs();}catch(e){toast(e.message,'error')}}

function renderProofs(){
    const rows=state.proofs.filter(p=>state.proofFilter==='all'||p.type===state.proofFilter);
    $('#proof-list').innerHTML=rows.map(p=>`<article class="proof-card"><div class="proof-image-wrap"><a href="${esc(safeUrl(p.image_url))}" target="_blank" rel="noopener"><img src="${esc(safeUrl(p.image_url))}" alt="إثبات اللاعب" loading="lazy"></a><span class="proof-type ${p.type}">${p.type==='grandline'?'GRAND LINE':p.type==='hunter'?'HUNTERS':p.type==='league'?'LEAGUE':p.type==='streak'?'STREAK':p.type==='competitive'?'RANKED':'BATTLE PASS'}</span></div><div class="proof-info"><div class="proof-player">PIRATE ID #${esc(p.user_id)} · ${p.status==='pending'?'قيد المراجعة':p.status==='approved'?'مقبول':'مرفوض'}</div><h3>${p.type==='grandline'?`جزيرة ${esc(p.context)} · المرحلة ${esc(p.detail)}`:p.type==='hunter'?esc(p.detail):p.type==='league'?'إثبات مباراة Champions League':p.type==='streak'?`تحدي ستريك: ${esc(p.detail)}`:`مهمة Battle Pass: ${esc(p.detail)}`}</h3><p>${esc(p.description||'لم يرفق وصف.')}</p><small>${esc(p.submitted_at||'')}</small>${p.status==='pending'?`<div class="proof-actions"><button class="approve-btn" data-approve="${p.type}:${p.id}">✓ قبول الإثبات</button><button class="reject-btn" data-reject="${p.type}:${p.id}">× رفض</button></div>`:`<div class="proof-history-note">${p.review_note?`ملاحظة المراجعة: ${esc(p.review_note)}`:'تمت مراجعة هذا الإثبات.'}</div>`}</div></article>`).join('')||`<div class="empty-state wide-empty"><div>▣</div><h3>${state.proofStatus==='pending'?'لا توجد إثباتات معلقة':'لا توجد إثباتات ضمن هذه التصفية'}</h3><p>يمكنك تغيير حالة الإثبات أو النظام من خيارات التصفية أعلاه.</p></div>`;
    $$('[data-approve]').forEach(b=>b.onclick=()=>review(b.dataset.approve,'approved'));
    $$('[data-reject]').forEach(b=>b.onclick=()=>{const note=prompt('اكتب سبب رفض الإثبات:');if(note!==null)review(b.dataset.reject,'rejected',note)});
}

async function review(key,decision,note=''){
    const [kind,id]=key.split(':');
    try{
        const result=await api('/api/proofs/review',{method:'POST',body:JSON.stringify({kind,proof_id:Number(id),decision,note})});
        state.proofs=state.proofs.filter(p=>!(p.type===kind&&p.id===Number(id)));
        renderProofs();
        await loadOverview();
        if(decision==='approved'){
            const r=result.reward;
            if(r.mission_progress){const p=r.mission_progress;const reward=p.completed?` — المكافأة: ${r.points} نقطة، ${r.coins} عملة، ${r.gems} جوهرة`:'';toast(`تم القبول — التقدم ${p.current}/${p.required}${reward}`);}
            else if(kind==='league')toast(`تم القبول — +${r.tournament_points||0} نقطة بطولة، +${r.coins} عملة`);
            else toast(`تم القبول — +${r.points} نقطة، +${r.coins} عملة، +${r.gems} جوهرة`);
        } else toast('تم رفض الإثبات');
    }catch(e){toast(e.message,'error')}
}

async function searchPlayers(){
    const q=$('#player-search').value.trim();
    if(!q){toast('اكتب اسم اللاعب أو ID أولاً','error');return}
    try{
        state.players=await api(`/api/users?q=${encodeURIComponent(q)}`);
        $('#player-results').innerHTML=state.players.map(p=>`<button class="player-result" data-player="${p.user_id}"><span class="player-result-avatar">♟</span><span><b>${esc(p.display_name||p.username||'Unknown Pirate')}</b><small>${p.user_id}</small></span><strong>${Number(p.bounty||0).toLocaleString()} ☠</strong></button>`).join('')||'<div class="empty-inline">لم يتم العثور على لاعب.</div>';
        $$('[data-player]').forEach(b=>b.onclick=()=>selectPlayer(Number(b.dataset.player)));
    }catch(e){toast(e.message,'error')}
}

async function loadEconomyHealth(){try{const d=await api('/api/economy/health');const labels={bounty:'Bounty',points:'Points',coins:'Coins',gems:'Gems'};$('#economy-health').innerHTML=Object.entries(labels).map(([key,label])=>`<article class="panel economy-health-card"><small>${label} SUPPLY</small><b>${Number(d.supply[key]||0).toLocaleString('en-US')}</b><span>7-day net: ${Number(d.last_7_days[key]?.net_delta||0).toLocaleString('en-US')} · ${Number(d.last_7_days[key]?.transactions||0)} transactions</span></article>`).join('')+`<article class="panel economy-health-card"><small>REGISTERED WALLETS</small><b>${Number(d.supply.players||0).toLocaleString('en-US')}</b><span>SQLite ledger overview</span></article>`}catch(e){$('#economy-health').innerHTML=`<div class="empty-inline">${esc(e.message)}</div>`}}

async function loadShopOrders(){
    const host=$('#shop-orders-list');
    if(!host)return;
    host.innerHTML='<div class="empty-inline">جارٍ تحميل طلبات المتجر...</div>';
    try{
        const rows=await api('/api/economy/orders?status=pending');
        host.innerHTML=rows.map(order=>`<div class="shop-order-row"><div class="shop-order-info"><b>#${Number(order.id)} · ${esc(order.item_name)}</b><small>${esc(order.username||'عضو غير معروف')} · ID ${Number(order.user_id)}</small><small>${Number(order.cost).toLocaleString('en-US')} ${order.currency==='coins'?'عملة':'جوهرة'} · ${esc(order.created_at||'')}</small></div><button type="button" class="secondary-btn fulfill-order-btn" data-fulfill-order="${Number(order.id)}">تأكيد التسليم</button></div>`).join('')||'<div class="empty-inline">لا توجد طلبات تنتظر التسليم.</div>';
        $$('[data-fulfill-order]').forEach(button=>button.addEventListener('click',async()=>{
            const id=Number(button.dataset.fulfillOrder);
            if(!Number.isSafeInteger(id)||id<=0)return;
            if(!confirm(`تأكيد تسليم طلب #${id}؟ تأكد من تسليم العنصر للعضو أولاً.`))return;
            button.disabled=true;
            try{await api(`/api/economy/orders/${id}/fulfill`,{method:'POST',body:JSON.stringify({})});toast(`تم إغلاق الطلب #${id}`);await loadShopOrders();}
            catch(error){button.disabled=false;toast(error.message,'error');}
        }));
    }catch(error){host.innerHTML=`<div class="empty-inline">${esc(error.message)}</div>`;}
}

async function loadEconomyHistory(userId){
    const host=$('#economy-history');
    if(!host)return;
    host.innerHTML='<div class="empty-inline">جارٍ تحميل سجل المعاملات...</div>';
    try{
        const rows=await api(`/api/economy/history/${encodeURIComponent(userId)}?limit=30`);
        const labels={bounty:'Bounty',points:'نقاط الترتيب',coins:'عملات',gems:'جواهر'};
        host.innerHTML=rows.map(row=>`<div class="economy-history-row"><div class="economy-history-main"><b>${esc(labels[row.currency]||row.currency)}</b><small>${esc(row.reason||'معاملة')}</small><time>${esc(row.created_at||'')}</time></div><strong class="${Number(row.delta)>0?'credit':'debit'}">${Number(row.delta)>0?'+':''}${Number(row.delta).toLocaleString('en-US')}</strong><span class="economy-balance-after">الرصيد: ${Number(row.balance_after).toLocaleString('en-US')}</span></div>`).join('')||'<div class="empty-inline">لا توجد معاملات مسجلة لهذا اللاعب بعد.</div>';
    }catch(error){host.innerHTML=`<div class="empty-inline">${esc(error.message)}</div>`;}
}

function selectPlayer(id){
    const p=state.players.find(x=>x.user_id===id);if(!p)return;
    state.selectedPlayer=p;
    $('#selected-player').innerHTML=`<div class="player-avatar-large">♟</div><div><b>${esc(p.display_name||p.username||'Unknown Pirate')}</b><small>DISCORD ID: ${p.user_id}</small><div class="wallet-preview"><span>☠ ${Number(p.bounty||0).toLocaleString()} Bounty</span><span>⭐ ${Number(p.points).toLocaleString()} نقاط</span><span>🪙 ${Number(p.coins).toLocaleString()}</span><span>💎 ${Number(p.gems).toLocaleString()}</span></div></div>`;
    $('#economy-submit').disabled=false;
    loadEconomyHistory(p.user_id);
    $$('[data-player]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.player)===id));
}

$('#economy-form').onsubmit=async e=>{
    e.preventDefault();
    if(!state.selectedPlayer)return;
    const enteredAmount=Number($('#economy-amount').value);
    if(!Number.isSafeInteger(enteredAmount)||enteredAmount<=0||enteredAmount>10000000){toast('أدخل مبلغاً صحيحاً أكبر من صفر','error');return}
    const operation=$('input[name="economy-operation"]:checked').value;
    const amount=operation==='subtract'?-enteredAmount:enteredAmount;
    const currency=$('input[name="currency"]:checked').value;
    const currencyNames={bounty:'Bounty',points:'نقاط الترتيب',coins:'العملات',gems:'الجواهر'};
    const actionName=operation==='subtract'?'خصم':'إضافة';
    const currentBalance=Number(state.selectedPlayer[currency]||0);
    if(operation==='subtract'&&enteredAmount>currentBalance){
        toast(`لا يمكن خصم ${enteredAmount.toLocaleString('en-US')}؛ الرصيد الحالي ${currentBalance.toLocaleString('en-US')} فقط`,'error');
        return;
    }
    if(!confirm(`تأكيد ${actionName} ${enteredAmount.toLocaleString('en-US')} من ${currencyNames[currency]} للاعب ${state.selectedPlayer.username||state.selectedPlayer.user_id}؟`))return;
    try{
        const p=await api('/api/economy/adjust',{method:'POST',body:JSON.stringify({user_id:state.selectedPlayer.user_id,currency,amount})});
        state.players=state.players.map(x=>x.user_id===p.user_id?p:x);
        selectPlayer(p.user_id);
        await loadEconomyHistory(p.user_id);
        $('#economy-amount').value='';
        updateEconomyOperationUI();
        toast(`تم ${actionName} ${enteredAmount.toLocaleString('en-US')} من ${currencyNames[currency]} بنجاح`);
    }catch(err){toast(err.message,'error')}
};


function updateEconomyOperationUI(){
    const operation=$('input[name="economy-operation"]:checked')?.value||'add';
    const amount=Number($('#economy-amount')?.value||0);
    const currency=$('input[name="currency"]:checked')?.value||'bounty';
    const currencyNames={bounty:'Bounty',points:'نقطة',coins:'عملة',gems:'جوهرة'};
    const preview=$('#economy-operation-preview');
    const submit=$('#economy-submit');
    if(preview){
        preview.textContent=operation==='subtract'
            ? `سيتم خصم ${amount>0?amount.toLocaleString('en-US'):'…'} ${currencyNames[currency]} من رصيد اللاعب.`
            : `سيتم إضافة ${amount>0?amount.toLocaleString('en-US'):'…'} ${currencyNames[currency]} إلى رصيد اللاعب.`;
        preview.classList.toggle('is-debit',operation==='subtract');
    }
    if(submit){
        submit.innerHTML=operation==='subtract'
            ? '<i class="fa-solid fa-minus"></i> تأكيد خصم الرصيد'
            : '<i class="fa-solid fa-plus"></i> تأكيد إضافة الرصيد';
        submit.classList.toggle('danger-action',operation==='subtract');
    }
}
$$('input[name="economy-operation"], input[name="currency"]').forEach(input=>input.addEventListener('change',updateEconomyOperationUI));
$('#economy-amount')?.addEventListener('input',updateEconomyOperationUI);
updateEconomyOperationUI();

async function loadSettings(){
    try{
        const s=await api('/api/settings');
        $('#log-channel').value=s.log_channel_id||'';
        $('#bot-status').value=s.bot_status;
        $('#status-text').value=s.status_text;
        $('#settings-state').textContent='الإعدادات الحالية محمّلة.';
    }catch(e){toast(e.message,'error')}
}

$('#save-settings').onclick=async()=>{
    const log=$('#log-channel').value.trim();
    const data={log_channel_id:log?Number(log):null,bot_status:$('#bot-status').value,status_text:$('#status-text').value.trim()};
    try{
        await api('/api/settings',{method:'PUT',body:JSON.stringify(data)});
        $('#settings-state').textContent='تم حفظ الإعدادات بنجاح.';
        toast('تم تحديث إعدادات REQUIEM');
    }catch(e){toast(e.message,'error')}
};

// ================== Battle Pass ==================
async function loadBP() {
    try {
        const tiers = await api('/api/bp');
        $('#bp-list').innerHTML = tiers.map(t => `
            <article class="bp-tier-card" data-bp-card="${Number(t.id)}">
                <div class="bp-tier-top"><span class="bp-tier-number">TIER ${Number(t.tier)}</span>
                    <div class="bp-tier-actions"><button type="button" data-edit-bp="${Number(t.id)}" title="تعديل المستوى" aria-label="تعديل المستوى"><i class="fa-solid fa-pen"></i></button><button type="button" data-delete-bp="${Number(t.id)}" title="حذف المستوى" aria-label="حذف المستوى"><i class="fa-solid fa-trash"></i></button></div>
                </div>
                <h3>${esc(t.label)}</h3>
                <div class="bp-tier-requirement">النقاط المطلوبة: <b>${Number(t.required_points).toLocaleString('en-US')}</b></div>
                <div class="bp-tier-rewards"><span><i class="fa-solid fa-coins"></i>${Number(t.reward_coins).toLocaleString('en-US')}</span><span><i class="fa-solid fa-gem"></i>${Number(t.reward_gems).toLocaleString('en-US')}</span></div>
            </article>
        `).join('') || '<div class="empty-inline wide-empty">لا توجد مستويات في Battle Pass حالياً.</div>';
        $$('[data-edit-bp]').forEach(button => button.addEventListener('click', () => {
            const tier = tiers.find(item => Number(item.id) === Number(button.dataset.editBp));
            if (tier) openBPModal(tier);
        }));
        $$('[data-delete-bp]').forEach(button => button.addEventListener('click', () => deleteBP(Number(button.dataset.deleteBp))));
        await loadBPSeasons();
    } catch (e) { toast(e.message, 'error'); }
}

async function loadBPSeasons() {
    const seasons = await api('/api/battlepass/seasons');
    const select = $('#bp-season-select');
    const previous = select.value;
    select.innerHTML = seasons.map(s => `<option value="${Number(s.id)}">${esc(s.name)}${s.active ? ' — نشط' : ''}</option>`).join('') || '<option value="">لا توجد مواسم بعد</option>';
    if (seasons.some(s => String(s.id) === previous)) select.value = previous;
    else if (seasons.length) select.value = String((seasons.find(s => s.active) || seasons[0]).id);
    await loadBPMissions();
}

async function loadBPMissions() {
    const seasonId = Number($('#bp-season-select').value || 0);
    if (!seasonId) { $('#bp-mission-list').innerHTML = '<div class="empty-inline wide-empty">أنشئ موسماً أولاً ثم أضف مهامه.</div>'; return; }
    const missions = await api(`/api/battlepass/missions?season_id=${seasonId}`);
    $('#bp-season-status').textContent = `${missions.length} مهمة مسجلة في هذا الموسم`;
    $('#bp-mission-list').innerHTML = missions.map(m => `<article class="bp-tier-card"><div class="bp-tier-top"><span class="bp-tier-number">MISSION #${Number(m.id)}</span><div class="bp-tier-actions"><button type="button" data-edit-bp-mission="${Number(m.id)}" title="تعديل المهمة"><i class="fa-solid fa-pen"></i></button><button type="button" data-delete-bp-mission="${Number(m.id)}" title="إيقاف المهمة"><i class="fa-solid fa-ban"></i></button></div></div><h3>${esc(m.title)}</h3><p>${esc(m.description)}</p><div class="bp-tier-requirement">الإثباتات المطلوبة: <b>${Number(m.required_count)}</b></div><div class="bp-tier-rewards"><span>⭐ ${Number(m.reward_points)}</span><span>🪙 ${Number(m.reward_coins)}</span><span>💎 ${Number(m.reward_gems)}</span></div></article>`).join('') || '<div class="empty-inline wide-empty">لا توجد مهام لهذا الموسم.</div>';
    $$('[data-edit-bp-mission]').forEach(b => b.onclick = () => { const mission=missions.find(m=>Number(m.id)===Number(b.dataset.editBpMission)); if(mission)openBPMissionModal(mission); });
    $$('[data-delete-bp-mission]').forEach(b => b.onclick = () => deleteBPMission(Number(b.dataset.deleteBpMission)));
}

async function deleteBPMission(id) {
    if(!confirm('إيقاف هذه المهمة؟ ستبقى سجلاتها وإثباتاتها محفوظة.'))return;
    try{await api(`/api/battlepass/missions/${id}`,{method:'DELETE'});await loadBPMissions();toast('تم إيقاف المهمة');}catch(e){toast(e.message,'error')}
}

function openBPSeasonModal() {
    openModal(`<div class="modal-head"><div><span class="eyebrow">NEW SEASON</span><h2>إنشاء موسم Battle Pass</h2></div><button id="modal-close" class="modal-x" type="button">×</button></div><form id="bp-season-form" class="modal-form"><label>اسم الموسم</label><input name="name" maxlength="100" required placeholder="Season 2: New Era"><label>الوصف</label><textarea name="description" maxlength="1000" placeholder="وصف الموسم"></textarea><div class="form-grid"><div><label>بداية الموسم (اختياري)</label><input name="starts_at" type="datetime-local"></div><div><label>نهاية الموسم (اختياري)</label><input name="ends_at" type="datetime-local"></div></div><label class="check-row"><input name="active" type="checkbox" checked> تفعيل هذا الموسم</label><div class="modal-actions"><button type="button" class="secondary-btn" id="cancel-modal">إلغاء</button><button class="primary-btn" type="submit">حفظ الموسم</button></div></form>`);
    $('#cancel-modal').onclick=closeModal;
    $('#bp-season-form').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const data={name:String(f.get('name')||'').trim(),description:String(f.get('description')||''),starts_at:f.get('starts_at')||null,ends_at:f.get('ends_at')||null,active:f.get('active')==='on'};try{await api('/api/battlepass/seasons',{method:'POST',body:JSON.stringify(data)});closeModal();await loadBPSeasons();toast('تم إنشاء الموسم');}catch(err){toast(err.message,'error')}};
}

async function openBPMissionModal(mission = null) {
    const seasons=await api('/api/battlepass/seasons'); if(!seasons.length)return toast('أنشئ موسماً أولاً','error');
    const active=seasons.find(s=>s.active)||seasons[0];
    const selectedSeason=mission?.season_id ?? active.id;
    openModal(`<div class="modal-head"><div><span class="eyebrow">${mission?'EDIT':'NEW'} SEASONAL OBJECTIVE</span><h2>${mission?'تعديل المهمة الموسمية':'إضافة مهمة موسمية'}</h2></div><button id="modal-close" class="modal-x" type="button">×</button></div><form id="bp-mission-form" class="modal-form"><label>الموسم</label><select name="season_id">${seasons.map(s=>`<option value="${Number(s.id)}" ${Number(s.id)===Number(selectedSeason)?'selected':''}>${esc(s.name)}</option>`).join('')}</select><label>عنوان المهمة</label><input name="title" maxlength="100" required placeholder="انتصارات القراصنة" value="${esc(mission?.title??'')}"><label>وصف المهمة</label><textarea name="description" maxlength="1000" required placeholder="ارفع إثباتاً واضحاً لإكمال المطلوب">${esc(mission?.description??'')}</textarea><div class="form-grid"><div><label>عدد الإثباتات المطلوبة</label><input name="required_count" type="number" min="1" max="100" value="${Number(mission?.required_count??1)}" required></div><div><label>نقاط</label><input name="reward_points" type="number" min="0" value="${Number(mission?.reward_points??0)}"></div><div><label>عملات</label><input name="reward_coins" type="number" min="0" value="${Number(mission?.reward_coins??0)}"></div><div><label>جواهر</label><input name="reward_gems" type="number" min="0" value="${Number(mission?.reward_gems??0)}"></div></div><label class="check-row"><input name="active" type="checkbox" ${Number(mission?.active??1)===1?'checked':''}> مهمة نشطة</label><div class="modal-actions"><button type="button" class="secondary-btn" id="cancel-modal">إلغاء</button><button class="primary-btn" type="submit">حفظ المهمة</button></div></form>`);
    $('#cancel-modal').onclick=closeModal;
    $('#bp-mission-form').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const data={season_id:Number(f.get('season_id')),title:String(f.get('title')||'').trim(),description:String(f.get('description')||'').trim(),required_count:Number(f.get('required_count')),reward_points:Number(f.get('reward_points')),reward_coins:Number(f.get('reward_coins')),reward_gems:Number(f.get('reward_gems')),active:f.get('active')==='on'};try{await api(mission?`/api/battlepass/missions/${mission.id}`:'/api/battlepass/missions',{method:mission?'PUT':'POST',body:JSON.stringify(data)});closeModal();await loadBPMissions();toast(mission?'تم تحديث المهمة':'تمت إضافة المهمة');}catch(err){toast(err.message,'error')}};
}

function openBPModal(tier = null) {
    const isEdit = !!tier;
    openModal(`
        <div class="modal-head"><div><span class="eyebrow">${isEdit ? 'EDIT TIER' : 'NEW TIER'}</span><h2>${isEdit ? 'تعديل المستوى' : 'إضافة مستوى جديد'}</h2></div><button id="modal-close" class="modal-x" type="button" aria-label="إغلاق">×</button></div>
        <form id="bp-form" class="modal-form">
            <div class="form-grid three">
                <div><label>رقم المستوى (Tier)</label><input name="tier" type="number" min="1" required value="${tier?.tier ?? ''}" placeholder="1"></div>
                <div><label>النقاط المطلوبة</label><input name="required_points" type="number" min="0" required value="${tier?.required_points ?? ''}" placeholder="300"></div>
                <div><label>اسم المكافأة</label><input name="label" maxlength="100" required value="${esc(tier?.label ?? '')}" placeholder="لقب Supernova"></div>
            </div>
            <div class="form-grid"><div><label>مكافأة العملات 🪙</label><input name="reward_coins" type="number" min="0" required value="${tier?.reward_coins ?? 0}" placeholder="100"></div><div><label>مكافأة الجواهر 💎</label><input name="reward_gems" type="number" min="0" required value="${tier?.reward_gems ?? 0}" placeholder="1"></div></div>
            <div class="modal-actions"><button type="button" class="secondary-btn" id="cancel-modal">إلغاء</button><button class="primary-btn" type="submit"><i class="fa-solid fa-floppy-disk"></i> حفظ المستوى</button></div>
        </form>
    `);
    $('#cancel-modal').onclick = closeModal;
    $('#bp-form').onsubmit = async e => {
        e.preventDefault();
        const f = new FormData(e.target);
        const data = {tier:Number(f.get('tier')),required_points:Number(f.get('required_points')),reward_coins:Number(f.get('reward_coins')),reward_gems:Number(f.get('reward_gems')),label:String(f.get('label')||'').trim()};
        if (!Number.isInteger(data.tier) || data.tier < 1 || data.required_points < 0 || data.reward_coins < 0 || data.reward_gems < 0 || !data.label) return toast('تحقق من بيانات المستوى والمكافآت', 'error');
        try {
            await api(isEdit ? `/api/bp/${tier.id}` : '/api/bp', {method:isEdit?'PUT':'POST',body:JSON.stringify(data)});
            closeModal(); await loadBP(); toast('تم حفظ مستوى Battle Pass');
        } catch (err) { toast(err.message, 'error'); }
    };
}

async function deleteBP(id) {
    if (!confirm('هل تريد حذف هذا المستوى؟')) return;
    try { await api(`/api/bp/${id}`, {method:'DELETE'}); await loadBP(); toast('تم حذف المستوى'); }
    catch (e) { toast(e.message, 'error'); }
}

// ================== ProBot-style custom shortcuts ==================
async function loadShortcutCommands() {
    const select = $('#sc-command-select');
    try {
        state.shortcutCommands = await api('/api/shortcuts/commands');
        select.innerHTML = '<option value="">اختر أمراً من أوامر البوت...</option>' + state.shortcutCommands.map(command =>
            `<option value="${esc(command.name)}">/${esc(command.name)}${command.description ? ` — ${esc(command.description)}` : ''}</option>`
        ).join('');
        select.disabled = state.shortcutCommands.length === 0;
        if (!state.shortcutCommands.length) select.innerHTML = '<option value="">لا توجد أوامر متاحة حالياً</option>';
    } catch (e) {
        select.innerHTML = '<option value="">تعذر تحميل قائمة الأوامر</option>';
        select.disabled = true;
    }
}

function updateShortcutPreview() {
    const trigger = $('#sc-trigger').value.trim() || 'shortcut';
    const type = $('#sc-type').value;
    const value = type === 'command' ? ($('#sc-command-select').selectedOptions[0]?.textContent || '/command') : ($('#sc-data').value.trim() || 'سيظهر مثال الرد هنا بعد كتابة المحتوى.');
    $('#shortcut-preview-text').textContent = type === 'command' ? `الأمر المرتبط: ${value}` : value;
    $('.trigger-prefix').textContent = trigger.startsWith('!') ? '' : '!';
}

function syncShortcutEditor() {
    const isCommand = $('#sc-type').value === 'command';
    $('#sc-data').classList.toggle('hidden', isCommand);
    $('#sc-command-select').classList.toggle('hidden', !isCommand);
    $('#sc-data').required = !isCommand;
    $('#sc-command-select').required = isCommand;
    $('#sc-data-label').innerHTML = isCommand ? 'الأمر المرتبط <span>*</span>' : 'نص الرسالة <span>*</span>';
    $('#sc-data-help').textContent = isCommand ? 'اختر أمراً موجوداً فعلياً في شجرة أوامر Discord الخاصة بالبوت.' : 'اكتب الرد الذي سيرسله البوت عند مطابقة الاختصار.';
    $('#shortcut-command-hint').classList.toggle('hidden', !isCommand);
    if (isCommand && $('#sc-command-select').value) $('#sc-data').value = $('#sc-command-select').value;
    updateShortcutPreview();
}

async function loadShortcuts() {
    try {
        const shortcuts = await api('/api/shortcuts');
        $('#shortcuts-list').innerHTML = shortcuts.map((s, index) => `
            <article class="shortcut-card">
                <span class="shortcut-card-icon"><i class="fa-solid ${s.action_type === 'command' ? 'fa-terminal' : 'fa-comment-dots'}"></i></span>
                <div class="shortcut-card-main"><div class="shortcut-card-top"><b class="shortcut-trigger">${esc(s.trigger_text)}</b><span class="shortcut-kind">${s.action_type === 'command' ? 'أمر Discord' : 'رد نصي'}</span></div><p>${esc(s.action_type === 'command' ? `/${s.action_data}` : s.action_data)}</p></div>
                <div class="shortcut-card-actions"><button type="button" data-edit-shortcut="${index}" title="تعديل" aria-label="تعديل الاختصار"><i class="fa-solid fa-pen"></i></button><button type="button" class="delete-shortcut" data-delete-shortcut="${index}" title="حذف" aria-label="حذف الاختصار"><i class="fa-solid fa-trash"></i></button></div>
            </article>
        `).join('') || '<div class="empty-inline">لا توجد اختصارات محفوظة. أنشئ أول اختصار من النموذج أعلاه.</div>';
        $$('[data-edit-shortcut]').forEach(button => button.addEventListener('click', () => beginShortcutEdit(shortcuts[Number(button.dataset.editShortcut)])));
        $$('[data-delete-shortcut]').forEach(button => button.addEventListener('click', () => deleteShortcut(shortcuts[Number(button.dataset.deleteShortcut)].trigger_text)));
    } catch (e) { toast(e.message, 'error'); }
}

function beginShortcutEdit(shortcut) {
    if (!shortcut) return;
    state.editingShortcut = shortcut.trigger_text;
    $('#sc-trigger').value = shortcut.trigger_text;
    $('#sc-type').value = shortcut.action_type;
    $('#sc-data').value = shortcut.action_data;
    syncShortcutEditor();
    if (shortcut.action_type === 'command') $('#sc-command-select').value = shortcut.action_data;
    $('#shortcut-submit').innerHTML = '<i class="fa-solid fa-floppy-disk"></i> حفظ التعديلات';
    $('#shortcut-cancel-edit').classList.remove('hidden');
    updateShortcutPreview();
    $('#sc-trigger').focus();
    $('#page-shortcuts').scrollIntoView({behavior:'smooth',block:'start'});
}

function resetShortcutForm() {
    state.editingShortcut = null;
    $('#shortcut-form').reset();
    $('#sc-data').value = '';
    $('#shortcut-submit').innerHTML = '<i class="fa-solid fa-plus"></i> حفظ الاختصار';
    $('#shortcut-cancel-edit').classList.add('hidden');
    syncShortcutEditor();
}

$('#shortcut-form').onsubmit = async e => {
    e.preventDefault();
    const actionType = $('#sc-type').value;
    const trigger = $('#sc-trigger').value.trim().toLowerCase();
    const actionData = actionType === 'command' ? $('#sc-command-select').value : $('#sc-data').value.trim();
    if (!trigger || /\s/.test(trigger)) return toast('اسم الاختصار يجب أن يكون كلمة واحدة دون مسافات', 'error');
    if (!actionData) return toast(actionType === 'command' ? 'اختر أمراً من القائمة' : 'اكتب نص الرد أولاً', 'error');
    const data = {trigger_text:trigger,action_type:actionType,action_data:actionData};
    const wasEditing = Boolean(state.editingShortcut);
    try {
        if (wasEditing) await api(`/api/shortcuts/${encodeURIComponent(state.editingShortcut)}`, {method:'PUT',body:JSON.stringify(data)});
        else await api('/api/shortcuts', {method:'POST',body:JSON.stringify(data)});
        resetShortcutForm(); await loadShortcuts(); toast(wasEditing ? 'تم تحديث الاختصار' : 'تم إنشاء الاختصار');
    } catch (err) { toast(err.message, 'error'); }
};

async function deleteShortcut(trigger) {
    if (!confirm(`حذف الاختصار "${trigger}"؟`)) return;
    try { await api(`/api/shortcuts/${encodeURIComponent(trigger)}`, {method:'DELETE'}); if (state.editingShortcut === trigger) resetShortcutForm(); await loadShortcuts(); toast('تم حذف الاختصار'); }
    catch (e) { toast(e.message, 'error'); }
}

$('#sc-type').addEventListener('change', syncShortcutEditor);
$('#sc-trigger').addEventListener('input', updateShortcutPreview);
$('#sc-data').addEventListener('input', updateShortcutPreview);
$('#sc-command-select').addEventListener('change', () => { $('#sc-data').value = $('#sc-command-select').value; updateShortcutPreview(); });
$('#shortcut-cancel-edit').addEventListener('click', resetShortcutForm);

// ================== Competitive / Wanted / Market ==================
function renderRankings(target, rows, mode='elo'){
    const node=$(target); if(!node)return;
    node.innerHTML=(rows||[]).map((r,i)=>`<div class="ranking-row"><span class="ranking-place">${String(i+1).padStart(2,'0')}</span><span class="ranking-player"><b>${esc(r.username||`Player #${r.user_id}`)}</b><small>#${esc(r.user_id)} · ${mode==='bounty'?'Bounty':'Wins '+Number(r.wins||0)}</small></span><strong>${Number(mode==='bounty'?r.bounty:r.rating||r.wins||0).toLocaleString('en-US')}</strong></div>`).join('')||'<div class="empty-inline">لا توجد بيانات كافية بعد.</div>';
}
async function loadCompetitive(){
    try{
        const [general,tournament,seasons]=await Promise.all([api('/api/competitive/leaderboard?mode=general&limit=10'),api('/api/competitive/leaderboard?mode=tournament&limit=10'),api('/api/competitive/seasons')]);
        renderRankings('#general-leaderboard',general);renderRankings('#tournament-leaderboard',tournament);
        $('#general-leader-count').textContent=general[0]?.rating??'—';$('#tournament-leader-count').textContent=tournament[0]?.rating??'—';
        $('#competitive-seasons').innerHTML=seasons.map(x=>`<div class="season-row"><span><b>${esc(x.name)}</b><small>${esc(x.starts_at)} — ${esc(x.ends_at)}</small></span><span class="season-state">${esc(x.status)}</span><span class="season-actions">${x.status!=='archived'?`<button class="small-primary" data-season-activate="${x.id}">تفعيل</button><button class="danger-icon" data-season-archive="${x.id}" title="أرشفة">أرشفة</button>`:''}</span></div>`).join('')||'<div class="empty-inline">لا توجد مواسم تنافسية بعد.</div>';
        $$('[data-season-activate]').forEach(b=>b.onclick=async()=>{try{await api(`/api/competitive/seasons/${b.dataset.seasonActivate}/activate`,{method:'POST',body:'{}'});await loadCompetitive();toast('تم تفعيل الموسم')}catch(e){toast(e.message,'error')}});
        $$('[data-season-archive]').forEach(b=>b.onclick=async()=>{if(!confirm('أرشفة الموسم وحفظ ترتيب اللاعبين؟'))return;try{await api(`/api/competitive/seasons/${b.dataset.seasonArchive}/archive`,{method:'POST',body:'{}'});await loadCompetitive();toast('تم أرشفة الموسم')}catch(e){toast(e.message,'error')}});
    }catch(e){toast(e.message,'error')}
}
async function loadWanted(){
    try{const d=await api('/api/competitive/wanted');renderRankings('#wanted-bounty',d.bounty,'bounty');renderRankings('#wanted-weekly',d.weekly,'wins');renderRankings('#wanted-monthly',d.monthly,'wins');renderRankings('#wanted-general',d.general_elo);renderRankings('#wanted-tournament',d.tournament_elo)}catch(e){toast(e.message,'error')}
}
async function loadMarket(){
    try{
        const [catalog,inventory]=await Promise.all([api('/api/competitive/catalog'),api(`/api/competitive/inventory/${encodeURIComponent(state.userId||'0')}`).catch(()=>[])]);
        $('#market-catalog').innerHTML=catalog.map(item=>`<article class="market-item"><span class="market-rarity">${esc(item.rarity)}</span><b>${esc(item.name)}</b><small>${esc(item.category)}</small><strong>${Number(item.price).toLocaleString('en-US')} ${esc(item.currency)}</strong><button class="small-primary" data-buy-item="${esc(item.item_id)}">اقتناء</button></article>`).join('')||'<div class="empty-inline">السوق فارغ حالياً.</div>';
        $('#player-inventory').innerHTML=inventory.map(item=>`<div class="inventory-item"><span><b>${esc(item.name)}</b><small>${esc(item.category)} · ${esc(item.rarity)}</small></span>${item.equipped?'<span class="data-live">مجهز</span>':`<button class="small-primary" data-equip-item="${esc(item.item_id)}">تجهيز</button>`}</div>`).join('')||'<div class="empty-inline">لا توجد مقتنيات في هذا الحساب.</div>';
        $$('[data-buy-item]').forEach(b=>b.onclick=async()=>{if(!confirm('تأكيد اقتناء هذا العنصر؟'))return;try{const key=`web-buy:${state.userId}:${b.dataset.buyItem}:${Date.now()}`;await api('/api/competitive/purchase',{method:'POST',body:JSON.stringify({item_id:b.dataset.buyItem,idempotency_key:key})});toast('تمت إضافة العنصر إلى مقتنياتك');await loadMarket()}catch(e){toast(e.message,'error')}});
        $$('[data-equip-item]').forEach(b=>b.onclick=async()=>{try{await api('/api/competitive/equip',{method:'POST',body:JSON.stringify({item_id:b.dataset.equipItem})});await loadMarket();toast('تم تجهيز العنصر')}catch(e){toast(e.message,'error')}});
    }catch(e){toast(e.message,'error')}
}
$('#competitive-refresh')?.addEventListener('click',loadCompetitive);
$('#wanted-refresh')?.addEventListener('click',loadWanted);
$('#market-refresh')?.addEventListener('click',loadMarket);
$('#market-item-form')?.addEventListener('submit',async e=>{e.preventDefault();const data={item_id:$('#market-item-id').value.trim(),name:$('#market-item-name').value.trim(),category:$('#market-item-category').value.trim(),currency:$('#market-item-currency').value,price:Number($('#market-item-price').value),rarity:$('#market-item-rarity').value,rotation:$('#market-item-rotation').value};try{await api('/api/competitive/catalog',{method:'POST',body:JSON.stringify(data)});e.target.reset();await loadMarket();toast('تم حفظ العنصر في السوق')}catch(err){toast(err.message,'error')}});
$('#competitive-season-form')?.addEventListener('submit',async e=>{e.preventDefault();const data={name:$('#competitive-season-name').value.trim(),starts_at:$('#competitive-season-start').value,ends_at:$('#competitive-season-end').value};try{await api('/api/competitive/seasons',{method:'POST',body:JSON.stringify(data)});e.target.reset();await loadCompetitive();toast('تم إنشاء الموسم')}catch(err){toast(err.message,'error')}});

async function loadAchievements(){
    try{
        const rows=await api('/api/achievements');
        $('#achievements-list').innerHTML=rows.map(a=>`<article class="achievement-card"><span class="achievement-category">${esc(a.category)}</span><h3>${esc(a.title)}</h3><p>${esc(a.description||'')}</p><div class="achievement-progress"><span>التقدم</span><b>${Number(a.progress||0)} / ${Number(a.target)}</b></div><div class="achievement-track"><i style="width:${Math.min(100,100*Number(a.progress||0)/Math.max(1,Number(a.target)))}%"></i></div><div class="achievement-rewards">⭐ ${Number(a.reward_points).toLocaleString()} · 🪙 ${Number(a.reward_coins).toLocaleString()} · 💎 ${Number(a.reward_gems).toLocaleString()} · ☠ ${Number(a.reward_bounty).toLocaleString()}</div>${a.unlocked_at?(a.claimed_at?'<span class="data-live">تم استلام المكافأة</span>':`<button class="small-primary" data-claim-ach="${esc(a.achievement_id)}" data-period="${esc(a.period_key)}">استلام المكافأة</button>`):'<span class="muted">قيد التقدم</span>'}</article>`).join('')||'<div class="empty-inline">لا توجد إنجازات منشورة حالياً.</div>';
        $$('[data-claim-ach]').forEach(b=>b.onclick=async()=>{try{await api(`/api/achievements/${encodeURIComponent(b.dataset.claimAch)}/claim`,{method:'POST',body:JSON.stringify({period_key:b.dataset.period})});await loadAchievements();toast('تم استلام مكافأة الإنجاز')}catch(e){toast(e.message,'error')}});
    }catch(e){toast(e.message,'error')}
}
$('#achievements-refresh')?.addEventListener('click',loadAchievements);
$('#achievement-form')?.addEventListener('submit',async e=>{e.preventDefault();const data={achievement_id:$('#ach-id').value.trim(),title:$('#ach-title').value.trim(),description:'',category:$('#ach-category').value,trigger_key:$('#ach-trigger').value,target:Number($('#ach-target').value),reward_points:Number($('#ach-reward').value||0),reward_coins:0,reward_gems:0,reward_bounty:0,title_reward:'',badge_reward:'',hidden:false,active:true};try{await api('/api/achievements',{method:'POST',body:JSON.stringify(data)});e.target.reset();await loadAchievements();toast('تم إنشاء الإنجاز')}catch(err){toast(err.message,'error')}});

async function loadTournaments(){try{const rows=await api('/api/tournaments');$('#tournament-list').innerHTML=rows.map(t=>`<div class="season-row"><span><b>${esc(t.name)}</b><small>#${t.id} · ${t.player_count}/${t.size} لاعب · ${esc(t.created_at||'')}</small></span><span class="season-state">${esc(t.status)}</span><span class="season-actions">${t.status==='registration'&&Number(t.player_count)===Number(t.size)?`<button class="small-primary" data-start-tournament="${t.id}">بدء البطولة</button>`:''}<button class="outline-btn" data-show-tournament="${t.id}">المباريات</button></span></div>`).join('')||'<div class="empty-inline">لا توجد بطولات حالياً.</div>';$$('[data-start-tournament]').forEach(b=>b.onclick=async()=>{if(!confirm('بدء البطولة وإنشاء الجولة الأولى؟'))return;try{const r=await api(`/api/tournaments/${b.dataset.startTournament}/start`,{method:'POST',body:'{}'});toast(`تم إنشاء ${r.matches.length} مباراة`);loadTournaments()}catch(e){toast(e.message,'error')}});$$('[data-show-tournament]').forEach(b=>b.onclick=async()=>{try{const m=await api(`/api/tournaments/${b.dataset.showTournament}/matches`);alert(m.map(x=>`Round ${x.round_number} · Match ${x.match_number}: ${x.player1_id} vs ${x.player2_id} — ${x.status}${x.winner_id?` · Winner ${x.winner_id}`:''}`).join('\n')||'لا توجد مباريات بعد')}catch(e){toast(e.message,'error')}})}catch(e){toast(e.message,'error')}}
async function loadChallenges(){try{const rows=await api('/api/challenges');$('#challenge-list').innerHTML=rows.map(c=>`<div class="season-row"><span><b>Challenge #${c.id}</b><small>#${c.challenger_id} vs #${c.opponent_id} · ${esc(c.created_at||'')}</small></span><span class="season-state">${esc(c.status)}</span><span class="season-actions">${c.winner_id?`الفائز #${c.winner_id}`:''}</span></div>`).join('')||'<div class="empty-inline">لا توجد تحديات.</div>'}catch(e){toast(e.message,'error')}}
async function loadStreaks(){try{const d=await api('/api/streaks');renderRankings('#streak-leaderboard',d.leaderboard.map(r=>({...r,rating:r.streak,wins:r.streak})));renderRankings('#streak-claims',d.claims.map(r=>({...r,username:`Player #${r.user_id}`,rating:r.streak,wins:r.streak})).slice(0,20))}catch(e){toast(e.message,'error')}}
async function loadAnnouncements(){try{const rows=await api('/api/announcements');$('#announcement-list').innerHTML=rows.map(a=>`<div class="season-row"><span><b>Announcement #${a.id}</b><small>Channel ${a.channel_id} · ${esc(a.created_at)}</small><small>${esc(a.message)}</small></span><span class="season-state">Sent</span></div>`).join('')||'<div class="empty-inline">لا توجد إعلانات مرسلة.</div>'}catch(e){toast(e.message,'error')}}
async function loadAuditLogs(){try{const rows=await api('/api/audit-logs?limit=100');$('#audit-list').innerHTML=rows.map(a=>`<div class="season-row"><span><b>${esc(a.action)}</b><small>Actor #${a.actor_id} · Target ${a.target_id??'—'} · ${esc(a.created_at||'')}</small><small>${esc(a.details||'')}</small></span></div>`).join('')||'<div class="empty-inline">لا توجد سجلات.</div>'}catch(e){toast(e.message,'error')}}
$('#tournament-refresh')?.addEventListener('click',loadTournaments);$('#challenge-refresh')?.addEventListener('click',loadChallenges);$('#streak-refresh')?.addEventListener('click',loadStreaks);$('#announcement-refresh')?.addEventListener('click',loadAnnouncements);$('#audit-refresh')?.addEventListener('click',loadAuditLogs);
$('#tournament-form')?.addEventListener('submit',async e=>{e.preventDefault();try{await api('/api/tournaments',{method:'POST',body:JSON.stringify({name:$('#tournament-name').value.trim(),size:Number($('#tournament-size').value)})});e.target.reset();await loadTournaments();toast('تم إنشاء البطولة')}catch(err){toast(err.message,'error')}});
$('#announcement-form')?.addEventListener('submit',async e=>{e.preventDefault();if(!confirm('إرسال هذا الإعلان إلى قناة Discord؟'))return;try{const r=await api('/api/announcements',{method:'POST',body:JSON.stringify({channel_id:Number($('#announcement-channel').value),message:$('#announcement-message').value.trim()})});e.target.reset();await loadAnnouncements();toast(`تم إرسال الإعلان #${r.id}`)}catch(err){toast(err.message,'error')}});

// ================== Init ==================
$$('.nav-item').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
$$('[data-goto]').forEach(b=>b.onclick=()=>showPage(b.dataset.goto));
$('#add-island-btn').onclick=()=>openIslandModal();
$('#proof-refresh').onclick=loadProofs;
$('#add-bp-season-btn').onclick=openBPSeasonModal;
$('#add-bp-mission-btn').onclick=openBPMissionModal;
$('#bp-season-select').onchange=loadBPMissions;
$$('[data-proof-filter]').forEach(b=>b.onclick=()=>{$$('[data-proof-filter]').forEach(x=>x.classList.toggle('active',x===b));state.proofFilter=b.dataset.proofFilter;renderProofs()});
$$('[data-proof-status]').forEach(b=>b.onclick=()=>{$$('[data-proof-status]').forEach(x=>x.classList.toggle('active',x===b));state.proofStatus=b.dataset.proofStatus;loadProofs()});
$('#search-player-btn').onclick=searchPlayers;
$('#economy-history-refresh')?.addEventListener('click',()=>{if(state.selectedPlayer)loadEconomyHistory(state.selectedPlayer.user_id)});
$('#shop-orders-refresh')?.addEventListener('click',loadShopOrders);
$('#player-search').addEventListener('keydown',e=>{if(e.key==='Enter')searchPlayers()});
$('#refresh-btn').onclick=async()=>{try{await loadIslands();await loadOverview();await loadActivity();if($('#page-proofs').classList.contains('active'))await loadProofs();if($('#page-battlepass').classList.contains('active'))await loadBP();if($('#page-shortcuts').classList.contains('active'))await loadShortcuts();if($('#page-settings').classList.contains('active'))await loadSettings();if($('#page-competitive').classList.contains('active'))await loadCompetitive();if($('#page-wanted').classList.contains('active'))await loadWanted();if($('#page-market').classList.contains('active'))await loadMarket();if($('#page-achievements').classList.contains('active'))await loadAchievements();if($('#page-tournaments').classList.contains('active'))await loadTournaments();if($('#page-challenges').classList.contains('active'))await loadChallenges();if($('#page-streaks').classList.contains('active'))await loadStreaks();if($('#page-announcements').classList.contains('active'))await loadAnnouncements();if($('#page-audit').classList.contains('active'))await loadAuditLogs();toast('تم تحديث البيانات')}catch(e){toast(e.message,'error')}};
$('#guild-select').onchange=async e=>{try{await api('/api/select-guild',{method:'POST',body:JSON.stringify({guild_id:e.target.value})});state.guildId=e.target.value;await loadOverview();toast('تم تغيير السيرفر')}catch(err){toast(err.message,'error')}};
$('#logout-btn').onclick=async()=>{try{await api('/api/logout',{method:'POST'});location.href='/login'}catch(e){location.href='/logout'}};
$('#menu-toggle').onclick=()=>{$('#sidebar').classList.add('open');$('#sidebar-overlay')?.classList.add('visible')};
$('#mobile-close').onclick=()=>{$('#sidebar').classList.remove('open');$('#sidebar-overlay')?.classList.remove('visible')};
$('#sidebar-overlay').onclick=()=>{$('#sidebar').classList.remove('open');$('#sidebar-overlay').classList.remove('visible')};
$('#add-bp-tier-btn').onclick=()=>openBPModal();
$('#upload-character-image').onclick=async()=>{
    const id=$('#character-image-select').value;
    const file=$('#character-image-file').files[0];
    if(!id||!file){toast('اختر الشخصية والصورة أولاً','error');return}
    try{
        const fd=new FormData();fd.append('file',file);
        const up=await api('/api/upload',{method:'POST',body:fd});
        await api(`/api/characters/${encodeURIComponent(id)}/image`,{method:'POST',body:JSON.stringify({image_url:up.url})});
        $('#character-image-file').value='';
        toast('تم تحديث صورة الشخصية وستظهر في أوامر البوت');
    }catch(e){toast(e.message,'error')}
};

loadShortcutCommands().then(syncShortcutEditor);
init();