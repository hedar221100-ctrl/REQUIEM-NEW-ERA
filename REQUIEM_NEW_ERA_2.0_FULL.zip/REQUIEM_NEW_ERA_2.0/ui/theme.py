import discord
from discord.ext import commands
from discord import app_commands
from ui.theme import RequiemTheme, ProfileView, build_profile_embed, GrandLineView, HuntersView, LeaguePickBanView, BattlePassView

class GeneralCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="profile", description="عرض بطاقة اللاعب وإحصائياتك في OPBR وسيرفر REQUIEM")
    async def profile(self, interaction: discord.Interaction, member: discord.Member = None):
        target = member or interaction.user
        embed = build_profile_embed(target)
        view = ProfileView()
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="grandline", description="فتح خريطة المغامرة والتنقل بين جزر ون بيس")
    async def grandline(self, interaction: discord.Interaction):
        embed = RequiemTheme.create_embed(
            title="REQUIEM: GRAND LINE — خريطة المغامرة",
            description="مرحباً بك في رحلة المغامرة الكبرى! اختر الجزيرة التي تريد الانتقال إليها أو خوض معارك الزعماء مع طاقمك.",
            color=RequiemTheme.COLOR_PRIMARY,
            banner_url=RequiemTheme.BANNER_GRANDLINE
        )
        view = GrandLineView()
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="hunters", description="عرض قائمة المهام اليومية والأسبوعية لـ OPBR ورفع الإثباتات")
    async def hunters(self, interaction: discord.Interaction):
        embed = RequiemTheme.create_embed(
            title="REQUIEM: LEGEND HUNTERS — المهام والتحديات",
            description="نفذ المهام الخاصة بشخصيات Attacker و Defender و Runner في اللعبة وارفع الإثبات لرفع مستواك!",
            color=RequiemTheme.COLOR_SUCCESS,
            banner_url=RequiemTheme.BANNER_HUNTERS
        )
        view = HuntersView()
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="league", description="واجهة نظام البطولات الاحترافي ومرحلة الـ Ban / Pick")
    async def league(self, interaction: discord.Interaction):
        embed = RequiemTheme.create_embed(
            title="REQUIEM: CHAMPIONS LEAGUE — دوري الأبطال",
            description="نظام البطولات الرسمي لسيرفر REQUIEM. يمكنك المباشرة بمرحلة الـ Ban/Pick واستعراض جداول المباريات.",
            color=RequiemTheme.COLOR_DANGER,
            banner_url=RequiemTheme.BANNER_LEAGUE
        )
        view = LeaguePickBanView()
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="pass", description="عرض تقدمك في الـ Battle Pass واستلام المكافآت الموسمية")
    async def battle_pass(self, interaction: discord.Interaction):
        embed = RequiemTheme.create_embed(
            title="REQUIEM: BATTLE PASS — ROAD TO YONKO",
            description="الموسم الأول: **THE ROAD TO YONKO** 🔥\nتقدم في المستويات عبر إكمال التحديات واستلم مكافآتك الحصرية!",
            color=RequiemTheme.COLOR_GOLD,
            banner_url=RequiemTheme.BANNER_PASS
        )
        view = BattlePassView()
        await interaction.response.send_message(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(GeneralCog(bot))
