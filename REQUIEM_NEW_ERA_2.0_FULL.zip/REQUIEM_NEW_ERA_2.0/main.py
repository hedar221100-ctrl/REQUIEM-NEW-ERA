"""
main.py — REQUIEM: NEW ERA
Main entry point for the Discord bot.

Features:
- Automatic cog loading from ./cogs
- Async DB initialization in setup_hook (prevents blocking)
- Tree sync (supports instant sync to a test guild if TEST_GUILD_ID is set)
- Global error handler for slash commands
"""

import os
import asyncio
from pathlib import Path
import discord
import uvicorn
from discord.ext import commands
from dotenv import load_dotenv

# Load .env before resolving paths and configuration.
load_dotenv()

from core import runtime

# ═══════════════════════════════════════════════════════════════════════════
# Bot Class
# ═══════════════════════════════════════════════════════════════════════════

class RequiemBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix="!", intents=intents)
        self.tree.on_error = on_tree_error

    async def setup_hook(self) -> None:
        """
        يتم استدعاء هذه الدالة مرة واحدة فقط قبل تسجيل دخول البوت.
        المكان المثالي لتهيئة قاعدة البيانات وتحميل الـ Cogs ومزامنة الأوامر.
        """
        print("⏳ جارٍ تهيئة قاعدة البيانات...")
        from web.store import initialize, refresh_live_catalog
        await initialize()
        print("✅ قاعدة البيانات جاهزة.")

        # 1. تحميل جميع ملفات الـ Cogs
        print("⏳ جارٍ تحميل الـ Cogs...")
        for filename in sorted(os.listdir("./cogs")):
            if filename.endswith(".py") and not filename.startswith("__"):
                try:
                    await self.load_extension(f"cogs.{filename[:-3]}")
                    print(f"  ✅ تم تحميل: {filename}")
                except Exception as e:
                    print(f"  ❌ فشل تحميل {filename}: {e}")

        refresh_live_catalog()

        # Restore pending proof-review controls after restarts. Each view uses
        # a proof-specific custom_id so simultaneous review cards never collide.
        try:
            from web.store import list_proofs
            from cogs.admin import AdminReviewView
            for proof in await list_proofs("pending"):
                self.add_view(AdminReviewView(proof["type"], int(proof["id"])))
            print("  ✅ تمت استعادة أزرار مراجعة الإثباتات المعلقة.")
        except Exception as exc:
            print(f"  ⚠️ تعذرت استعادة أزرار المراجعة: {exc!r}")

        try:
            from cogs.league import TournamentJoinView
            from utils.db import _conn
            with _conn() as conn:
                open_tournaments = conn.execute("SELECT id,size FROM tournaments WHERE status='registration'").fetchall()
            for tournament in open_tournaments:
                self.add_view(TournamentJoinView(int(tournament["id"]), int(tournament["size"])))
            print(f"  ✅ تمت استعادة أزرار الانضمام إلى {len(open_tournaments)} بطولة مفتوحة.")
        except Exception as exc:
            print(f"  ⚠️ تعذرت استعادة أزرار البطولات: {exc!r}")

        # 2. مزامنة الأوامر (Slash Commands)
        # للحصول على تحديث فوري للأوامر أثناء التطوير، ضع ID سيرفرك في .env باسم TEST_GUILD_ID
        test_guild_id = os.getenv("TEST_GUILD_ID")
        try:
            if test_guild_id:
                guild = discord.Object(id=int(test_guild_id))
                self.tree.copy_global_to(guild=guild)
                synced = await self.tree.sync(guild=guild)
                from utils.db import save_synced_commands
                registry = [{"name": getattr(cmd, "qualified_name", cmd.name), "id": int(cmd.id)} for cmd in synced if getattr(cmd, "id", None)]
                await save_synced_commands(int(test_guild_id), registry)
                print(f"✅ تمت مزامنة {len(synced)} أمر (Slash) في السيرفر التجريبي وحُفظت معرّفات {len(registry)} أمر.")
            else:
                synced = await self.tree.sync()
                from utils.db import save_synced_commands
                registry = [{"name": getattr(cmd, "qualified_name", cmd.name), "id": int(cmd.id)} for cmd in synced if getattr(cmd, "id", None)]
                await save_synced_commands(0, registry)
                print(f"✅ تمت مزامنة {len(synced)} أمر (Slash) عالمياً وحُفظت معرّفات {len(registry)} أمر (قد يستغرق التحديث ساعة).")
        except Exception as e:
            print(f"❌ فشل مزامنة الأوامر: {e}")

    async def on_ready(self):
        # هذه الدالة قد تُستدعى أكثر من مرة (عند انقطاع الاتصال مثلاً)
        print(f"\n🚀 البوت جاهز للعمل: {self.user.name} (ID: {self.user.id})")
        print(f"🌐 متصل بـ {len(self.guilds)} سيرفر.\n")
        status_type = discord.ActivityType.watching
        status_text = "REQUIEM: NEW ERA | /profile"
        try:
            from web.store import dashboard_summary
            if self.guilds:
                saved = await dashboard_summary(self.guilds[0].id)
                status_text = saved.get("status_text") or status_text
                status_type = {
                    "playing": discord.ActivityType.playing,
                    "watching": discord.ActivityType.watching,
                    "listening": discord.ActivityType.listening,
                    "competing": discord.ActivityType.competing,
                }.get(saved.get("bot_status"), status_type)
        except Exception as exc:
            print(f"⚠️ تعذر تحميل حالة البوت المحفوظة: {exc}")
        await self.change_presence(activity=discord.Activity(type=status_type, name=status_text))

# ═══════════════════════════════════════════════════════════════════════════
# Global Error Handler
# ═══════════════════════════════════════════════════════════════════════════

async def on_tree_error(interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
    """Centralized slash-command error handler with safe follow-up behavior."""
    if isinstance(error, discord.app_commands.CommandOnCooldown):
        message = f"⏳ يرجى الانتظار **{error.retry_after:.1f}** ثانية قبل استخدام هذا الأمر مجدداً."
    elif isinstance(error, discord.app_commands.MissingPermissions):
        message = "❌ لا تمتلك الصلاحيات الكافية لاستخدام هذا الأمر."
    else:
        command_name = interaction.command.name if interaction.command else "unknown"
        print(f"⚠️ خطأ في الأمر {command_name}: {error!r}")
        message = "❌ حدث خطأ غير متوقع. تم تسجيل التفاصيل في سجل البوت."

    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)

# ═══════════════════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════════════════

async def run_services():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("DISCORD_TOKEN is missing from environment")

    from web.store import initialize
    await initialize()

    bot = RequiemBot()
    runtime.bot = bot
    port = int(os.getenv("SERVER_PORT", os.getenv("WEB_PORT", os.getenv("PORT", "8000"))))
    config = uvicorn.Config("web.app:app", host="0.0.0.0", port=port, log_level="info", proxy_headers=True, forwarded_allow_ips="*")
    web_server = uvicorn.Server(config)

    print(f"🌐 REQUIEM Dashboard listening on 0.0.0.0:{port}")
    from config import DB_PATH, BACKUP_EVERY_HOURS, KEEP_BACKUPS
    from utils.backups import backup_loop
    backup_dir = Path(DB_PATH).expanduser().resolve().parent / "backups"
    bot_task = asyncio.create_task(bot.start(token), name="requiem-discord-bot")
    web_task = asyncio.create_task(web_server.serve(), name="requiem-dashboard")
    backup_task = asyncio.create_task(backup_loop(DB_PATH, backup_dir, BACKUP_EVERY_HOURS, KEEP_BACKUPS), name="requiem-sqlite-backups")
    tasks = {bot_task, web_task, backup_task}
    try:
        done, _pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            exception = task.exception()
            if exception:
                raise exception
    finally:
        web_server.should_exit = True
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if not bot.is_closed():
            await bot.close()
        runtime.bot = None


if __name__ == "__main__":
    try:
        asyncio.run(run_services())
    except KeyboardInterrupt:
        print("\n🛑 REQUIEM stopped.")
